<?php
$pageTitle = 'Live Chat Support';
require_once __DIR__ . '/../includes/functions.php';
$isAdminPage = isLoggedIn() && isAdmin();

$chatUser = null;
$chatMessages = [];
$allConversations = [];
$userId = $_SESSION['user_id'] ?? 0;

if ($isAdminPage) {
    if (isset($_GET['chat_with'])) {
        $chatWith = (int)$_GET['chat_with'];
        if ($chatWith && $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
            $msg = trim($_POST['message']);
            if ($msg) {
                query("INSERT INTO chat_messages (sender_id, receiver_id, message, is_read) VALUES (?,?,?,0)", [$userId, $chatWith, $msg]);
                header("Location: ?chat_with=" . $chatWith);
                exit;
            }
        }
    }
    $allConversations = fetchAll("SELECT cm.sender_id, u.username, MAX(cm.created_at) as last_msg, COUNT(CASE WHEN cm.is_read=0 AND cm.receiver_id=? THEN 1 END) as unread FROM chat_messages cm LEFT JOIN users u ON cm.sender_id=u.id WHERE cm.sender_id != ? GROUP BY cm.sender_id ORDER BY last_msg DESC", [$userId, $userId]);
    if (isset($_GET['chat_with'])) {
        $chatWith = (int)$_GET['chat_with'];
        $chatUser = fetch("SELECT id, username FROM users WHERE id=?", [$chatWith]);
        if ($chatWith) {
            query("UPDATE chat_messages SET is_read=1 WHERE sender_id=? AND receiver_id=?", [$chatWith, $userId]);
            $chatMessages = fetchAll("SELECT cm.*, u.username as sender_name FROM chat_messages cm LEFT JOIN users u ON cm.sender_id=u.id WHERE (cm.sender_id=? AND cm.receiver_id=?) OR (cm.sender_id=? AND cm.receiver_id=?) ORDER BY cm.created_at ASC", [$userId, $chatWith, $chatWith, $userId]);
        }
    }
} elseif (isLoggedIn()) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
        $msg = trim($_POST['message']);
        if ($msg) {
            query("INSERT INTO chat_messages (sender_id, receiver_id, message, is_read) VALUES (?,?,?,0)", [$userId, 1, $msg]);
            header("Location: chat.php");
            exit;
        }
    }
    $chatMessages = fetchAll("SELECT cm.*, u.username as sender_name FROM chat_messages cm LEFT JOIN users u ON cm.sender_id=u.id WHERE (cm.sender_id=? AND cm.receiver_id=1) OR (cm.sender_id=1 AND cm.receiver_id=?) ORDER BY cm.created_at ASC", [$userId, $userId]);
} else {
    redirect(SITE_URL . '/store/login.php');
}

if ($isAdminPage) require_once __DIR__ . '/../includes/admin_header.php';
?>

<style>
.chat-wrapper { display: flex; height: calc(100vh - 200px); min-height: 500px; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.1); background: #fff; }
.chat-sidebar { width: 320px; background: #1a1a2e; color: #fff; display: flex; flex-direction: column; flex-shrink: 0; }
.chat-sidebar-header { padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.08); }
.chat-sidebar-header h6 { margin: 0; font-weight: 700; font-size: 1rem; }
.chat-sidebar-list { flex: 1; overflow-y: auto; padding: 10px; }
.chat-sidebar-list::-webkit-scrollbar { width: 4px; }
.chat-sidebar-list::-webkit-scrollbar-thumb { background: #e94560; border-radius: 4px; }
.chat-conv-item { display: flex; align-items: center; gap: 12px; padding: 12px; border-radius: 12px; cursor: pointer; transition: all 0.2s; text-decoration: none; color: #ccc; margin-bottom: 4px; }
.chat-conv-item:hover { background: rgba(233,69,96,0.15); color: #fff; }
.chat-conv-item.active { background: rgba(233,69,96,0.25); color: #fff; border-left: 3px solid #e94560; }
.chat-conv-avatar { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #e94560, #c73e54); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 1rem; color: #fff; flex-shrink: 0; }
.chat-conv-info { flex: 1; min-width: 0; }
.chat-conv-name { font-weight: 600; font-size: 0.9rem; }
.chat-conv-time { font-size: 0.75rem; color: #888; }
.chat-conv-unread { background: #e94560; color: #fff; font-size: 0.65rem; padding: 3px 7px; border-radius: 10px; font-weight: 700; }

.chat-main { flex: 1; display: flex; flex-direction: column; background: #f8f9fa; }
.chat-header { padding: 16px 24px; background: #fff; border-bottom: 1px solid #eee; display: flex; align-items: center; gap: 12px; }
.chat-header-avatar { width: 36px; height: 36px; border-radius: 50%; background: linear-gradient(135deg, #e94560, #c73e54); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 700; }
.chat-header-info h6 { margin: 0; font-size: 0.95rem; font-weight: 600; }
.chat-header-info small { color: #999; }

.chat-messages { flex: 1; overflow-y: auto; padding: 20px 24px; display: flex; flex-direction: column; gap: 12px; }
.chat-messages::-webkit-scrollbar { width: 5px; }
.chat-messages::-webkit-scrollbar-thumb { background: #ddd; border-radius: 4px; }

.chat-bubble { max-width: 65%; padding: 12px 16px; border-radius: 16px; font-size: 0.9rem; line-height: 1.4; position: relative; }
.chat-bubble.sent { align-self: flex-end; background: linear-gradient(135deg, #0d6efd, #0b5ed7); color: #fff; border-bottom-right-radius: 4px; }
.chat-bubble.received { align-self: flex-start; background: #fff; color: #333; border-bottom-left-radius: 4px; box-shadow: 0 1px 4px rgba(0,0,0,0.06); }
.chat-bubble-time { font-size: 0.65rem; margin-top: 4px; opacity: 0.7; }
.chat-bubble.sent .chat-bubble-time { text-align: right; color: rgba(255,255,255,0.7); }
.chat-bubble.received .chat-bubble-time { color: #999; }
.chat-bubble-sender { font-size: 0.75rem; font-weight: 700; margin-bottom: 4px; color: #e94560; }

.chat-input { padding: 16px 24px; background: #fff; border-top: 1px solid #eee; display: flex; gap: 10px; align-items: center; }
.chat-input input { flex: 1; border: 2px solid #e9ecef; border-radius: 24px; padding: 12px 20px; font-size: 0.9rem; transition: border-color 0.3s; outline: none; }
.chat-input input:focus { border-color: #e94560; }
.chat-input button { width: 44px; height: 44px; border-radius: 50%; border: none; background: linear-gradient(135deg, #e94560, #c73e54); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; cursor: pointer; transition: transform 0.2s; }
.chat-input button:hover { transform: scale(1.05); }

.chat-empty { flex: 1; display: flex; align-items: center; justify-content: center; }
.chat-empty-inner { text-align: center; color: #999; }
.chat-empty-inner i { font-size: 4rem; margin-bottom: 16px; opacity: 0.3; }

@media (max-width: 768px) {
    .chat-wrapper { flex-direction: column; height: auto; min-height: 400px; }
    .chat-sidebar { width: 100%; max-height: 200px; }
    .chat-bubble { max-width: 85%; }
}
</style>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0"><i class="fas fa-comments text-primary"></i> <?= $isAdminPage ? 'Live Chat Support' : 'Chat with Support' ?></h4>
    <?php if ($isAdminPage): ?>
    <a href="<?= SITE_URL ?>/admin/" class="btn btn-sm btn-outline-primary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    <?php endif; ?>
</div>

<div class="chat-wrapper">
    <?php if ($isAdminPage): ?>
    <div class="chat-sidebar">
        <div class="chat-sidebar-header">
            <h6><i class="fas fa-inbox"></i> Conversations</h6>
        </div>
        <div class="chat-sidebar-list" id="chatSidebar">
            <?php if (empty($allConversations)): ?>
            <div class="text-center py-5" style="color:#666">
                <i class="fas fa-inbox fa-2x mb-2 d-block" style="opacity:0.3"></i>
                <small>No conversations yet</small>
            </div>
            <?php else: ?>
            <?php foreach ($allConversations as $conv): ?>
            <a href="?chat_with=<?= $conv['sender_id'] ?>" class="chat-conv-item <?= (isset($_GET['chat_with']) && $_GET['chat_with']==$conv['sender_id'])?'active':'' ?>">
                <div class="chat-conv-avatar"><?= strtoupper(substr($conv['username'],0,1)) ?></div>
                <div class="chat-conv-info">
                    <div class="chat-conv-name"><?= htmlspecialchars($conv['username']) ?></div>
                    <div class="chat-conv-time"><?= date('M d, H:i', strtotime($conv['last_msg'])) ?></div>
                </div>
                <?php if ($conv['unread'] > 0): ?>
                <span class="chat-conv-unread"><?= $conv['unread'] ?></span>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="chat-main">
        <?php if ($chatUser || !$isAdminPage): ?>
        <?php if ($chatUser): ?>
        <div class="chat-header">
            <div class="chat-header-avatar"><?= strtoupper(substr($chatUser['username'],0,1)) ?></div>
            <div class="chat-header-info">
                <h6><?= htmlspecialchars($chatUser['username']) ?></h6>
                <small>Online</small>
            </div>
        </div>
        <?php elseif (!$isAdminPage): ?>
        <div class="chat-header">
            <div class="chat-header-avatar">S</div>
            <div class="chat-header-info">
                <h6>Quick Mart Support</h6>
                <small>We typically reply within minutes</small>
            </div>
        </div>
        <?php endif; ?>

        <div class="chat-messages" id="chatBox">
            <?php if (empty($chatMessages) && !$isAdminPage): ?>
            <div class="chat-empty">
                <div class="chat-empty-inner">
                    <i class="fas fa-headset d-block"></i>
                    <h5>Welcome!</h5>
                    <p>How can we help you today?<br>Send us a message and we'll respond shortly.</p>
                </div>
            </div>
            <?php endif; ?>
            <?php foreach ($chatMessages as $msg): ?>
            <?php $isSent = $msg['sender_id'] == $_SESSION['user_id']; ?>
            <div class="chat-bubble <?= $isSent ? 'sent' : 'received' ?>">
                <?php if (!$isSent && $isAdminPage): ?>
                <div class="chat-bubble-sender"><?= htmlspecialchars($msg['sender_name']) ?></div>
                <?php endif; ?>
                <?= htmlspecialchars($msg['message']) ?>
                <div class="chat-bubble-time"><?= date('M d, H:i', strtotime($msg['created_at'])) ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <form method="POST" class="chat-input">
            <input type="text" name="message" placeholder="Type your message..." autofocus autocomplete="off">
            <button type="submit"><i class="fas fa-paper-plane"></i></button>
        </form>
        <?php else: ?>
        <div class="chat-empty">
            <div class="chat-empty-inner">
                <i class="fas fa-comments d-block"></i>
                <h5>Select a conversation</h5>
                <p>Choose a user from the sidebar to start chatting</p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
const chatBox = document.getElementById('chatBox');
const chatForm = document.querySelector('.chat-input form');
const chatInput = document.querySelector('.chat-input input[name="message"]');
let lastId = <?= !empty($chatMessages) ? end($chatMessages)['id'] : 0 ?>;
const chatWith = <?= ($chatUser && isset($chatUser['id'])) ? $chatUser['id'] : ($isAdminPage ? 'null' : '0') ?>;
const isAdmin = <?= $isAdminPage ? 'true' : 'false' ?>;
let isAtBottom = true;

chatBox.scrollTop = chatBox.scrollHeight;
chatBox.addEventListener('scroll', function() {
    isAtBottom = chatBox.scrollHeight - chatBox.scrollTop - chatBox.clientHeight < 50;
});

// Auto-scroll to bottom
function scrollBottom() {
    if (isAtBottom) chatBox.scrollTop = chatBox.scrollHeight;
}

// Add message bubble to chat
function addBubble(msg, isSent, senderName, isAdminChat) {
    const div = document.createElement('div');
    div.className = 'chat-bubble ' + (isSent ? 'sent' : 'received');
    let html = '';
    if (!isSent && isAdminChat) {
        html += '<div class="chat-bubble-sender">' + senderName + '</div>';
    }
    html += escapeHtml(msg.message);
    html += '<div class="chat-bubble-time">' + formatTime(msg.created_at) + '</div>';
    div.innerHTML = html;
    chatBox.appendChild(div);
}

function escapeHtml(t) {
    const d = document.createElement('div');
    d.textContent = t;
    return d.innerHTML;
}

function formatTime(dt) {
    const d = new Date(dt);
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return months[d.getMonth()] + ' ' + d.getDate() + ' ' + String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0');
}

// AJAX Send Message
chatForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const msg = chatInput.value.trim();
    if (!msg) return;
    chatInput.value = '';

    fetch('<?= SITE_URL ?>/api/chat.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({message: msg, chat_with: chatWith})
    }).then(r => r.json()).then(data => {
        if (data.ok) {
            const div = document.createElement('div');
            div.className = 'chat-bubble sent';
            div.innerHTML = escapeHtml(msg) + '<div class="chat-bubble-time">' + data.time + '</div>';
            chatBox.appendChild(div);
            scrollBottom();
        }
    });
});

// Auto-refresh every 5 seconds
setInterval(function() {
    // Refresh chat messages
    if (chatWith || !isAdmin) {
        const url = '<?= SITE_URL ?>/api/chat.php?chat_with=' + (chatWith || 0) + '&last_id=' + lastId;
        fetch(url).then(r => r.json()).then(data => {
            if (data.messages && data.messages.length > 0) {
                data.messages.forEach(m => {
                    const isSent = m.sender_id == <?= $userId ?? 0 ?>;
                    addBubble(m, isSent, m.sender_name, isAdmin);
                    lastId = m.id;
                });
                scrollBottom();
            }
        });
    }
    // Refresh admin sidebar conversation list
    if (isAdmin) {
        fetch('<?= SITE_URL ?>/api/chat.php?action=conversations').then(r => r.json()).then(data => {
            if (data.conversations) {
                const sidebar = document.getElementById('chatSidebar');
                if (data.conversations.length === 0) {
                    sidebar.innerHTML = '<div class="text-center py-5" style="color:#666"><i class="fas fa-inbox fa-2x mb-2 d-block" style="opacity:0.3"></i><small>No conversations yet</small></div>';
                } else {
                    sidebar.innerHTML = data.conversations.map(c => {
                        const active = c.sender_id == chatWith ? ' active' : '';
                        const initial = c.username.charAt(0).toUpperCase();
                        const time = new Date(c.last_msg).toLocaleDateString('en', {month:'short', day:'numeric'}) + ', ' + new Date(c.last_msg).toLocaleTimeString('en', {hour:'2-digit', minute:'2-digit'});
                        const unread = c.unread > 0 ? '<span class="chat-conv-unread">' + c.unread + '</span>' : '';
                        return '<a href="?chat_with=' + c.sender_id + '" class="chat-conv-item' + active + '"><div class="chat-conv-avatar">' + initial + '</div><div class="chat-conv-info"><div class="chat-conv-name">' + escapeHtml(c.username) + '</div><div class="chat-conv-time">' + time + '</div></div>' + unread + '</a>';
                    }).join('');
                }
            }
        });
    }
}, 5000);
</script>

<?php if ($isAdminPage): require_once __DIR__ . '/../includes/admin_footer.php'; else: require_once __DIR__ . '/../includes/footer.php'; endif; ?>
