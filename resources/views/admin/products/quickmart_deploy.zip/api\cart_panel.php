<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: application/json');

$userId = $_SESSION['user_id'] ?? null;
$sid = getCartSession();

if ($userId) {
    $items = fetchAll("SELECT c.id, c.quantity, c.product_id, p.name, p.price, p.stock, p.slug, p.image FROM cart_items c JOIN products p ON c.product_id=p.id WHERE c.user_id=? ORDER BY c.id DESC", [$userId]);
} else {
    $items = fetchAll("SELECT c.id, c.quantity, c.product_id, p.name, p.price, p.stock, p.slug, p.image FROM cart_items c JOIN products p ON c.product_id=p.id WHERE c.session_id=? ORDER BY c.id DESC", [$sid]);
}

$subtotal = 0;
foreach ($items as &$item) {
    $item['line_total'] = $item['price'] * $item['quantity'];
    $subtotal += $item['line_total'];
    $img = !empty($item['image']) && file_exists(__DIR__ . '/../' . $item['image']) ? $item['image'] : 'assets/images/no-image.svg';
    $item['image_url'] = SITE_URL . '/' . $img;
}
unset($item);

$count = 0;
foreach ($items as $i) $count += $i['quantity'];

$shipping = $subtotal >= 2000 ? 0 : 80;

echo json_encode([
    'success'   => true,
    'items'     => $items,
    'count'     => $count,
    'subtotal'  => $subtotal,
    'shipping'  => $shipping,
    'total'     => $subtotal + $shipping,
]);
