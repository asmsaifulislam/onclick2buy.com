<?php
$pageTitle = 'Site Configuration';
require_once __DIR__ . '/../includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $configs = ['store_name','store_address','store_phone','store_email','vat_percent','tax_enabled','social_facebook','social_instagram','social_youtube','social_twitter','social_whatsapp','store_map_lat','store_map_lng','currency','maintenance_mode'];
    foreach ($configs as $key) {
        $value = $_POST[$key] ?? '';
        $existing = fetch("SELECT id FROM site_config WHERE `key`=?", [$key]);
        if ($existing) { query("UPDATE site_config SET value=? WHERE `key`=?", [$value, $key]); }
        else { query("INSERT INTO site_config (`key`, value) VALUES (?,?)", [$key, $value]); }
    }
    setAlert('success', 'Site configuration saved!'); redirect(SITE_URL . '/admin/site_config.php');
}
$config = [];
$rows = fetchAll("SELECT `key`, value FROM site_config");
foreach ($rows as $r) $config[$r['key']] = $r['value'];
?>
<h4 class="mb-4"><i class="fas fa-cog"></i> Site Configuration</h4>
<form method="POST">
<div class="row g-4">
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h6 class="mb-3">Store Information</h6>
            <div class="mb-3"><label class="form-label fw-bold">Store Name</label><input type="text" name="store_name" class="form-control" value="<?= htmlspecialchars($config['store_name'] ?? 'Quick Mart') ?>"></div>
            <div class="mb-3"><label class="form-label fw-bold">Address</label><textarea name="store_address" class="form-control" rows="2"><?= htmlspecialchars($config['store_address'] ?? '') ?></textarea></div>
            <div class="row g-3 mb-3"><div class="col-6"><label class="form-label fw-bold">Phone</label><input type="text" name="store_phone" class="form-control" value="<?= htmlspecialchars($config['store_phone'] ?? '') ?>"></div>
            <div class="col-6"><label class="form-label fw-bold">Email</label><input type="email" name="store_email" class="form-control" value="<?= htmlspecialchars($config['store_email'] ?? '') ?>"></div></div>
            <div class="mb-3"><label class="form-label fw-bold">Currency</label><input type="text" name="currency" class="form-control" value="<?= htmlspecialchars($config['currency'] ?? 'BDT') ?>"></div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card card-custom p-4 mb-4">
            <h6 class="mb-3">Tax / VAT</h6>
            <div class="row g-3">
                <div class="col-6"><label class="form-label fw-bold">VAT %</label><input type="number" step="0.1" name="vat_percent" class="form-control" value="<?= htmlspecialchars($config['vat_percent'] ?? '0') ?>"></div>
                <div class="col-6"><label class="form-label fw-bold">Tax Enabled</label><select name="tax_enabled" class="form-select"><option value="0" <?= ($config['tax_enabled'] ?? '0')=='0'?'selected':'' ?>>No</option><option value="1" <?= ($config['tax_enabled'] ?? '0')=='1'?'selected':'' ?>>Yes</option></select></div>
            </div>
        </div>
        <div class="card card-custom p-4 mb-4">
            <h6 class="mb-3">Social Media</h6>
            <div class="mb-3"><label class="form-label fw-bold">Facebook URL</label><input type="url" name="social_facebook" class="form-control" value="<?= htmlspecialchars($config['social_facebook'] ?? '') ?>"></div>
            <div class="mb-3"><label class="form-label fw-bold">Instagram URL</label><input type="url" name="social_instagram" class="form-control" value="<?= htmlspecialchars($config['social_instagram'] ?? '') ?>"></div>
            <div class="mb-3"><label class="form-label fw-bold">YouTube URL</label><input type="url" name="social_youtube" class="form-control" value="<?= htmlspecialchars($config['social_youtube'] ?? '') ?>"></div>
            <div class="mb-3"><label class="form-label fw-bold">Twitter URL</label><input type="url" name="social_twitter" class="form-control" value="<?= htmlspecialchars($config['social_twitter'] ?? '') ?>"></div>
            <div class="mb-3"><label class="form-label fw-bold">WhatsApp Number (with country code)</label><input type="text" name="social_whatsapp" class="form-control" placeholder="+8801XXXXXXXXX" value="<?= htmlspecialchars($config['social_whatsapp'] ?? '') ?>"></div>
        </div>
        <div class="card card-custom p-4">
            <h6 class="mb-3">Map Coordinates</h6>
            <div class="row g-3">
                <div class="col-6"><label class="form-label fw-bold">Latitude</label><input type="number" step="any" name="store_map_lat" class="form-control" value="<?= htmlspecialchars($config['store_map_lat'] ?? '23.8103') ?>"></div>
                <div class="col-6"><label class="form-label fw-bold">Longitude</label><input type="number" step="any" name="store_map_lng" class="form-control" value="<?= htmlspecialchars($config['store_map_lng'] ?? '90.4125') ?>"></div>
            </div>
        </div>
    </div>
</div>
<div class="row g-4 mt-2">
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h6 class="mb-3">System</h6>
            <div class="mb-3"><label class="form-label fw-bold">Maintenance Mode</label><select name="maintenance_mode" class="form-select"><option value="0" <?= ($config['maintenance_mode'] ?? '0')=='0'?'selected':'' ?>>Off</option><option value="1" <?= ($config['maintenance_mode'] ?? '0')=='1'?'selected':'' ?>>On (Shows maintenance page)</option></select></div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h6 class="mb-3">Delivery Charges</h6>
            <div class="row g-3">
                <div class="col-6"><label class="form-label fw-bold">Inside Dhaka</label><input type="number" class="form-control" value="80" disabled><small class="text-muted">Set in config.php</small></div>
                <div class="col-6"><label class="form-label fw-bold">Outside Dhaka</label><input type="number" class="form-control" value="120" disabled><small class="text-muted">Set in config.php</small></div>
            </div>
        </div>
    </div>
</div>
<div class="mt-4"><button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-save"></i> Save Configuration</button></div>
</form>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
