<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn()) { setAlert('danger', 'Please login first.'); redirect(SITE_URL . '/store/login.php'); }

$action = $_POST['action'] ?? '';
$userId = $_SESSION['user_id'];

switch ($action) {
    case 'alert':
        $productId = (int)($_POST['product_id'] ?? 0);
        $targetPrice = (float)($_POST['target_price'] ?? 0);
        if ($productId && $targetPrice > 0) {
            query("INSERT OR REPLACE INTO price_alerts (user_id, product_id, target_price) VALUES (?,?,?)", [$userId, $productId, $targetPrice]);
            setAlert('success', 'Price alert set!');
        }
        break;
    case 'subscribe':
        $productId = (int)($_POST['product_id'] ?? 0);
        $plan = $_POST['plan_name'] ?? '';
        $freq = $_POST['frequency'] ?? 'monthly';
        $product = fetch("SELECT price FROM products WHERE id=?", [$productId]);
        if ($product && $plan) {
            query("INSERT INTO subscriptions (user_id, product_id, plan_name, frequency, price, status) VALUES (?,?,?,?,?,'active')", [$userId, $productId, $plan, $freq, $product['price']]);
            setAlert('success', 'Subscription created!');
        }
        break;
    case 'redeem_points':
        $points = (int)($_POST['points'] ?? 0);
        $current = fetch("SELECT points FROM loyalty_points WHERE user_id=?", [$userId]);
        if ($current && $current['points'] >= $points && $points >= 100) {
            $discount = floor($points / 100);
            query("UPDATE loyalty_points SET points=points-?, total_redeemed=total_redeemed+? WHERE user_id=?", [$points, $points, $userId]);
            query("INSERT INTO loyalty_transactions (user_id, points, tx_type, description) VALUES (?,-?,?,'redeemed','Redeemed for BDT $discount discount')", [$userId, $points]);
            setAlert('success', "Redeemed $points points for BDT $discount discount!");
        } else {
            setAlert('danger', 'Not enough points. Minimum 100 points required.');
        }
        break;
}

redirect($_SERVER['HTTP_REFERER'] ?? SITE_URL . '/store/');
