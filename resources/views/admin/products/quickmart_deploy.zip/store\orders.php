<?php
$pageTitle = 'My Orders - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');

$orders = fetchAll("SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC", [$_SESSION['user_id']]);
?>

<h2 class="mb-4"><i class="fas fa-box"></i> My Orders</h2>

<?php if (empty($orders)): ?>
<div class="text-center py-5">
    <i class="fas fa-box-open fa-4x text-muted mb-3"></i>
    <h5>No orders yet</h5>
    <a href="<?= SITE_URL ?>/store/products.php" class="btn btn-primary mt-3">Start Shopping</a>
</div>
<?php else: ?>
<?php foreach ($orders as $order): ?>
<div class="card card-custom mb-3 p-4">
    <div class="row align-items-center">
        <div class="col-md-2">
            <small class="text-muted">Order</small><br>
            <strong>#<?= $order['order_number'] ?></strong>
        </div>
        <div class="col-md-2">
            <small class="text-muted">Date</small><br>
            <?= date('M d, Y', strtotime($order['created_at'])) ?>
        </div>
        <div class="col-md-2">
            <small class="text-muted">Total</small><br>
            <strong class="text-primary"><?= formatPrice($order['total']) ?></strong>
        </div>
        <div class="col-md-2">
            <small class="text-muted">Payment</small><br>
            <span class="badge bg-info"><?= strtoupper($order['payment_method']) ?></span>
        </div>
        <div class="col-md-2">
            <small class="text-muted">Status</small><br>
            <?php
            $statusClass = match($order['status']) {
                'pending' => 'warning',
                'confirmed' => 'info',
                'shipped' => 'primary',
                'delivered' => 'success',
                'cancelled' => 'danger',
                default => 'secondary'
            };
            ?>
            <span class="badge bg-<?= $statusClass ?>"><?= ucfirst($order['status']) ?></span>
        </div>
        <div class="col-md-2 text-end">
            <a href="<?= SITE_URL ?>/store/order_detail.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-outline-primary">Details</a>
            <?php if ($order['status'] == 'pending'): ?>
            <form method="POST" action="<?= SITE_URL ?>/api/cart.php" style="display:inline">
                <input type="hidden" name="action" value="cancel_order">
                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Cancel this order?')">Cancel</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
