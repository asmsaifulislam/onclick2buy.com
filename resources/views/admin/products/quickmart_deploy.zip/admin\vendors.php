<?php
$pageTitle = 'Vendor Management';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM vendors WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/vendors.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [(int)$_POST['user_id'], $_POST['shop_name'], $_POST['description'], $_POST['phone'], $_POST['address'], (float)$_POST['commission_rate'], $_POST['status']];
    if ($id) { query("UPDATE vendors SET user_id=?, shop_name=?, description=?, phone=?, address=?, commission_rate=?, is_verified=? WHERE id=?", [...$data, ($data[6]=='verified'?1:0), $id]); }
    else { query("INSERT INTO vendors (user_id, shop_name, description, phone, address, commission_rate, is_verified) VALUES (?,?,?,?,?,?,?)", [$_POST['user_id'], $_POST['shop_name'], $_POST['description'], $_POST['phone'], $_POST['address'], (float)$_POST['commission_rate'], $_POST['status']=='verified'?1:0]); }
    setAlert('success', 'Vendor saved!'); redirect(SITE_URL . '/admin/vendors.php');
}
$vendors = fetchAll("SELECT v.*, u.username FROM vendors v LEFT JOIN users u ON v.user_id=u.id ORDER BY v.shop_name");
$users = fetchAll("SELECT id, username FROM users WHERE is_staff=0 ORDER BY username");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Vendors (<?= count($vendors) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_user').value='';document.getElementById('f_shop').value='';document.getElementById('f_desc').value='';document.getElementById('f_phone').value='';document.getElementById('f_addr').value='';document.getElementById('f_comm').value='10';document.getElementById('f_status').value='pending';document.getElementById('modalTitle').textContent='Add Vendor';"><i class="fas fa-plus"></i> Add Vendor</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>Shop</th><th>User</th><th>Phone</th><th>Commission</th><th>Earnings</th><th>Status</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($vendors as $v): ?>
<tr><td><strong><?= htmlspecialchars($v['shop_name']) ?></strong></td><td><?= htmlspecialchars($v['username'] ?? 'N/A') ?></td><td><?= htmlspecialchars($v['phone']) ?></td><td><?= $v['commission_rate'] ?>%</td><td><?= formatPrice($v['total_earnings']) ?></td>
<td><span class="badge bg-<?= $v['is_verified']?'success':'warning' ?>"><?= $v['is_verified']?'Verified':'Pending' ?></span></td>
<td><button class="btn btn-sm btn-warning" onclick="document.getElementById('f_id').value='<?= $v['id'] ?>';document.getElementById('f_user').value='<?= $v['user_id'] ?>';document.getElementById('f_shop').value='<?= htmlspecialchars($v['shop_name']) ?>';document.getElementById('f_desc').value='<?= htmlspecialchars($v['description']) ?>';document.getElementById('f_phone').value='<?= htmlspecialchars($v['phone']) ?>';document.getElementById('f_addr').value='<?= htmlspecialchars($v['address']) ?>';document.getElementById('f_comm').value='<?= $v['commission_rate'] ?>';document.getElementById('f_status').value='<?= $v['is_verified']?'verified':'pending' ?>';document.getElementById('modalTitle').textContent='Edit Vendor';new bootstrap.Modal(document.getElementById('modal')).show();"><i class="fas fa-edit"></i></button> <a href="?delete=<?= $v['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Vendor</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">User</label><select name="user_id" id="f_user" class="form-select" required><option value="">Select</option><?php foreach ($users as $u): ?><option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['username']) ?></option><?php endforeach; ?></select></div>
<div class="mb-3"><label class="form-label">Shop Name</label><input type="text" name="shop_name" id="f_shop" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Description</label><textarea name="description" id="f_desc" class="form-control"></textarea></div>
<div class="row g-3 mb-3"><div class="col-6"><label class="form-label">Phone</label><input type="text" name="phone" id="f_phone" class="form-control"></div>
<div class="col-6"><label class="form-label">Commission %</label><input type="number" step="0.1" name="commission_rate" id="f_comm" class="form-control"></div></div>
<div class="mb-3"><label class="form-label">Address</label><input type="text" name="address" id="f_addr" class="form-control"></div>
<div class="mb-3"><label class="form-label">Status</label><select name="status" id="f_status" class="form-select"><option value="pending">Pending</option><option value="verified">Verified</option></select></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
