<?php
$pageTitle = 'Checkout - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');

$sid = getCartSession();
$cartItems = fetchAll("SELECT c.*, p.name, p.price, p.stock FROM cart_items c JOIN products p ON c.product_id=p.id WHERE c.user_id=?", [$_SESSION['user_id']]);
if (empty($cartItems)) redirect(SITE_URL . '/store/cart.php');

$subtotal = 0;
foreach ($cartItems as $item) $subtotal += $item['price'] * $item['quantity'];
$shipping = 80;
$giftWrapId = 0;
$giftWrapPrice = 0;
$pointsRedeemed = 0;
$pointsDiscount = 0;
$total = $subtotal + $shipping;

$giftWraps = fetchAll("SELECT * FROM gift_wraps ORDER BY name");
$lp = fetch("SELECT points FROM loyalty_points WHERE user_id=?", [$_SESSION['user_id']]);
$maxRedeem = $lp ? floor($lp['points'] / 100) : 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $giftWrapId = (int)($_POST['gift_wrap_id'] ?? 0);
    $pointsRedeemed = (int)($_POST['points_redeemed'] ?? 0);

    if ($giftWrapId) {
        $gw = fetch("SELECT price FROM gift_wraps WHERE id=?", [$giftWrapId]);
        if ($gw) $giftWrapPrice = $gw['price'];
    }

    if ($pointsRedeemed >= 100 && $lp && $lp['points'] >= $pointsRedeemed) {
        $pointsDiscount = floor($pointsRedeemed / 100);
    } else {
        $pointsRedeemed = 0;
        $pointsDiscount = 0;
    }

    $total = $subtotal + $shipping + $giftWrapPrice - $pointsDiscount;

    $orderNum = generateOrderNumber();
    $orderId = insertId("INSERT INTO orders (user_id, order_number, total, subtotal, shipping_cost, discount, status, payment_method, payment_status, shipping_name, shipping_phone, shipping_address, shipping_city, shipping_area, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [
        $_SESSION['user_id'], $orderNum, $total, $subtotal, $shipping, $pointsDiscount,
        'pending', $_POST['payment_method'] ?? 'cod', 'pending',
        $_POST['name'], $_POST['phone'], $_POST['address'], $_POST['city'], $_POST['area'], $_POST['notes'] ?? ''
    ]);
    foreach ($cartItems as $item) {
        query("INSERT INTO order_items (order_id, product_id, product_name, price, quantity) VALUES (?,?,?,?,?)", [$orderId, $item['product_id'], $item['name'], $item['price'], $item['quantity']]);
        query("UPDATE products SET stock = stock - ? WHERE id = ?", [$item['quantity'], $item['product_id']]);
    }
    if ($giftWrapId) {
        query("INSERT INTO order_gift_wraps (order_id, gift_wrap_id, message) VALUES (?,?,?)", [$orderId, $giftWrapId, $_POST['gift_message'] ?? '']);
    }
    if ($pointsRedeemed >= 100) {
        query("UPDATE loyalty_points SET points=points-?, total_redeemed=total_redeemed+? WHERE user_id=?", [$pointsRedeemed, $pointsRedeemed, $_SESSION['user_id']]);
        query("INSERT INTO loyalty_transactions (user_id, points, tx_type, description) VALUES (?,-?,'redeemed','Redeemed at checkout - BDT $pointsDiscount discount')", [$_SESSION['user_id'], $pointsRedeemed]);
    }
    $earnedPoints = floor($subtotal / 10);
    if ($earnedPoints > 0) {
        $existing = fetch("SELECT id FROM loyalty_points WHERE user_id=?", [$_SESSION['user_id']]);
        if ($existing) {
            query("UPDATE loyalty_points SET points=points+?, total_earned=total_earned+? WHERE user_id=?", [$earnedPoints, $earnedPoints, $_SESSION['user_id']]);
        } else {
            query("INSERT INTO loyalty_points (user_id, points, total_earned, total_redeemed) VALUES (?,?,?,0)", [$_SESSION['user_id'], $earnedPoints, $earnedPoints]);
        }
        query("INSERT INTO loyalty_transactions (user_id, points, tx_type, description) VALUES (?,?,'earned','Earned from order #$orderNum')", [$_SESSION['user_id'], $earnedPoints]);
    }
    if (isLoggedIn()) {
        query("DELETE FROM cart_items WHERE user_id=?", [$_SESSION['user_id']]);
    }
    setAlert('success', "Order #$orderNum placed! You earned $earnedPoints loyalty points!");
    redirect(SITE_URL . '/store/orders.php');
}
?>

<h2 class="mb-4"><i class="fas fa-credit-card"></i> Checkout</h2>
<form method="POST" class="row">
    <div class="col-md-7">
        <div class="card card-custom p-4 mb-3">
            <h5 class="mb-3">Shipping Details</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold">Full Name</label>
                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($_SESSION['username']) ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold">Phone Number</label>
                    <input type="text" name="phone" class="form-control" placeholder="01XXXXXXXXX" required>
                </div>
                <div class="col-12">
                    <label class="form-label fw-bold">Address</label>
                    <textarea name="address" class="form-control" rows="2" placeholder="House #, Road #, Area" required></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold">City</label>
                    <select name="city" class="form-select" id="citySelect" onchange="updateShipping()">
                        <option value="inside">Inside Dhaka</option>
                        <option value="outside">Outside Dhaka</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold">Area</label>
                    <input type="text" name="area" class="form-control" placeholder="Area name">
                </div>
                <div class="col-12">
                    <label class="form-label fw-bold">Order Notes (optional)</label>
                    <textarea name="notes" class="form-control" rows="2" placeholder="Any special instructions..."></textarea>
                </div>
            </div>
        </div>

        <div class="card card-custom p-4 mb-3">
            <h5 class="mb-3"><i class="fas fa-gift"></i> Gift Wrapping</h5>
            <div class="d-flex flex-wrap gap-2">
                <label class="btn btn-outline-secondary payment-option">
                    <input type="radio" name="gift_wrap_id" value="0" checked onchange="updateGiftPrice(0)"> No Gift Wrap
                </label>
                <?php foreach ($giftWraps as $gw): ?>
                <label class="btn btn-outline-success payment-option">
                    <input type="radio" name="gift_wrap_id" value="<?= $gw['id'] ?>" onchange="updateGiftPrice(<?= $gw['price'] ?>)"> <?= htmlspecialchars($gw['name']) ?> (<?= formatPrice($gw['price']) ?>)
                </label>
                <?php endforeach; ?>
            </div>
            <div class="mt-2">
                <label class="form-label fw-bold">Gift Message (optional)</label>
                <input type="text" name="gift_message" class="form-control" placeholder="Happy Birthday! 🎂">
            </div>
        </div>

        <?php if ($maxRedeem > 0): ?>
        <div class="card card-custom p-4 mb-3">
            <h5 class="mb-3"><i class="fas fa-star text-warning"></i> Loyalty Points</h5>
            <p class="text-muted small">You have <strong><?= number_format($lp['points']) ?></strong> points. 100 points = BDT 1 discount. Max redeem: <?= number_format($maxRedeem) ?> BDT.</p>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold">Points to Redeem</label>
                    <input type="number" name="points_redeemed" id="pointsRedeemed" class="form-control" min="0" max="<?= $lp['points'] ?>" step="100" value="0" onchange="updatePointsDiscount()">
                </div>
                <div class="col-md-6 d-flex align-items-end">
                    <p class="mb-0">Discount: <strong class="text-success" id="pointsDiscountText">BDT 0</strong></p>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="card card-custom p-4">
            <h5 class="mb-3">Payment Method</h5>
            <div class="d-flex flex-wrap gap-2 mb-3">
                <label class="btn btn-outline-success payment-option"><input type="radio" name="payment_method" value="cod" checked> Cash on Delivery</label>
                <label class="btn btn-outline-success payment-option"><input type="radio" name="payment_method" value="bkash"> bKash</label>
                <label class="btn btn-outline-success payment-option"><input type="radio" name="payment_method" value="nagad"> Nagad</label>
                <label class="btn btn-outline-success payment-option"><input type="radio" name="payment_method" value="rocket"> Rocket</label>
                <label class="btn btn-outline-primary payment-option"><input type="radio" name="payment_method" value="visa"> Visa/Mastercard</label>
            </div>
            <button type="submit" class="btn btn-primary btn-lg w-100 mt-3">Place Order - <span id="finalTotal"><?= formatPrice($total) ?></span></button>
        </div>
    </div>

    <div class="col-md-5">
        <div class="card card-custom p-4">
            <h5>Order Summary</h5>
            <?php foreach ($cartItems as $item): ?>
            <div class="d-flex justify-content-between mb-2">
                <span class="text-muted"><?= htmlspecialchars($item['name']) ?> x<?= $item['quantity'] ?></span>
                <span><?= formatPrice($item['price'] * $item['quantity']) ?></span>
            </div>
            <?php endforeach; ?>
            <hr>
            <div class="d-flex justify-content-between mb-2"><span>Subtotal</span><span><?= formatPrice($subtotal) ?></span></div>
            <div class="d-flex justify-content-between mb-2"><span>Shipping</span><span id="shippingCost"><?= formatPrice($shipping) ?></span></div>
            <div class="d-flex justify-content-between mb-2" id="giftWrapRow" style="display:none!important"><span>Gift Wrap</span><span id="giftWrapCost">BDT 0</span></div>
            <div class="d-flex justify-content-between mb-2" id="pointsDiscountRow" style="display:none!important"><span class="text-success">Points Discount</span><span class="text-success" id="pointsDiscountVal">-BDT 0</span></div>
            <hr>
            <div class="d-flex justify-content-between"><strong>Total</strong><strong class="text-primary" id="orderTotal"><?= formatPrice($total) ?></strong></div>
            <?php if ($earnedPoints = floor($subtotal / 10)): ?>
            <p class="small text-success mt-2 mb-0"><i class="fas fa-star"></i> You'll earn <strong><?= $earnedPoints ?></strong> loyalty points with this order!</p>
            <?php endif; ?>
        </div>
    </div>
</form>

<style>.payment-option { border-radius: 8px; padding: 10px 20px; } .payment-option input { margin-right: 5px; } .payment-option:has(input:checked) { background: #0d6efd; color: #fff; border-color: #0d6efd; }</style>
<script>
var giftPrice = 0, subtotal = <?= $subtotal ?>, shipping = <?= $shipping ?>;
function updateShipping() { shipping = document.getElementById('citySelect').value === 'inside' ? 80 : 120; recalc(); }
function updateGiftPrice(p) { giftPrice = p; document.getElementById('giftWrapRow').style.display = p > 0 ? 'flex' : 'none'; document.getElementById('giftWrapCost').textContent = 'BDT ' + p; recalc(); }
function updatePointsDiscount() { var pts = parseInt(document.getElementById('pointsRedeemed').value) || 0; var disc = Math.floor(pts / 100); document.getElementById('pointsDiscountRow').style.display = disc > 0 ? 'flex' : 'none'; document.getElementById('pointsDiscountVal').textContent = '-BDT ' + disc; recalc(); }
function recalc() { var pts = parseInt(document.getElementById('pointsRedeemed')?.value || 0); var disc = Math.floor(pts / 100); var total = subtotal + shipping + giftPrice - disc; document.getElementById('orderTotal').textContent = 'BDT ' + total; document.getElementById('finalTotal').textContent = 'BDT ' + total; }
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
