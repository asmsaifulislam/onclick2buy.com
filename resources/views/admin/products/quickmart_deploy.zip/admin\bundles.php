<?php
$pageTitle = 'Bundles';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM bundles WHERE id=?", [(int)$_GET['delete']]); query("DELETE FROM bundle_products WHERE bundle_id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/bundles.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [$_POST['name'], $_POST['description'], (float)$_POST['bundle_price'], (int)$_POST['stock_limit']];
    if ($id) { query("UPDATE bundles SET name=?, description=?, bundle_price=?, stock_limit=? WHERE id=?", array_merge($data, [$id])); query("DELETE FROM bundle_products WHERE bundle_id=?", [$id]); }
    else { $id = insertId("INSERT INTO bundles (name, description, bundle_price, stock_limit) VALUES (?,?,?,?)", $data); }
    if (!empty($_POST['product_ids'])) { foreach ($_POST['product_ids'] as $pid) { query("INSERT INTO bundle_products (bundle_id, product_id, quantity) VALUES (?,?,?)", [$id, $pid, (int)($_POST['quantities'][$pid] ?? 1)]); } }
    setAlert('success', 'Bundle saved!'); redirect(SITE_URL . '/admin/bundles.php');
}
$bundles = fetchAll("SELECT b.*, COUNT(bp.id) as item_count FROM bundles b LEFT JOIN bundle_products bp ON b.id=bp.bundle_id GROUP BY b.id ORDER BY b.name");
$products = fetchAll("SELECT id, name, price FROM products WHERE is_active=1 ORDER BY name");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Product Bundles (<?= count($bundles) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_name').value='';document.getElementById('f_desc').value='';document.getElementById('f_price').value='';document.getElementById('f_stock').value='';document.getElementById('modalTitle').textContent='Add Bundle';"><i class="fas fa-plus"></i> Add Bundle</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>Name</th><th>Bundle Price</th><th>Items</th><th>Stock Limit</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($bundles as $b): ?>
<tr><td><strong><?= htmlspecialchars($b['name']) ?></strong></td><td><strong class="text-success"><?= formatPrice($b['bundle_price']) ?></strong></td><td><?= $b['item_count'] ?> products</td><td><?= $b['stock_limit'] ?: 'Unlimited' ?></td>
<td><a href="?delete=<?= $b['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Bundle</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" id="f_name" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Description</label><textarea name="description" id="f_desc" class="form-control"></textarea></div>
<div class="row g-3 mb-3"><div class="col-6"><label class="form-label">Bundle Price</label><input type="number" step="0.01" name="bundle_price" id="f_price" class="form-control" required></div>
<div class="col-6"><label class="form-label">Stock Limit (0=unlimited)</label><input type="number" name="stock_limit" id="f_stock" class="form-control"></div></div>
<div class="mb-3"><label class="form-label">Products in Bundle</label>
<div style="max-height:200px;overflow-y:auto"><?php foreach ($products as $p): ?>
<div class="d-flex align-items-center gap-2 mb-1"><label class="form-check"><input type="checkbox" name="product_ids[]" value="<?= $p['id'] ?>" class="form-check-input"></label>
<span class="small flex-grow-1"><?= htmlspecialchars($p['name']) ?> (<?= formatPrice($p['price']) ?>)</span>
<input type="number" name="quantities[<?= $p['id'] ?>]" value="1" min="1" class="form-control form-control-sm" style="width:60px"></div>
<?php endforeach; ?></div></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
