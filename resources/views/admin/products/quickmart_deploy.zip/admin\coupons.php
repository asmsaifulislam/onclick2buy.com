<?php
$pageTitle = 'Manage Coupons';
require_once __DIR__ . '/../includes/admin_header.php';

if (isset($_GET['delete'])) {
    query("DELETE FROM coupons WHERE id=?", [(int)$_GET['delete']]);
    setAlert('success', 'Coupon deleted.');
    redirect(SITE_URL . '/admin/coupons.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [
        strtoupper($_POST['code']), (float)$_POST['discount_percent'], (float)$_POST['discount_amount'],
        (float)$_POST['min_purchase'], (int)$_POST['max_uses'], $_POST['valid_from'], $_POST['valid_to']
    ];
    if ($id) {
        query("UPDATE coupons SET code=?, discount_percent=?, discount_amount=?, min_purchase=?, max_uses=?, valid_from=?, valid_to=? WHERE id=?", array_merge($data, [$id]));
        setAlert('success', 'Coupon updated!');
    } else {
        query("INSERT INTO coupons (code, discount_percent, discount_amount, min_purchase, max_uses, valid_from, valid_to) VALUES (?,?,?,?,?,?,?)", $data);
        setAlert('success', 'Coupon added!');
    }
    redirect(SITE_URL . '/admin/coupons.php');
}

$coupons = fetchAll("SELECT * FROM coupons ORDER BY created_at DESC");
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Coupons (<?= count($coupons) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#couponModal" onclick="document.getElementById('cp_id').value='';document.getElementById('cp_code').value='';document.getElementById('cp_dp').value='';document.getElementById('cp_da').value='';document.getElementById('cp_min').value='';document.getElementById('cp_max').value='';document.getElementById('cp_from').value='';document.getElementById('cp_to').value='';document.getElementById('couponModalTitle').textContent='Add Coupon';">
        <i class="fas fa-plus"></i> Add Coupon
    </button>
</div>

<div class="card card-custom">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-custom">
                <thead><tr><th>Code</th><th>Discount %</th><th>Amount</th><th>Min Purchase</th><th>Uses</th><th>Valid</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($coupons as $c): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($c['code']) ?></strong></td>
                        <td><?= $c['discount_percent'] ?>%</td>
                        <td><?= formatPrice($c['discount_amount']) ?></td>
                        <td><?= formatPrice($c['min_purchase']) ?></td>
                        <td><?= $c['used_count'] ?>/<?= $c['max_uses'] ?: '∞' ?></td>
                        <td><small><?= $c['valid_from'] ?> to <?= $c['valid_to'] ?></small></td>
                        <td><span class="badge bg-<?= $c['is_active'] ? 'success' : 'danger' ?>"><?= $c['is_active'] ? 'Active' : 'Inactive' ?></span></td>
                        <td>
                            <button class="btn btn-sm btn-warning" onclick="document.getElementById('cp_id').value='<?= $c['id'] ?>';document.getElementById('cp_code').value='<?= $c['code'] ?>';document.getElementById('cp_dp').value='<?= $c['discount_percent'] ?>';document.getElementById('cp_da').value='<?= $c['discount_amount'] ?>';document.getElementById('cp_min').value='<?= $c['min_purchase'] ?>';document.getElementById('cp_max').value='<?= $c['max_uses'] ?>';document.getElementById('cp_from').value='<?= $c['valid_from'] ?>';document.getElementById('cp_to').value='<?= $c['valid_to'] ?>';document.getElementById('couponModalTitle').textContent='Edit Coupon';new bootstrap.Modal(document.getElementById('couponModal')).show();"><i class="fas fa-edit"></i></button>
                            <a href="?delete=<?= $c['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="couponModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="couponModalTitle">Add Coupon</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="cp_id">
                    <div class="mb-3"><label class="form-label">Code</label><input type="text" name="code" id="cp_code" class="form-control" required></div>
                    <div class="row g-3">
                        <div class="col-6"><label class="form-label">Discount %</label><input type="number" name="discount_percent" id="cp_dp" class="form-control" step="0.01"></div>
                        <div class="col-6"><label class="form-label">Amount (BDT)</label><input type="number" name="discount_amount" id="cp_da" class="form-control" step="0.01"></div>
                    </div>
                    <div class="row g-3 mt-1">
                        <div class="col-6"><label class="form-label">Min Purchase</label><input type="number" name="min_purchase" id="cp_min" class="form-control" step="0.01"></div>
                        <div class="col-6"><label class="form-label">Max Uses</label><input type="number" name="max_uses" id="cp_max" class="form-control"></div>
                    </div>
                    <div class="row g-3 mt-1">
                        <div class="col-6"><label class="form-label">Valid From</label><input type="date" name="valid_from" id="cp_from" class="form-control"></div>
                        <div class="col-6"><label class="form-label">Valid To</label><input type="date" name="valid_to" id="cp_to" class="form-control"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
