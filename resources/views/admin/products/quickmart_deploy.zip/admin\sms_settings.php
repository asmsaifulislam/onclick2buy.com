<?php
$pageTitle = 'SMS Settings';
require_once __DIR__ . '/../includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fields = ['twilio_sid','twilio_token','twilio_phone','sms_enabled','sms_order_confirmation','sms_delivery_update'];
    foreach ($fields as $f) {
        $value = $_POST[$f] ?? '';
        $existing = fetch("SELECT id FROM site_config WHERE `key`=?", [$f]);
        if ($existing) { query("UPDATE site_config SET value=? WHERE `key`=?", [$value, $f]); }
        else { query("INSERT INTO site_config (`key`, value) VALUES (?,?)", [$f, $value]); }
    }
    setAlert('success', 'SMS settings saved!'); redirect(SITE_URL . '/admin/sms_settings.php');
}

if (isset($_GET['test_sms'])) {
    $phone = $_GET['test_phone'] ?? '';
    $sid = $_GET['sid'] ?? '';
    $token = $_GET['token'] ?? '';
    $from = $_GET['from'] ?? '';
    if ($phone && $sid && $token && $from) {
        setAlert('info', "SMS test: Would send to $phone via Twilio (SID: $sid). Configure Twilio credentials to activate real SMS.");
    } else {
        setAlert('danger', 'Please fill all Twilio credentials first.');
    }
    redirect(SITE_URL . '/admin/sms_settings.php');
}

$config = [];
$rows = fetchAll("SELECT `key`, value FROM site_config WHERE `key` LIKE 'twilio%' OR `key` LIKE 'sms_%'");
foreach ($rows as $r) $config[$r['key']] = $r['value'];

$ordersNeedSms = fetchAll("SELECT o.id, o.order_number, o.shipping_phone, o.shipping_name, o.status, o.created_at FROM orders o LEFT JOIN sms_logs sl ON o.id=sl.order_id WHERE sl.id IS NULL AND o.status != 'pending' ORDER BY o.created_at DESC LIMIT 20");
$smsLogs = fetchAll("SELECT sl.*, o.order_number FROM sms_logs sl LEFT JOIN orders o ON sl.order_id=o.id ORDER BY sl.created_at DESC LIMIT 20");
?>
<h4 class="mb-4"><i class="fas fa-sms"></i> SMS Integration (Twilio)</h4>

<div class="row g-4">
    <div class="col-md-8">
        <div class="card card-custom p-4 mb-4">
            <h6 class="mb-3">Twilio Configuration</h6>
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Twilio SID</label>
                        <input type="text" name="twilio_sid" class="form-control" value="<?= htmlspecialchars($config['twilio_sid'] ?? '') ?>" placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Twilio Auth Token</label>
                        <input type="password" name="twilio_token" class="form-control" value="<?= htmlspecialchars($config['twilio_token'] ?? '') ?>" placeholder="Your auth token">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Twilio Phone Number</label>
                        <input type="text" name="twilio_phone" class="form-control" value="<?= htmlspecialchars($config['twilio_phone'] ?? '') ?>" placeholder="+1234567890">
                    </div>
                </div>
                <div class="row g-3 mt-2">
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Enable SMS</label>
                        <select name="sms_enabled" class="form-select"><option value="1" <?= ($config['sms_enabled'] ?? '0')=='1'?'selected':'' ?>>Yes</option><option value="0" <?= ($config['sms_enabled'] ?? '0')=='0'?'selected':'' ?>>No</option></select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Order Confirmation SMS</label>
                        <select name="sms_order_confirmation" class="form-select"><option value="1" <?= ($config['sms_order_confirmation'] ?? '0')=='1'?'selected':'' ?>>Yes</option><option value="0" <?= ($config['sms_order_confirmation'] ?? '0')=='0'?'selected':'' ?>>No</option></select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Delivery Update SMS</label>
                        <select name="sms_delivery_update" class="form-select"><option value="1" <?= ($config['sms_delivery_update'] ?? '0')=='1'?'selected':'' ?>>Yes</option><option value="0" <?= ($config['sms_delivery_update'] ?? '0')=='0'?'selected':'' ?>>No</option></select>
                    </div>
                </div>
                <div class="mt-3">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Settings</button>
                    <a href="?test_sms=1&sid=<?= urlencode($config['twilio_sid'] ?? '') ?>&token=<?= urlencode($config['twilio_token'] ?? '') ?>&from=<?= urlencode($config['twilio_phone'] ?? '') ?>" class="btn btn-outline-info ms-2"><i class="fas fa-paper-plane"></i> Test SMS</a>
                </div>
            </form>
        </div>

        <div class="card card-custom p-4">
            <h6>SMS Message Templates</h6>
            <div class="small">
                <p><strong>Order Confirmation:</strong></p>
                <pre class="bg-dark p-2 rounded">Hi {name}! Your order #{order_number} has been confirmed. Total: BDT {total}. Track: {tracking_url}</pre>
                <p class="mt-2"><strong>Status Update:</strong></p>
                <pre class="bg-dark p-2 rounded">Hi {name}! Your order #{order_number} status: {status}. {note}</pre>
                <p class="mt-2"><strong>Delivery:</strong></p>
                <pre class="bg-dark p-2 rounded">Hi {name}! Your order #{order_number} has been delivered. Thank you for shopping with Quick Mart!</pre>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-custom p-4 mb-4">
            <h6>SMS Stats</h6>
            <div class="d-flex justify-content-between mb-2"><span>Total Sent</span><strong><?= count_rows("SELECT COUNT(*) FROM sms_logs") ?></strong></div>
            <div class="d-flex justify-content-between mb-2"><span>Successful</span><strong class="text-success"><?= count_rows("SELECT COUNT(*) FROM sms_logs WHERE status='sent'") ?></strong></div>
            <div class="d-flex justify-content-between mb-2"><span>Failed</span><strong class="text-danger"><?= count_rows("SELECT COUNT(*) FROM sms_logs WHERE status='failed'") ?></strong></div>
        </div>
        <div class="card card-custom p-4">
            <h6>Recent SMS Logs</h6>
            <?php if (empty($smsLogs)): ?><p class="text-muted small">No SMS sent yet.</p><?php endif; ?>
            <?php foreach ($smsLogs as $sl): ?>
            <div class="small border-bottom py-1">
                <span class="badge bg-<?= $sl['status']=='sent'?'success':'danger' ?>"><?= $sl['status'] ?></span>
                <?= htmlspecialchars($sl['phone']) ?> — <?= htmlspecialchars($sl['message'] ?? '') ?>
                <br><span class="text-muted"><?= date('M d H:i', strtotime($sl['created_at'])) ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
