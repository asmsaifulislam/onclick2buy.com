<?php
$pageTitle = 'Manage Customers';
require_once __DIR__ . '/../includes/admin_header.php';

$customers = fetchAll("SELECT u.*, (SELECT COUNT(*) FROM orders WHERE user_id=u.id) as order_count, (SELECT COALESCE(SUM(total),0) FROM orders WHERE user_id=u.id AND status!='cancelled') as total_spent FROM users u WHERE u.is_staff=0 ORDER BY u.created_at DESC");
?>

<h4 class="mb-4">Customers (<?= count($customers) ?>)</h4>

<div class="card card-custom">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-custom">
                <thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Orders</th><th>Total Spent</th><th>Joined</th></tr></thead>
                <tbody>
                    <?php foreach ($customers as $c): ?>
                    <tr>
                        <td><?= $c['id'] ?></td>
                        <td><strong><?= htmlspecialchars($c['username']) ?></strong></td>
                        <td><?= htmlspecialchars($c['email']) ?></td>
                        <td><span class="badge bg-primary"><?= $c['order_count'] ?></span></td>
                        <td class="text-primary fw-bold"><?= formatPrice($c['total_spent']) ?></td>
                        <td><?= date('M d, Y', strtotime($c['created_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
