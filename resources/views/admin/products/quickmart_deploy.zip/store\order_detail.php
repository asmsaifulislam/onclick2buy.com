<?php
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');
$id = (int)($_GET['id'] ?? 0);
$order = fetch("SELECT * FROM orders WHERE id=? AND user_id=?", [$id, $_SESSION['user_id']]);
if (!$order) redirect(SITE_URL . '/store/orders.php');
$pageTitle = "Order #{$order['order_number']}";
$items = fetchAll("SELECT * FROM order_items WHERE order_id=?", [$order['id']]);
$shipping = $order['shipping_cost'];
$subtotal = $order['subtotal'];
?>

<nav class="mb-4"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="<?= SITE_URL ?>/store/orders.php">Orders</a></li><li class="breadcrumb-item active">#<?= $order['order_number'] ?></li></ol></nav>

<div class="row">
    <div class="col-md-8">
        <div class="card card-custom p-4 mb-4">
            <h5>Order #<?= $order['order_number'] ?></h5>
            <p class="text-muted">Placed on <?= date('F d, Y h:i A', strtotime($order['created_at'])) ?></p>
            <table class="table">
                <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Total</th></tr></thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['product_name']) ?></td>
                        <td><?= formatPrice($item['price']) ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td><?= formatPrice($item['price'] * $item['quantity']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-custom p-4 mb-4">
            <h6>Order Status</h6>
            <div class="mb-3">
                <?php
                $steps = ['pending', 'confirmed', 'shipped', 'delivered'];
                $current = array_search($order['status'], $steps);
                if ($current === false) $current = -1;
                foreach ($steps as $i => $step): ?>
                <div class="d-flex align-items-center mb-2">
                    <span class="badge rounded-pill me-2 <?= $i <= $current ? 'bg-success' : 'bg-secondary' ?>"><?= $i + 1 ?></span>
                    <span class="<?= $i <= $current ? 'fw-bold' : 'text-muted' ?>"><?= ucfirst($step) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <h6>Summary</h6>
            <div class="d-flex justify-content-between mb-1"><span>Subtotal</span><span><?= formatPrice($subtotal) ?></span></div>
            <div class="d-flex justify-content-between mb-1"><span>Shipping</span><span><?= formatPrice($shipping) ?></span></div>
            <hr>
            <div class="d-flex justify-content-between"><strong>Total</strong><strong class="text-primary"><?= formatPrice($order['total']) ?></strong></div>
        </div>
        <div class="card card-custom p-4">
            <h6>Shipping Info</h6>
            <p class="mb-1"><strong><?= htmlspecialchars($order['shipping_name']) ?></strong></p>
            <p class="mb-1"><?= htmlspecialchars($order['shipping_phone']) ?></p>
            <p class="mb-1"><?= htmlspecialchars($order['shipping_address']) ?></p>
            <p class="mb-1"><?= htmlspecialchars($order['shipping_city']) ?>, <?= htmlspecialchars($order['shipping_area']) ?></p>
            <p class="small text-muted mt-2">Payment: <?= strtoupper($order['payment_method']) ?></p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
