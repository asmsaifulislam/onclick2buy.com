<?php
$pageTitle = 'Register - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (isLoggedIn()) redirect(SITE_URL . '/store/');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['password'] !== $_POST['password2']) {
        setAlert('danger', 'Passwords do not match.');
    } elseif (strlen($_POST['password']) < 6) {
        setAlert('danger', 'Password must be at least 6 characters.');
    } elseif (registerUser($_POST['username'], $_POST['email'], $_POST['password'])) {
        loginUser($_POST['username'], $_POST['password']);
        setAlert('success', 'Account created successfully!');
        redirect(SITE_URL . '/store/');
    } else {
        setAlert('danger', 'Username or email already exists.');
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card card-custom p-4">
            <h3 class="text-center mb-4">Register</h3>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label fw-bold">Username</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Password</label>
                    <input type="password" name="password" class="form-control" required minlength="6">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Confirm Password</label>
                    <input type="password" name="password2" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100 mb-3">Register</button>
            </form>
            <p class="text-center">Already have an account? <a href="<?= SITE_URL ?>/store/login.php">Login here</a></p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
