<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';

echo "Running migration...\n";

$columns = fetchAll("PRAGMA table_info(users)");
$existing = array_column($columns, 'name');

if (!in_array('is_active', $existing)) {
    query("ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1");
    echo "Added is_active column.\n";
} else {
    echo "is_active column already exists.\n";
}

if (!in_array('role', $existing)) {
    query("ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'customer'");
    echo "Added role column.\n";
} else {
    echo "role column already exists.\n";
}

query("UPDATE users SET is_active=1, role='super_admin' WHERE id=1");
query("UPDATE users SET is_active=1 WHERE is_active IS NULL");

echo "Migration done.\n";
