<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

$now = date('Y-m-d H:i:s');
$sale = fetch("SELECT fs.end_date, fs.name, fs.discount_percent FROM flash_sales fs WHERE fs.is_active=1 AND fs.start_date<=? AND fs.end_date>=? ORDER BY fs.end_date ASC LIMIT 1", [$now, $now]);

if ($sale) {
    echo json_encode([
        'active' => true,
        'end_date' => $sale['end_date'],
        'title' => $sale['name'] ?? 'Flash Sale',
        'discount' => $sale['discount_percent'] ?? 0,
        'server_time' => date('Y-m-d\TH:i:s'),
    ]);
} else {
    $next = fetch("SELECT fs.start_date FROM flash_sales fs WHERE fs.is_active=1 AND fs.start_date>? ORDER BY fs.start_date ASC LIMIT 1", [$now]);
    echo json_encode([
        'active' => false,
        'end_date' => null,
        'next_start' => $next['start_date'] ?? null,
        'server_time' => date('Y-m-d\TH:i:s'),
    ]);
}
