<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { echo json_encode(['error' => 'Invalid product']); exit; }

$product = fetch("SELECT p.*, c.name as cat_name, c.slug as cat_slug FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = ? AND p.is_active = 1", [$id]);
if (!$product) { echo json_encode(['error' => 'Product not found']); exit; }

$variants = fetchAll("SELECT * FROM product_variants WHERE product_id = ? ORDER BY id", [$id]);

echo json_encode([
    'id'            => $product['id'],
    'name'          => $product['name'],
    'slug'          => $product['slug'],
    'price'         => (float)$product['price'],
    'price_fmt'     => formatPrice($product['price']),
    'stock'         => (int)$product['stock'],
    'image'         => getProductImage($product),
    'description'   => $product['description'] ?? '',
    'cat_name'      => $product['cat_name'] ?? '',
    'cat_slug'      => $product['cat_slug'] ?? '',
    'brand'         => $product['brand'] ?? '',
    'average_rating'=> (int)$product['average_rating'],
    'total_reviews' => (int)$product['total_reviews'],
    'variants'      => array_map(function($v) {
        return [
            'id'       => $v['id'],
            'name'     => $v['name'] ?? '',
            'type'     => $v['type'] ?? '',
            'value'    => $v['value'] ?? '',
            'price'    => (float)($v['price'] ?? 0),
            'stock'    => (int)($v['stock'] ?? 0),
        ];
    }, $variants),
]);
