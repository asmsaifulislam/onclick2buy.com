<?php
$pageTitle = 'Login - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (isLoggedIn()) redirect(SITE_URL . '/store/');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (loginUser($_POST['username'], $_POST['password'])) {
        setAlert('success', 'Welcome back, ' . htmlspecialchars($_SESSION['username']) . '!');
        redirect(SITE_URL . '/store/');
    } else {
        setAlert('danger', 'Invalid username or password.');
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card card-custom p-4">
            <h3 class="text-center mb-4">Login</h3>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label fw-bold">Username</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100 mb-3">Login</button>
            </form>
            <p class="text-center">Don't have an account? <a href="<?= SITE_URL ?>/store/register.php">Register here</a></p>
            <hr>
            <p class="text-muted small text-center">Demo: <strong>admin</strong> / <strong>admin123</strong></p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
