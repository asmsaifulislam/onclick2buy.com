<?php
$pageTitle = 'My Wallet - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');

$wallet = fetch("SELECT * FROM wallets WHERE user_id=?", [$_SESSION['user_id']]);
if (!$wallet) { query("INSERT INTO wallets (user_id, balance) VALUES (?,0)", [$_SESSION['user_id']]); $wallet = fetch("SELECT * FROM wallets WHERE user_id=?", [$_SESSION['user_id']]); }
$transactions = fetchAll("SELECT wt.*, w.id as wid FROM wallet_transactions wt JOIN wallets w ON wt.wallet_id=w.id WHERE w.user_id=? ORDER BY wt.created_at DESC LIMIT 20", [$_SESSION['user_id']]);
?>
<h2 class="mb-4"><i class="fas fa-wallet"></i> My Wallet</h2>
<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card card-custom p-4 text-center">
            <i class="fas fa-wallet fa-3x text-primary mb-3"></i>
            <h2 class="text-primary"><?= formatPrice($wallet['balance']) ?></h2>
            <p class="text-muted">Available Balance</p>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card card-custom p-4">
            <h5>Transaction History</h5>
            <?php if (empty($transactions)): ?>
            <p class="text-muted">No transactions yet.</p>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-sm table-custom">
                    <thead><tr><th>Date</th><th>Type</th><th>Amount</th><th>Description</th></tr></thead>
                    <tbody>
                        <?php foreach ($transactions as $t): ?>
                        <tr>
                            <td><?= date('M d, Y', strtotime($t['created_at'])) ?></td>
                            <td><span class="badge bg-<?= $t['tx_type']=='credit'?'success':'danger' ?>"><?= ucfirst($t['tx_type']) ?></span></td>
                            <td class="fw-bold <?= $t['tx_type']=='credit'?'text-success':'text-danger' ?>"><?= $t['tx_type']=='credit'?'+':'-' ?><?= formatPrice($t['amount']) ?></td>
                            <td><?= htmlspecialchars($t['description']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
