<?php
$pageTitle = 'Dashboard';
require_once __DIR__ . '/../includes/admin_header.php';

$period = $_GET['period'] ?? 'today';
$today = date('Y-m-d');
switch ($period) {
    case 'week': $startDate = date('Y-m-d', strtotime('-7 days')); break;
    case 'month': $startDate = date('Y-m-d', strtotime('-30 days')); break;
    case 'year': $startDate = date('Y-m-d', strtotime('-365 days')); break;
    default: $startDate = $today;
}
$yesterday = date('Y-m-d', strtotime('-1 day'));
$lastWeek = date('Y-m-d', strtotime('-14 days'));

$totalOrders = count_rows("SELECT COUNT(*) FROM orders WHERE created_at >= ?", [$startDate]);
$totalRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND created_at >= ?", [$startDate]);
$pendingOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status='pending' AND created_at >= ?", [$startDate]);
$confirmedOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status='confirmed' AND created_at >= ?", [$startDate]);
$shippedOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status='shipped' AND created_at >= ?", [$startDate]);
$deliveredOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status='delivered' AND created_at >= ?", [$startDate]);
$cancelledOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status='cancelled' AND created_at >= ?", [$startDate]);
$totalProducts = count_rows("SELECT COUNT(*) FROM products WHERE is_active=1");
$totalCategories = count_rows("SELECT COUNT(*) FROM categories WHERE is_active=1");
$totalCustomers = count_rows("SELECT COUNT(*) FROM users WHERE is_staff=0");
$lowStockCount = count_rows("SELECT COUNT(*) FROM products WHERE is_active=1 AND stock <= 10");
$pendingRefunds = count_rows("SELECT COUNT(*) FROM refund_requests WHERE status='pending'");
$avgOrderValue = $totalOrders > 0 ? $totalRevenue / $totalOrders : 0;

$ydOrders = count_rows("SELECT COUNT(*) FROM orders WHERE created_at >= ? AND created_at < ?", [$yesterday, $today]);
$ydRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND created_at >= ? AND created_at < ?", [$yesterday, $today]);
$ordersChange = $totalOrders - $ydOrders;
$revenueChange = $totalRevenue - $ydRevenue;

$lwOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status != 'cancelled' AND created_at >= ? AND created_at < ?", [$lastWeek, $startDate]);
$lwRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND created_at >= ? AND created_at < ?", [$lastWeek, $startDate]);
$wowOrders = $lwOrders > 0 ? round(($totalOrders - $lwOrders) / $lwOrders * 100, 1) : 0;
$wowRevenue = $lwRevenue > 0 ? round(($totalRevenue - $lwRevenue) / $lwRevenue * 100, 1) : 0;

$targetAmount = count_rows("SELECT COALESCE(target_amount,0) FROM revenue_targets WHERE month=? AND year=?", [(int)date('m'), (int)date('Y')]);
$targetProgress = $targetAmount > 0 ? ($totalRevenue / $targetAmount * 100) : 0;

$overdueOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status IN ('pending','confirmed') AND created_at < ?", [date('Y-m-d H:i:s', strtotime('-3 days'))]);

$newCustomers = count_rows("SELECT COUNT(*) FROM users WHERE is_staff=0 AND created_at >= ?", [$startDate]);
$returningCustomers = $totalCustomers - $newCustomers;
$returningRate = $totalCustomers > 0 ? round($returningCustomers / $totalCustomers * 100) : 0;

$totalRefunds = count_rows("SELECT COALESCE(SUM(amount),0) FROM refund_requests WHERE status='approved' AND created_at >= ?", [$startDate]);
$refundRate = $totalRevenue > 0 ? round($totalRefunds / $totalRevenue * 100, 1) : 0;

$couponUsed = count_rows("SELECT COUNT(*) FROM orders WHERE discount > 0 AND created_at >= ?", [$startDate]);
$couponRevenue = count_rows("SELECT COALESCE(SUM(discount),0) FROM orders WHERE discount > 0 AND created_at >= ?", [$startDate]);

$paymentBreakdown = fetchAll("SELECT payment_method, COUNT(*) as cnt, SUM(total) as total FROM orders WHERE status != 'cancelled' AND created_at >= ? GROUP BY payment_method ORDER BY total DESC", [$startDate]);

$topProducts = fetchAll("SELECT p.name, SUM(oi.quantity) as units, SUM(oi.price * oi.quantity) as revenue FROM order_items oi JOIN products p ON oi.product_id=p.id JOIN orders o ON oi.order_id=o.id WHERE o.status != 'cancelled' AND o.created_at >= ? GROUP BY p.id ORDER BY revenue DESC LIMIT 5", [$startDate]);

$topCategories = fetchAll("SELECT c.name, SUM(oi.price * oi.quantity) as revenue FROM order_items oi JOIN products p ON oi.product_id=p.id JOIN categories c ON p.category_id=c.id JOIN orders o ON oi.order_id=o.id WHERE o.status != 'cancelled' AND o.created_at >= ? GROUP BY c.id ORDER BY revenue DESC LIMIT 5", [$startDate]);

$recentOrders = fetchAll("SELECT o.*, u.username FROM orders o LEFT JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC LIMIT 10");
$newOrdersToday = fetchAll("SELECT o.*, u.username FROM orders o LEFT JOIN users u ON o.user_id=u.id WHERE o.status='pending' AND o.created_at >= ? ORDER BY o.created_at DESC LIMIT 5", [$today]);
$lowStockProducts = fetchAll("SELECT * FROM products WHERE is_active=1 AND stock <= 10 ORDER BY stock ASC LIMIT 5");

$hourlySales = fetchAll("SELECT " . sqlHour('created_at') . " as hour, COUNT(*) as cnt FROM orders WHERE status != 'cancelled' AND created_at >= ? GROUP BY hour ORDER BY hour", [$startDate]);
$hourlyMap = array_fill(0, 24, 0);
foreach ($hourlySales as $h) $hourlyMap[(int)$h['hour']] = (int)$h['cnt'];
$maxHourly = max($hourlyMap) > 0 ? max($hourlyMap) : 1;

$dayOfWeek = fetchAll("SELECT " . sqlDayOfWeek('created_at') . " as day, SUM(total) as revenue FROM orders WHERE status != 'cancelled' AND created_at >= ? GROUP BY day ORDER BY day", [$startDate]);
$dayRevMap = array_fill(0, 7, 0);
foreach ($dayOfWeek as $d) $dayRevMap[(int)$d['day']] = (int)$d['revenue'];

$salesData = [];
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} days"));
    $dayRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND DATE(created_at)=?", [$date]);
    $dayOrders = count_rows("SELECT COUNT(*) FROM orders WHERE DATE(created_at)=?", [$date]);
    $salesData[] = ['date' => date('M d', strtotime($date)), 'revenue' => (int)$dayRevenue, 'orders' => (int)$dayOrders];
}

$recentActivity = fetchAll("SELECT 'order' as type, o.order_number as ref, o.status as detail, o.created_at as time FROM orders o WHERE o.created_at >= ? UNION ALL SELECT 'refund' as type, " . sqlCastAsText('rr.id') . " as ref, rr.status as detail, rr.created_at as time FROM refund_requests rr WHERE rr.created_at >= ? ORDER BY time DESC LIMIT 10", [date('Y-m-d H:i:s', strtotime('-7 days')), date('Y-m-d H:i:s', strtotime('-7 days'))]);

$totalStockValue = count_rows("SELECT COALESCE(SUM(p.price * p.stock),0) FROM products p WHERE p.is_active=1");

$repeatCustomers = count_rows("SELECT COUNT(*) FROM (SELECT user_id FROM orders WHERE user_id IS NOT NULL AND status != 'cancelled' AND created_at >= ? GROUP BY user_id HAVING COUNT(*) > 1)", [$startDate]);
$repeatRate = $totalCustomers > 0 ? round($repeatCustomers / $totalCustomers * 100) : 0;

$paymentLabels = json_encode(array_map(fn($p) => strtoupper($p['payment_method'] ?? 'N/A'), $paymentBreakdown));
$paymentTotals = json_encode(array_column($paymentBreakdown, 'total'));
$paymentCounts = json_encode(array_column($paymentBreakdown, 'cnt'));
$topProductNames = json_encode(array_map(fn($p) => (strlen($p['name']) > 15 ? substr($p['name'], 0, 15).'...' : $p['name']), $topProducts));
$topProductRevenues = json_encode(array_column($topProducts, 'revenue'));
$topCatLabels = json_encode(array_column($topCategories, 'name'));
$topCatRevenues = json_encode(array_column($topCategories, 'revenue'));
$salesDataJson = json_encode($salesData);
$dayNames = json_encode(['Sun','Mon','Tue','Wed','Thu','Fri','Sat']);
$dayRevJson = json_encode($dayRevMap);
$hourlyJson = json_encode($hourlyMap);
?>

<style>
.pipeline-stage{display:flex;align-items:center;gap:8px;padding:12px 16px;border-radius:12px;text-align:center;flex:1;min-width:0;position:relative;cursor:pointer;transition:transform .2s}
.pipeline-stage:hover{transform:translateY(-2px)}
.pipeline-stage .count{font-size:1.8rem;font-weight:700;line-height:1}
.pipeline-stage .label{font-size:.7rem;text-transform:uppercase;letter-spacing:1px;opacity:.9}
.pipeline-arrow{display:flex;align-items:center;font-size:1.2rem;color:#666}
.activity-item{padding:10px 14px;border-radius:10px;margin-bottom:8px;font-size:.85rem;display:flex;align-items:center;gap:10px;border-left:3px solid}
.activity-item.order{background:rgba(13,202,240,.08);border-color:#0dcaf0}
.activity-item.refund{background:rgba(220,53,69,.08);border-color:#dc3545}
.activity-item .time{font-size:.7rem;color:#999;margin-left:auto;white-space:nowrap}
.quick-action{padding:10px;border-radius:10px;text-align:center;text-decoration:none;color:inherit;border:1px solid rgba(255,255,255,.05);transition:all .2s;cursor:pointer}
.quick-action:hover{transform:translateY(-2px);border-color:var(--primary);color:var(--primary)}
.quick-action i{font-size:1.5rem;display:block;margin-bottom:6px}
.quick-action span{font-size:.75rem;display:block}
.heatmap-mini{display:grid;grid-template-columns:repeat(12,1fr);gap:3px}
.heatmap-cell{border-radius:3px;padding:4px 2px;text-align:center;font-size:.6rem}
.kpi-mini{text-align:center;padding:10px}
.kpi-mini .val{font-size:1.1rem;font-weight:700}
.kpi-mini .lbl{font-size:.7rem;color:#999}
</style>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">Dashboard</h4>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-sm btn-outline-secondary"><i class="fas fa-print"></i> PDF</button>
        <button onclick="exportCSV()" class="btn btn-sm btn-outline-success"><i class="fas fa-file-csv"></i> CSV</button>
    </div>
</div>

<div class="mb-3 d-flex align-items-center gap-2 flex-wrap">
    <button onclick="filterDashboard('today')" class="btn btn-sm filter-btn <?= $period=='today'?'btn-primary':'btn-outline-primary' ?>" data-period="today">Today</button>
    <button onclick="filterDashboard('week')" class="btn btn-sm filter-btn <?= $period=='week'?'btn-primary':'btn-outline-primary' ?>" data-period="week">This Week</button>
    <button onclick="filterDashboard('month')" class="btn btn-sm filter-btn <?= $period=='month'?'btn-primary':'btn-outline-primary' ?>" data-period="month">This Month</button>
    <button onclick="filterDashboard('year')" class="btn btn-sm filter-btn <?= $period=='year'?'btn-primary':'btn-outline-primary' ?>" data-period="year">This Year</button>
    <span class="text-muted ms-2">|</span>
    <span id="badge-orders-change" class="badge bg-secondary">Loading...</span>
    <span id="badge-revenue-change" class="badge bg-secondary" style="display:none"></span>
    <span id="badge-wow" class="badge" style="display:none"></span>
</div>

<?php if ($targetAmount > 0): ?>
<div class="card card-custom mb-4 p-3">
    <div class="d-flex justify-content-between align-items-center mb-2">
        <span class="fw-bold"><i class="fas fa-bullseye text-primary"></i> Monthly Target: <?= formatPrice($targetAmount) ?></span>
        <span class="fw-bold <?= $targetProgress >= 100 ? 'text-success' : ($targetProgress >= 50 ? 'text-primary' : 'text-warning') ?>"><?= number_format($targetProgress, 1) ?>%</span>
    </div>
    <div class="progress" style="height:20px;border-radius:10px;">
        <div class="progress-bar <?= $targetProgress >= 100 ? 'bg-success' : ($targetProgress >= 50 ? 'bg-primary' : 'bg-warning') ?>" style="width:<?= min($targetProgress, 100) ?>%"><?= formatPrice($totalRevenue) ?> / <?= formatPrice($targetAmount) ?></div>
    </div>
</div>
<?php endif; ?>

<div class="stats-grid mb-4">
    <div class="stat-card stat-blue" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#0d6efd"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-blue"><i class="fas fa-shopping-cart"></i></div>
            <div class="stat-info">
                <p class="stat-label">Total Orders</p>
                <h3 class="stat-value counter-value" id="s-totalOrders" data-target="<?= $totalOrders ?>"><?= $totalOrders ?></h3>
            </div>
        </div>
    </div>
    <div class="stat-card stat-green" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#198754"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-green"><i class="fas fa-dollar-sign"></i></div>
            <div class="stat-info">
                <p class="stat-label">Revenue</p>
                <h3 class="stat-value" id="s-totalRevenue" title="<?= formatPrice($totalRevenue) ?>"><?= formatPrice($totalRevenue) ?></h3>
            </div>
        </div>
    </div>
    <div class="stat-card stat-amber" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#ffc107"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-amber"><i class="fas fa-clock"></i></div>
            <div class="stat-info">
                <p class="stat-label">Pending</p>
                <h3 class="stat-value counter-value" id="s-pendingOrders" data-target="<?= $pendingOrders ?>"><?= $pendingOrders ?></h3>
            </div>
        </div>
    </div>
    <div class="stat-card stat-cyan" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#0dcaf0"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-cyan"><i class="fas fa-check-circle"></i></div>
            <div class="stat-info">
                <p class="stat-label">Delivered</p>
                <h3 class="stat-value counter-value" id="s-deliveredOrders" data-target="<?= $deliveredOrders ?>"><?= $deliveredOrders ?></h3>
            </div>
        </div>
    </div>
    <div class="stat-card stat-red" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#dc3545"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-red"><i class="fas fa-times-circle"></i></div>
            <div class="stat-info">
                <p class="stat-label">Cancelled</p>
                <h3 class="stat-value" id="s-cancelledOrders"><?= $cancelledOrders ?></h3>
            </div>
        </div>
    </div>
    <div class="stat-card stat-purple" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#6f42c1"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-purple"><i class="fas fa-box"></i></div>
            <div class="stat-info">
                <p class="stat-label">Products</p>
                <h3 class="stat-value counter-value" id="s-totalProducts" data-target="<?= $totalProducts ?>"><?= $totalProducts ?></h3>
            </div>
        </div>
    </div>
</div>
<div class="stats-grid mb-4">
    <div class="stat-card stat-green" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#198754"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-green"><i class="fas fa-users"></i></div>
            <div class="stat-info">
                <p class="stat-label">Customers</p>
                <h3 class="stat-value counter-value" id="s-totalCustomers" data-target="<?= $totalCustomers ?>"><?= $totalCustomers ?></h3>
            </div>
        </div>
    </div>
    <div class="stat-card stat-cyan" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#0dcaf0"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-cyan"><i class="fas fa-receipt"></i></div>
            <div class="stat-info">
                <p class="stat-label">Avg Order</p>
                <h3 class="stat-value" id="s-avgOrderValue" title="<?= formatPrice($avgOrderValue) ?>"><?= formatPrice($avgOrderValue) ?></h3>
            </div>
        </div>
    </div>
    <div class="stat-card stat-green" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#198754"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-green"><i class="fas fa-warehouse"></i></div>
            <div class="stat-info">
                <p class="stat-label">Stock Value</p>
                <h3 class="stat-value" id="s-totalStockValue" title="<?= formatPrice($totalStockValue) ?>"><?= formatPrice($totalStockValue) ?></h3>
            </div>
        </div>
    </div>
    <div class="stat-card stat-blue" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#0d6efd"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-blue"><i class="fas fa-redo"></i></div>
            <div class="stat-info">
                <p class="stat-label">Repeat Rate</p>
                <h3 class="stat-value" id="s-repeatRate"><?= $repeatRate ?>%</h3>
                <p class="stat-sub" id="s-repeatSub"><?= $repeatCustomers ?>/<?= $totalCustomers ?></p>
            </div>
        </div>
    </div>
    <div class="stat-card stat-red" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#dc3545"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-red"><i class="fas fa-undo"></i></div>
            <div class="stat-info">
                <p class="stat-label">Refund Rate</p>
                <h3 class="stat-value <?= $refundRate > 5 ? 'text-danger' : 'text-success' ?>" id="s-refundRate"><?= $refundRate ?>%</h3>
            </div>
        </div>
    </div>
    <div class="stat-card stat-amber" onclick="statRipple(this,event)">
        <div class="stat-dot" style="background:#ffc107"></div>
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon icon-amber"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="stat-info">
                <p class="stat-label">Low Stock</p>
                <h3 class="stat-value <?= $lowStockCount > 0 ? 'text-danger' : 'text-warning' ?>" id="s-lowStock"><?= $lowStockCount ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="card card-custom mb-4 p-3" id="pipeline-section">
    <h6 class="mb-3"><i class="fas fa-stream text-primary"></i> Order Pipeline</h6>
    <div class="d-flex gap-2 align-items-center flex-wrap">
        <div class="pipeline-stage" style="background:linear-gradient(135deg,#ffc107,#ff9800);color:#000;border-radius:12px">
            <div><div class="count" id="p-pending"><?= $pendingOrders ?></div><div class="label">Pending</div></div>
        </div>
        <div class="pipeline-arrow"><i class="fas fa-arrow-right"></i></div>
        <div class="pipeline-stage" style="background:linear-gradient(135deg,#0dcaf0,#0d6efd);color:#fff;border-radius:12px">
            <div><div class="count" id="p-confirmed"><?= $confirmedOrders ?></div><div class="label">Confirmed</div></div>
        </div>
        <div class="pipeline-arrow"><i class="fas fa-arrow-right"></i></div>
        <div class="pipeline-stage" style="background:linear-gradient(135deg,#6f42c1,#5a32a3);color:#fff;border-radius:12px">
            <div><div class="count" id="p-shipped"><?= $shippedOrders ?></div><div class="label">Shipped</div></div>
        </div>
        <div class="pipeline-arrow"><i class="fas fa-arrow-right"></i></div>
        <div class="pipeline-stage" style="background:linear-gradient(135deg,#198754,#157347);color:#fff;border-radius:12px">
            <div><div class="count" id="p-delivered"><?= $deliveredOrders ?></div><div class="label">Delivered</div></div>
        </div>
        <div class="pipeline-arrow"><i class="fas fa-arrow-right text-danger"></i></div>
        <div class="pipeline-stage" style="background:linear-gradient(135deg,#dc3545,#b02a37);color:#fff;border-radius:12px">
            <div><div class="count" id="p-cancelled"><?= $cancelledOrders ?></div><div class="label">Cancelled</div></div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-xl-8">
        <div class="card card-custom">
            <div class="card-header"><h6>Sales Trend (30 Days)</h6></div>
            <div class="card-body"><canvas id="salesChart" height="90"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Payment Methods</h6></div>
            <div class="card-body d-flex justify-content-center"><canvas id="paymentPie" height="180"></canvas></div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Hourly Sales</h6></div>
            <div class="card-body">
                <div class="heatmap-mini" id="hourlyHeatmap"></div>
                <div class="d-flex justify-content-between mt-2" style="font-size:.65rem;color:#666"><span>12AM</span><span>6AM</span><span>12PM</span><span>6PM</span></div>
            </div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Sales by Day</h6></div>
            <div class="card-body"><canvas id="dayChart" height="140"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Top 5 Products</h6></div>
            <div class="card-body"><canvas id="productBar" height="140"></canvas></div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Category Performance</h6></div>
            <div class="card-body"><canvas id="catBar" height="140"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Quick Actions</h6></div>
            <div class="card-body">
                <div class="row g-2">
                    <div class="col-4"><a href="<?= SITE_URL ?>/admin/orders.php?status=pending" class="quick-action bg-warning bg-opacity-10"><i class="fas fa-clock text-warning"></i><span>Pending Orders</span></a></div>
                    <div class="col-4"><a href="<?= SITE_URL ?>/admin/products.php" class="quick-action bg-primary bg-opacity-10"><i class="fas fa-plus text-primary"></i><span>Add Product</span></a></div>
                    <div class="col-4"><a href="<?= SITE_URL ?>/admin/flash_sales.php" class="quick-action bg-danger bg-opacity-10"><i class="fas fa-bolt text-danger"></i><span>Flash Sale</span></a></div>
                    <div class="col-4"><a href="<?= SITE_URL ?>/admin/coupons.php" class="quick-action bg-success bg-opacity-10"><i class="fas fa-ticket-alt text-success"></i><span>New Coupon</span></a></div>
                    <div class="col-4"><a href="<?= SITE_URL ?>/admin/push_notifications.php" class="quick-action bg-info bg-opacity-10"><i class="fas fa-bell text-info"></i><span>Send Alert</span></a></div>
                    <div class="col-4"><a href="<?= SITE_URL ?>/admin/inventory.php" class="quick-action bg-purple bg-opacity-10" style="background:rgba(111,66,193,.1)"><i class="fas fa-warehouse" style="color:#6f42c1"></i><span>Inventory</span></a></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Activity Feed</h6></div>
            <div class="card-body" style="max-height:240px;overflow-y:auto;">
                <?php if (!empty($recentActivity)): ?>
                <?php foreach ($recentActivity as $a): ?>
                <div class="activity-item <?= $a['type'] ?>">
                    <i class="fas fa-<?= $a['type'] == 'order' ? 'shopping-cart text-info' : 'undo text-danger' ?>"></i>
                    <div>
                        <strong>#<?= htmlspecialchars($a['ref']) ?></strong>
                        <span class="badge badge-<?= $a['detail'] ?> ms-1" style="font-size:.65rem"><?= ucfirst($a['detail']) ?></span>
                    </div>
                    <span class="time"><?= date('M d H:i', strtotime($a['time'])) ?></span>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <p class="text-muted text-center">No recent activity</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if ($overdueOrders > 0): ?>
<div class="card border-warning mb-4">
    <div class="card-body d-flex align-items-center gap-3">
        <div class="bg-warning rounded-circle d-flex align-items-center justify-content-center" style="width:50px;height:50px"><i class="fas fa-exclamation-triangle text-dark" style="font-size:1.3rem"></i></div>
        <div>
            <strong class="text-warning"><?= $overdueOrders ?> Overdue Orders</strong>
            <p class="mb-0 text-muted" style="font-size:.85rem">Orders stuck in pending/confirmed for over 3 days</p>
        </div>
        <a href="<?= SITE_URL ?>/admin/orders.php" class="btn btn-warning btn-sm ms-auto">Review Now</a>
    </div>
</div>
<?php endif; ?>

<div class="row g-3 mb-4">
    <div class="col-xl-8">
        <div class="card card-custom">
            <div class="card-header d-flex justify-content-between">
                <h6>Recent Orders</h6>
                <a href="<?= SITE_URL ?>/admin/orders.php" class="text-decoration-none">View All</a>
            </div>
            <div class="card-body table-responsive">
                <table class="table table-custom" id="recentOrdersTable">
                    <thead><tr><th>Order #</th><th>Customer</th><th>Status</th><th>Payment</th><th>Total</th><th>Date</th><th>Action</th></tr></thead>
                    <tbody id="recentOrdersBody">
                        <?php foreach ($recentOrders as $o): ?>
                        <tr>
                            <td><a href="<?= SITE_URL ?>/admin/orders.php">#<?= $o['order_number'] ?></a></td>
                            <td><?= htmlspecialchars($o['username'] ?? 'Guest') ?></td>
                            <td><span class="badge badge-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
                            <td><span class="badge badge-<?= $o['payment_status'] ?? 'pending' ?>"><?= ucfirst($o['payment_status'] ?? 'pending') ?></span></td>
                            <td><?= formatPrice($o['total']) ?></td>
                            <td><?= date('M d, H:i', strtotime($o['created_at'])) ?></td>
                            <td>
                                <?php if ($o['status'] == 'pending'): ?>
                                <form method="POST" action="<?= SITE_URL ?>/admin/orders.php" style="display:inline" onsubmit="return confirm('Confirm this order?')">
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                    <input type="hidden" name="status" value="confirmed">
                                    <button class="btn btn-sm btn-outline-success" title="Confirm"><i class="fas fa-check"></i></button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card card-custom mb-3">
            <div class="card-header d-flex justify-content-between">
                <h6>New Order Alerts</h6>
                <a href="<?= SITE_URL ?>/admin/orders.php" class="text-decoration-none">View All</a>
            </div>
            <div class="card-body" style="max-height:180px;overflow-y:auto;" id="newOrdersBody">
                <?php if (!empty($newOrdersToday)): ?>
                <?php foreach ($newOrdersToday as $o): ?>
                <div class="d-flex justify-content-between align-items-center mb-2 p-2 bg-warning bg-opacity-10 rounded alert-pulse">
                    <div><strong>#<?= $o['order_number'] ?></strong><br><small><?= htmlspecialchars($o['username'] ?? 'Guest') ?> - <?= formatPrice($o['total']) ?></small></div>
                    <a href="<?= SITE_URL ?>/admin/orders.php" class="btn btn-sm btn-outline-primary">View</a>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <p class="text-muted text-center">No new orders</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="card card-custom">
            <div class="card-header d-flex justify-content-between">
                <h6>Low Stock</h6>
                <a href="<?= SITE_URL ?>/admin/inventory.php" class="text-decoration-none">View All</a>
            </div>
            <div class="card-body" style="max-height:180px;overflow-y:auto;">
                <?php if (!empty($lowStockProducts)): ?>
                <?php foreach ($lowStockProducts as $p): ?>
                <div class="d-flex justify-content-between align-items-center mb-2 p-2 bg-danger bg-opacity-10 rounded">
                    <div><strong><?= htmlspecialchars(substr($p['name'], 0, 25)) ?></strong><br><small class="text-danger">Stock: <?= $p['stock'] ?></small></div>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <p class="text-muted text-center">All stocked</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-xl-6">
        <div class="card card-custom p-3">
            <h6 class="mb-3"><i class="fas fa-chart-pie text-primary"></i> Summary</h6>
            <div class="row g-3">
                <div class="col-4 kpi-mini"><div class="val text-success" id="sum-revenue"><?= formatPrice($totalRevenue) ?></div><div class="lbl">Revenue</div></div>
                <div class="col-4 kpi-mini"><div class="val text-info" id="sum-orders"><?= $totalOrders ?></div><div class="lbl">Orders</div></div>
                <div class="col-4 kpi-mini"><div class="val text-primary" id="sum-avg"><?= formatPrice($avgOrderValue) ?></div><div class="lbl">Avg Order</div></div>
                <div class="col-4 kpi-mini"><div class="val text-warning" id="sum-coupon"><?= $couponUsed ?></div><div class="lbl">Coupon Used</div></div>
                <div class="col-4 kpi-mini"><div class="val text-danger" id="sum-discount"><?= formatPrice($couponRevenue) ?></div><div class="lbl">Discount Given</div></div>
                <div class="col-4 kpi-mini"><div class="val text-success" id="sum-newcust"><?= $newCustomers ?></div><div class="lbl">New Customers</div></div>
            </div>
        </div>
    </div>
    <div class="col-xl-6">
        <div class="card card-custom p-3">
            <h6 class="mb-3"><i class="fas fa-trophy text-warning"></i> Top Sellers</h6>
            <?php if (!empty($topProducts)): ?>
            <?php foreach ($topProducts as $i => $tp): ?>
            <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-<?= ['primary','success','warning','info','danger'][$i] ?>"><?= $i+1 ?></span>
                    <span><?= htmlspecialchars($tp['name']) ?></span>
                </div>
                <span class="fw-bold"><?= formatPrice($tp['revenue']) ?></span>
            </div>
            <?php endforeach; ?>
            <?php else: ?>
            <p class="text-muted text-center">No sales yet</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="<?= SITE_URL ?>/assets/js/chart.umd.min.js"></script>
<script>
const pieColors = ['#e94560','#0d6efd','#198754','#ffc107','#6f42c1','#0dcaf0'];
let salesChart, paymentPie, dayChart, productBar, catBar;
let currentPeriod = '<?= $period ?>';

function initCharts(d) {
    const c = d.charts;
    if (salesChart) salesChart.destroy();
    salesChart = new Chart(document.getElementById('salesChart'), {type:'line',data:{labels:c.salesData.map(x=>x.date),datasets:[{label:'Revenue',data:c.salesData.map(x=>x.revenue),borderColor:'#e94560',backgroundColor:'rgba(233,69,96,0.08)',fill:true,tension:0.4,pointRadius:2},{label:'Orders',data:c.salesData.map(x=>x.orders),borderColor:'#0d6efd',backgroundColor:'rgba(13,110,253,0.08)',fill:true,tension:0.4,pointRadius:2,yAxisID:'y1'}]},options:{responsive:true,plugins:{legend:{position:'bottom',labels:{boxWidth:12}}},scales:{y:{beginAtZero:true,position:'left'},y1:{beginAtZero:true,position:'right',grid:{drawOnChartArea:false}}}}});

    if (paymentPie) paymentPie.destroy();
    paymentPie = new Chart(document.getElementById('paymentPie'), {type:'pie',data:{labels:c.paymentLabels,datasets:[{data:c.paymentTotals,backgroundColor:pieColors}]},options:{responsive:true,plugins:{legend:{position:'bottom',labels:{boxWidth:12,padding:6}}}}});

    const hGrid = document.getElementById('hourlyHeatmap');
    hGrid.innerHTML = '';
    c.hourlyMap.forEach((v,i) => {
        const el = document.createElement('div');
        const pct = c.maxHourly > 0 ? v/c.maxHourly : 0;
        el.className = 'heatmap-cell';
        el.style.cssText = 'background:rgba(233,69,96,'+(0.1+pct*0.9)+');color:'+(pct>0.5?'#fff':'#333')+';';
        el.innerHTML = '<div class="fw-bold">'+i+'</div><div>'+v+'</div>';
        hGrid.appendChild(el);
    });

    if (dayChart) dayChart.destroy();
    dayChart = new Chart(document.getElementById('dayChart'), {type:'bar',data:{labels:c.dayNames,datasets:[{label:'Revenue',data:c.dayRevMap,backgroundColor:pieColors,borderRadius:6}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});

    if (productBar) productBar.destroy();
    productBar = new Chart(document.getElementById('productBar'), {type:'bar',data:{labels:c.topProductNames,datasets:[{label:'Revenue',data:c.topProductRevenues,backgroundColor:'#e94560',borderRadius:6}]},options:{indexAxis:'y',responsive:true,plugins:{legend:{display:false}},scales:{x:{beginAtZero:true}}}});

    if (catBar) catBar.destroy();
    catBar = new Chart(document.getElementById('catBar'), {type:'bar',data:{labels:c.topCatLabels,datasets:[{label:'Revenue',data:c.topCatRevenues,backgroundColor:pieColors,borderRadius:6}]},options:{indexAxis:'y',responsive:true,plugins:{legend:{display:false}},scales:{x:{beginAtZero:true}}}});
}

function animateValue(el, target) {
    let cur = 0;
    let step = Math.max(1, Math.ceil(target / 30));
    el.setAttribute('data-target', target);
    const t = setInterval(() => { cur += step; if (cur >= target) { cur = target; clearInterval(t); } el.textContent = cur.toLocaleString(); }, 25);
}

function filterDashboard(period) {
    if (period === currentPeriod) return;
    currentPeriod = period;

    document.querySelectorAll('.filter-btn').forEach(b => {
        b.className = 'btn btn-sm filter-btn ' + (b.dataset.period === period ? 'btn-primary' : 'btn-outline-primary');
    });

    document.getElementById('badge-orders-change').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';

    fetch('<?= SITE_URL ?>/api/dashboard_data.php?period=' + period)
        .then(r => r.json())
        .then(d => {
            const c = d.cards;

            animateValue(document.getElementById('s-totalOrders'), c.totalOrders);
            document.getElementById('s-totalRevenue').textContent = c.totalRevenue;
            document.getElementById('s-totalRevenue').title = c.totalRevenue;
            animateValue(document.getElementById('s-pendingOrders'), c.pendingOrders);
            animateValue(document.getElementById('s-deliveredOrders'), c.deliveredOrders);
            document.getElementById('s-cancelledOrders').textContent = c.cancelledOrders;
            animateValue(document.getElementById('s-totalProducts'), c.totalProducts);
            animateValue(document.getElementById('s-totalCustomers'), c.totalCustomers);
            document.getElementById('s-avgOrderValue').textContent = c.avgOrderValue;
            document.getElementById('s-avgOrderValue').title = c.avgOrderValue;
            document.getElementById('s-totalStockValue').textContent = c.totalStockValue;
            document.getElementById('s-repeatRate').textContent = c.repeatRate + '%';
            document.getElementById('s-repeatSub').textContent = c.repeatCustomers + '/' + c.allCustomers;
            document.getElementById('s-refundRate').textContent = c.refundRate + '%';
            document.getElementById('s-refundRate').className = 'stat-value ' + (c.refundRate > 5 ? 'text-danger' : 'text-success');
            document.getElementById('s-lowStock').textContent = c.lowStockCount;

            const b = d.badges;
            let obHtml = '';
            if (b.ordersChange > 0) obHtml = '<i class="fas fa-arrow-up"></i> ' + b.ordersChange + ' orders vs yesterday';
            else if (b.ordersChange < 0) obHtml = '<i class="fas fa-arrow-down"></i> ' + Math.abs(b.ordersChange) + ' fewer';
            else obHtml = 'Same as yesterday';
            const obClass = b.ordersChange > 0 ? 'bg-success' : (b.ordersChange < 0 ? 'bg-danger' : 'bg-secondary');
            document.getElementById('badge-orders-change').className = 'badge ' + obClass;
            document.getElementById('badge-orders-change').innerHTML = obHtml;

            if (b.revenueChange > 0 || b.revenueChangeDir === 'down') {
                const rcEl = document.getElementById('badge-revenue-change');
                rcEl.style.display = '';
                rcEl.className = 'badge ' + (b.revenueChangeDir === 'up' ? 'bg-success' : 'bg-danger');
                rcEl.innerHTML = '<i class="fas fa-arrow-' + b.revenueChangeDir + '"></i> ' + b.revenueChange + (b.revenueChangeDir === 'up' ? ' more' : ' less');
            }
            if (b.wowRevenue != 0) {
                const wEl = document.getElementById('badge-wow');
                wEl.style.display = '';
                wEl.className = 'badge ' + (b.wowRevenue > 0 ? 'bg-success' : 'bg-danger');
                wEl.innerHTML = '<i class="fas fa-chart-line"></i> WoW ' + (b.wowRevenue > 0 ? '+' : '') + b.wowRevenue + '%';
            }

            const p = d.pipeline;
            document.getElementById('p-pending').textContent = p.pending;
            document.getElementById('p-confirmed').textContent = p.confirmed;
            document.getElementById('p-shipped').textContent = p.shipped;
            document.getElementById('p-delivered').textContent = p.delivered;
            document.getElementById('p-cancelled').textContent = p.cancelled;

            document.getElementById('sum-revenue').textContent = c.totalRevenue;
            document.getElementById('sum-orders').textContent = c.totalOrders;
            document.getElementById('sum-avg').textContent = c.avgOrderValue;
            document.getElementById('sum-coupon').textContent = d.summary.couponUsed;
            document.getElementById('sum-discount').textContent = d.summary.couponRevenue;
            document.getElementById('sum-newcust').textContent = d.summary.newCustomers;

            let orderRows = '';
            d.recentOrders.forEach(o => {
                orderRows += '<tr><td><a href="<?= SITE_URL ?>/admin/orders.php">#' + o.order_number + '</a></td><td>' + o.username + '</td><td><span class="badge badge-' + o.status + '">' + o.status.charAt(0).toUpperCase() + o.status.slice(1) + '</span></td><td><span class="badge badge-' + o.payment_status + '">' + o.payment_status.charAt(0).toUpperCase() + o.payment_status.slice(1) + '</span></td><td>' + o.total + '</td><td>' + o.date + '</td><td>' + (o.is_pending ? '<form method="POST" action="<?= SITE_URL ?>/admin/orders.php" style="display:inline"><input type="hidden" name="action" value="update_status"><input type="hidden" name="order_id" value="' + o.id + '"><input type="hidden" name="status" value="confirmed"><button class="btn btn-sm btn-outline-success" title="Confirm"><i class="fas fa-check"></i></button></form>' : '') + '</td></tr>';
            });
            document.getElementById('recentOrdersBody').innerHTML = orderRows || '<tr><td colspan="7" class="text-center text-muted">No orders in this period</td></tr>';

            let newHtml = '';
            if (d.newOrders.length > 0) {
                d.newOrders.forEach(o => {
                    newHtml += '<div class="d-flex justify-content-between align-items-center mb-2 p-2 bg-warning bg-opacity-10 rounded alert-pulse"><div><strong>#' + o.order_number + '</strong><br><small>' + o.username + ' - ' + o.total + '</small></div><a href="<?= SITE_URL ?>/admin/orders.php" class="btn btn-sm btn-outline-primary">View</a></div>';
                });
            } else {
                newHtml = '<p class="text-muted text-center">No new orders</p>';
            }
            document.getElementById('newOrdersBody').innerHTML = newHtml;

            initCharts(d);
        })
        .catch(err => {
            document.getElementById('badge-orders-change').innerHTML = 'Error loading data';
            console.error(err);
        });
}

initCharts({charts:{salesData:<?= $salesDataJson ?>,paymentLabels:<?= $paymentLabels ?>,paymentTotals:<?= $paymentTotals ?>,hourlyMap:<?= $hourlyJson ?>,maxHourly:<?= $maxHourly ?>,dayNames:<?= $dayNames ?>,dayRevMap:<?= $dayRevJson ?>,topProductNames:<?= $topProductNames ?>,topProductRevenues:<?= $topProductRevenues ?>,topCatLabels:<?= $topCatLabels ?>,topCatRevenues:<?= $topCatRevenues ?>}});

document.querySelectorAll('.counter-value').forEach(el => {
    let target = parseInt(el.getAttribute('data-target'));
    if (!target) return;
    animateValue(el, target);
});

function exportCSV() {
    var rows = [['Order #','Customer','Status','Payment','Total','Date']];
    document.querySelectorAll('#recentOrdersTable tbody tr').forEach(function(tr) {
        var cells = tr.querySelectorAll('td');
        if (cells.length >= 6) rows.push([cells[0].textContent.trim(),cells[1].textContent.trim(),cells[2].textContent.trim(),cells[3].textContent.trim(),cells[4].textContent.trim(),cells[5].textContent.trim()]);
    });
    var csv = rows.map(r => r.map(c => '"'+c.replace(/"/g,'""')+'"').join(',')).join('\n');
    var blob = new Blob([csv],{type:'text/csv'});
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'dashboard_export.csv'; a.click();
}

function statRipple(el, e) {
    var r = document.createElement('span');
    r.className = 'stat-ripple';
    var rect = el.getBoundingClientRect();
    r.style.left = (e.clientX - rect.left - 25) + 'px';
    r.style.top = (e.clientY - rect.top - 25) + 'px';
    el.appendChild(r);
    r.classList.add('active');
    setTimeout(function() { r.remove(); }, 600);
}
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
