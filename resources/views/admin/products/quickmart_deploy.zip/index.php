<?php
header("Location: store/");
exit;
