<?php
$pageTitle = 'Flash Sales';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM flash_sales WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/flash_sales.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [$_POST['name'], (float)$_POST['discount_percent'], $_POST['start_date'], $_POST['end_date']];
    if ($id) { query("UPDATE flash_sales SET name=?, discount_percent=?, start_date=?, end_date=? WHERE id=?", array_merge($data, [$id])); }
    else { $id = insertId("INSERT INTO flash_sales (name, discount_percent, start_date, end_date) VALUES (?,?,?,?)", $data); }
    query("DELETE FROM flash_sale_products WHERE flash_sale_id=?", [$id]);
    if (!empty($_POST['product_ids'])) {
        foreach ($_POST['product_ids'] as $pid) {
            $salePrice = (float)($_POST['sale_prices'][$pid] ?? 0);
            if ($salePrice > 0) query("INSERT INTO flash_sale_products (flash_sale_id, product_id, sale_price) VALUES (?,?,?)", [$id, $pid, $salePrice]);
        }
    }
    setAlert('success', 'Flash sale saved!'); redirect(SITE_URL . '/admin/flash_sales.php');
}
$sales = fetchAll("SELECT fs.*, COUNT(fsp.id) as product_count FROM flash_sales fs LEFT JOIN flash_sale_products fsp ON fs.id=fsp.flash_sale_id GROUP BY fs.id ORDER BY fs.start_date DESC");
$products = fetchAll("SELECT id, name, price FROM products WHERE is_active=1 ORDER BY name");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Flash Sales (<?= count($sales) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_name').value='';document.getElementById('f_disc').value='';document.getElementById('f_start').value='';document.getElementById('f_end').value='';document.getElementById('modalTitle').textContent='Add Flash Sale';">
        <i class="fas fa-plus"></i> Add Sale
    </button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>Name</th><th>Discount</th><th>Start</th><th>End</th><th>Products</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($sales as $s): ?>
<tr><td><strong><?= htmlspecialchars($s['name']) ?></strong></td><td><span class="badge bg-danger"><?= $s['discount_percent'] ?>% OFF</span></td><td><?= $s['start_date'] ?></td><td><?= $s['end_date'] ?></td><td><?= $s['product_count'] ?></td>
<td><a href="?delete=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Flash Sale</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" id="f_name" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Discount %</label><input type="number" name="discount_percent" id="f_disc" class="form-control" required></div>
<div class="row g-3 mb-3"><div class="col-6"><label class="form-label">Start Date</label><input type="datetime-local" name="start_date" id="f_start" class="form-control" required></div>
<div class="col-6"><label class="form-label">End Date</label><input type="datetime-local" name="end_date" id="f_end" class="form-control" required></div></div>
<div class="mb-3"><label class="form-label">Products & Sale Prices</label>
<div style="max-height:200px;overflow-y:auto"><?php foreach ($products as $p): ?>
<div class="d-flex align-items-center gap-2 mb-1">
<label class="form-check"><input type="checkbox" name="product_ids[]" value="<?= $p['id'] ?>" class="form-check-input"></label>
<span class="small flex-grow-1"><?= htmlspecialchars($p['name']) ?> (<?= formatPrice($p['price']) ?>)</span>
<input type="number" name="sale_prices[<?= $p['id'] ?>]" class="form-control form-control-sm" style="width:120px" placeholder="Sale price">
</div><?php endforeach; ?></div></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
