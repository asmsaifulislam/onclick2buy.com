<?php
$pageTitle = 'Store Locations - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
$locations = fetchAll("SELECT * FROM store_locations WHERE is_active=1 ORDER BY name");
?>
<h2 class="mb-4"><i class="fas fa-map-marker-alt"></i> Our Stores</h2>
<div class="row g-4">
    <?php foreach ($locations as $loc): ?>
    <div class="col-md-4">
        <div class="card card-custom p-4 h-100">
            <h5><i class="fas fa-store text-primary"></i> <?= htmlspecialchars($loc['name']) ?></h5>
            <p class="mb-1"><i class="fas fa-map-marker-alt text-danger"></i> <?= htmlspecialchars($loc['address']) ?></p>
            <p class="mb-1"><i class="fas fa-phone text-success"></i> <?= htmlspecialchars($loc['phone']) ?></p>
            <p class="mb-1"><i class="fas fa-clock text-info"></i> <?= htmlspecialchars($loc['hours']) ?></p>
            <?php if ($loc['latitude'] && $loc['longitude']): ?>
            <a href="https://www.google.com/maps?q=<?= $loc['latitude'] ?>,<?= $loc['longitude'] ?>" target="_blank" class="btn btn-sm btn-outline-primary mt-2"><i class="fas fa-directions"></i> Get Directions</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<div class="card card-custom p-4 mt-4">
    <h5><i class="fas fa-map"></i> Store Map</h5>
    <div style="width:100%;height:400px;border-radius:12px;overflow:hidden;background:#e2e8f0">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d58941.81915394527!2d90.35!3d23.78!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8b33cffc3fb%3A0x4a826f471c5c236b!2sDhaka!5e0!3m2!1sen!2sbd!4v1" width="100%" height="400" style="border:0" allowfullscreen="" loading="lazy"></iframe>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
