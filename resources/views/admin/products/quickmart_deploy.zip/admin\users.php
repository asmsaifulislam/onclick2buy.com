<?php
$pageTitle = 'User Control Panel';
require_once __DIR__ . '/../includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_user'])) {
        $userId = (int)$_POST['user_id'];
        $role = $_POST['role'];
        $isActive = (int)$_POST['is_active'];
        query("UPDATE users SET role=?, is_active=? WHERE id=?", [$role, $isActive, $userId]);
        setAlert('success', 'User updated!');
        redirect(SITE_URL . '/admin/users.php');
    }
    if (isset($_POST['toggle_ban'])) {
        $userId = (int)$_POST['user_id'];
        $current = fetch("SELECT is_active FROM users WHERE id=?", [$userId]);
        $newStatus = ($current && $current['is_active'] == 1) ? 0 : 1;
        query("UPDATE users SET is_active=? WHERE id=?", [$newStatus, $userId]);
        setAlert('success', $newStatus ? 'User unbanned.' : 'User banned.');
        redirect(SITE_URL . '/admin/users.php');
    }
    if (isset($_POST['delete_user'])) {
        $userId = (int)$_POST['user_id'];
        query("DELETE FROM users WHERE id=?", [$userId]);
        query("DELETE FROM staff_roles WHERE user_id=?", [$userId]);
        setAlert('success', 'User deleted.');
        redirect(SITE_URL . '/admin/users.php');
    }
}

$search = $_GET['search'] ?? '';
$roleFilter = $_GET['role'] ?? '';
$where = "WHERE 1=1";
$params = [];
if ($search) { $where .= " AND (username LIKE ? OR email LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($roleFilter) { $where .= " AND role=?"; $params[] = $roleFilter; }

$users = fetchAll("SELECT * FROM users $where ORDER BY created_at DESC", $params);
$totalUsers = count_rows("SELECT COUNT(*) FROM users");
$activeUsers = count_rows("SELECT COUNT(*) FROM users WHERE is_active=1");
$bannedUsers = count_rows("SELECT COUNT(*) FROM users WHERE is_active=0");
$staffCount = count_rows("SELECT COUNT(*) FROM users WHERE is_staff=1");
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0 fw-bold">User Control Panel</h4>
    <form class="d-flex gap-2 flex-wrap" method="GET">
        <input type="text" name="search" class="form-control form-control-sm" placeholder="Search username/email..." value="<?= htmlspecialchars($search) ?>" style="width:220px;">
        <select name="role" class="form-select form-select-sm" style="width:140px;" onchange="this.form.submit()">
            <option value="">All Roles</option>
            <option value="super_admin" <?= $roleFilter=='super_admin'?'selected':'' ?>>Super Admin</option>
            <option value="admin" <?= $roleFilter=='admin'?'selected':'' ?>>Admin</option>
            <option value="staff" <?= $roleFilter=='staff'?'selected':'' ?>>Staff</option>
            <option value="customer" <?= $roleFilter=='customer'?'selected':'' ?>>Customer</option>
        </select>
        <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-search"></i></button>
    </form>
</div>

<div class="row mb-4">
    <div class="col-md-3"><div class="card card-custom text-center p-3"><h5 class="text-primary mb-0"><?= $totalUsers ?></h5><small class="text-muted">Total Users</small></div></div>
    <div class="col-md-3"><div class="card card-custom text-center p-3"><h5 class="text-success mb-0"><?= $activeUsers ?></h5><small class="text-muted">Active</small></div></div>
    <div class="col-md-3"><div class="card card-custom text-center p-3"><h5 class="text-danger mb-0"><?= $bannedUsers ?></h5><small class="text-muted">Banned</small></div></div>
    <div class="col-md-3"><div class="card card-custom text-center p-3"><h5 class="text-info mb-0"><?= $staffCount ?></h5><small class="text-muted">Staff</small></div></div>
</div>

<div class="card card-custom">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table orders-table">
                <thead>
                    <tr>
                        <th style="width:50px">#</th>
                        <th>USERNAME</th>
                        <th>EMAIL</th>
                        <th>ROLE</th>
                        <th>STATUS</th>
                        <th>JOINED</th>
                        <th>ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                    <tr>
                        <td><?= $u['id'] ?></td>
                        <td><strong><?= htmlspecialchars($u['username']) ?></strong></td>
                        <td><?= htmlspecialchars($u['email']) ?></td>
                        <td>
                            <?php
                            $roleColors = ['super_admin'=>'#dc3545','admin'=>'#6f42c1','staff'=>'#0d6efd','customer'=>'#198754'];
                            $roleIcons = ['super_admin'=>'fas fa-crown','admin'=>'fas fa-user-shield','staff'=>'fas fa-user-tie','customer'=>'fas fa-user'];
                            $r = $u['role'] ?? 'customer';
                            $rc = $roleColors[$r] ?? '#6c757d';
                            $ri = $roleIcons[$r] ?? 'fas fa-user';
                            ?>
                            <span class="payment-badge" style="background:<?= $rc ?>;"><i class="<?= $ri ?>"></i> <?= ucfirst($r) ?></span>
                        </td>
                        <td>
                            <?php $isActive = $u['is_active'] ?? 1; ?>
                            <span class="status-badge" style="background:<?= $isActive ? '#198754' : '#dc3545' ?>;"><i class="<?= $isActive ? 'fas fa-check-circle' : 'fas fa-ban' ?>"></i> <?= $isActive ? 'Active' : 'Banned' ?></span>
                        </td>
                        <td><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
                        <td>
                            <div class="d-flex gap-1">
                                <button class="btn btn-sm btn-warning" onclick="openEditModal(<?= $u['id'] ?>,'<?= htmlspecialchars(addslashes($u['username'])) ?>','<?= htmlspecialchars($u['role'] ?? 'customer') ?>',<?= $u['is_active'] ?? 1 ?>)"><i class="fas fa-edit"></i></button>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="toggle_ban" value="1">
                                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                    <button type="submit" class="btn btn-sm <?= ($u['is_active'] ?? 1) ? 'btn-danger' : 'btn-success' ?>" title="<?= ($u['is_active'] ?? 1) ? 'Ban' : 'Unban' ?>"><i class="fas fa-<?= ($u['is_active'] ?? 1) ? 'ban' : 'check' ?>"></i></button>
                                </form>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="delete_user" value="1">
                                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this user permanently?')"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($users)): ?>
                    <tr><td colspan="7" class="text-center py-5"><i class="fas fa-users fa-3x text-muted mb-3 d-block"></i><h5 class="text-muted">No users found</h5></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Edit User</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="update_user" value="1">
                    <input type="hidden" name="user_id" id="edit_user_id">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" id="edit_username" class="form-control" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <select name="role" id="edit_role" class="form-select">
                            <option value="customer">Customer</option>
                            <option value="staff">Staff</option>
                            <option value="admin">Admin</option>
                            <option value="super_admin">Super Admin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="is_active" id="edit_active" class="form-select">
                            <option value="1">Active</option>
                            <option value="0">Banned</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.orders-table { margin: 0; border-collapse: separate; border-spacing: 0; }
.orders-table thead th {
    background: #f8f9fa; font-weight: 700; font-size: 0.75rem; text-transform: uppercase;
    letter-spacing: 0.5px; color: #6c757d; padding: 14px 16px; border-bottom: 2px solid #e9ecef;
}
.orders-table tbody td {
    padding: 16px; vertical-align: middle; border-bottom: 1px solid #f0f0f0; font-size: 0.9rem;
}
.orders-table tbody tr:hover { background: #f8f9ff; }
.orders-table tbody tr { transition: background 0.2s; }
.payment-badge {
    display: inline-flex; align-items: center; gap: 5px; color: #fff;
    padding: 5px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 700;
    letter-spacing: 0.3px; white-space: nowrap;
}
.payment-badge i { font-size: 0.8rem; }
.status-badge {
    display: inline-flex; align-items: center; gap: 5px; color: #fff;
    padding: 5px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 700; white-space: nowrap;
}
.status-badge i { font-size: 0.7rem; }
</style>

<script>
function openEditModal(id, username, role, isActive) {
    document.getElementById('edit_user_id').value = id;
    document.getElementById('edit_username').value = username;
    document.getElementById('edit_role').value = role;
    document.getElementById('edit_active').value = isActive;
    new bootstrap.Modal(document.getElementById('editModal')).show();
}
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
