<?php
$pageTitle = 'Manage Orders';
require_once __DIR__ . '/../includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    query("UPDATE orders SET status=? WHERE id=?", [$_POST['status'], (int)$_POST['order_id']]);
    setAlert('success', 'Order status updated!');
    redirect(SITE_URL . '/admin/orders.php');
}

$statusFilter = $_GET['status'] ?? '';
$where = $statusFilter ? "WHERE o.status=?" : "";
$params = $statusFilter ? [$statusFilter] : [];

$orders = fetchAll("SELECT o.*, u.username FROM orders o LEFT JOIN users u ON o.user_id=u.id $where ORDER BY o.created_at DESC", $params);

$paymentColors = ['bkash'=>'#e2136e', 'nagad'=>'#f6921e', 'rocket'=>'#ec1c24', 'cod'=>'#198754', 'visa'=>'#1a1f71', 'mastercard'=>'#eb001b', 'card'=>'#0d6efd', 'bank'=>'#6f42c1'];
$paymentIcons = ['bkash'=>'fas fa-mobile-alt', 'nagad'=>'fas fa-wallet', 'rocket'=>'fas fa-rocket', 'cod'=>'fas fa-money-bill', 'visa'=>'fab fa-cc-visa', 'mastercard'=>'fab fa-cc-mastercard', 'card'=>'fas fa-credit-card', 'bank'=>'fas fa-university'];
$statusColors = ['pending'=>'#ffc107', 'confirmed'=>'#0dcaf0', 'processing'=>'#0d6efd', 'shipped'=>'#6f42c1', 'delivered'=>'#198754', 'cancelled'=>'#dc3545'];
$statusIcons = ['pending'=>'fas fa-clock', 'confirmed'=>'fas fa-check', 'processing'=>'fas fa-cog', 'shipped'=>'fas fa-truck', 'delivered'=>'fas fa-check-double', 'cancelled'=>'fas fa-times'];
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0 fw-bold">Orders (<?= count($orders) ?>)</h4>
    <div class="d-flex gap-2 flex-wrap">
        <a href="?status=" class="btn btn-sm <?= !$statusFilter ? 'btn-primary' : 'btn-outline-primary' ?>">All</a>
        <a href="?status=pending" class="btn btn-sm <?= $statusFilter=='pending' ? 'btn-warning' : 'btn-outline-warning' ?>">Pending</a>
        <a href="?status=confirmed" class="btn btn-sm <?= $statusFilter=='confirmed' ? 'btn-info' : 'btn-outline-info' ?>">Confirmed</a>
        <a href="?status=shipped" class="btn btn-sm <?= $statusFilter=='shipped' ? 'btn-primary' : 'btn-outline-primary' ?>">Shipped</a>
        <a href="?status=delivered" class="btn btn-sm <?= $statusFilter=='delivered' ? 'btn-success' : 'btn-outline-success' ?>">Delivered</a>
        <a href="?status=cancelled" class="btn btn-sm <?= $statusFilter=='cancelled' ? 'btn-danger' : 'btn-outline-danger' ?>">Cancelled</a>
    </div>
</div>

<div class="card card-custom">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table orders-table" id="ordersTable">
                <thead>
                    <tr>
                        <th style="width:50px">#</th>
                        <th>ORDER</th>
                        <th>CUSTOMER</th>
                        <th>TOTAL</th>
                        <th>PAYMENT</th>
                        <th>STATUS</th>
                        <th>DATE</th>
                        <th>ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $o): ?>
                    <tr>
                        <td><?= $o['id'] ?></td>
                        <td><strong class="order-number">#<?= $o['order_number'] ?></strong></td>
                        <td><?= htmlspecialchars($o['username'] ?? 'Guest') ?></td>
                        <td class="fw-bold text-primary"><?= formatPrice($o['total']) ?></td>
                        <td>
                            <?php
                            $pm = strtolower(trim($o['payment_method'] ?? 'cod'));
                            $color = $paymentColors[$pm] ?? '#6c757d';
                            $icon = $paymentIcons[$pm] ?? 'fas fa-credit-card';
                            ?>
                            <span class="payment-badge" style="background:<?= $color ?>;">
                                <i class="<?= $icon ?>"></i> <?= strtoupper($pm ?: 'N/A') ?>
                            </span>
                        </td>
                        <td>
                            <?php
                            $st = $o['status'];
                            $sc = $statusColors[$st] ?? '#6c757d';
                            $si = $statusIcons[$st] ?? 'fas fa-circle';
                            ?>
                            <span class="status-badge" style="background:<?= $sc ?>;">
                                <i class="<?= $si ?>"></i> <?= ucfirst($st) ?>
                            </span>
                        </td>
                        <td><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
                        <td>
                            <form method="POST" class="d-flex align-items-center gap-1">
                                <input type="hidden" name="update_status" value="1">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <select name="status" class="form-select form-select-sm status-select">
                                    <?php foreach (['pending','confirmed','shipped','delivered','cancelled'] as $s): ?>
                                    <option value="<?= $s ?>" <?= $o['status']===$s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="btn btn-sm btn-primary save-btn"><i class="fas fa-save"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($orders)): ?>
                    <tr><td colspan="8" class="text-center py-5"><i class="fas fa-inbox fa-3x text-muted mb-3 d-block"></i><h5 class="text-muted">No orders found</h5></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.orders-table { margin: 0; border-collapse: separate; border-spacing: 0; }
.orders-table thead th {
    background: #f8f9fa;
    font-weight: 700;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #6c757d;
    padding: 14px 16px;
    border-bottom: 2px solid #e9ecef;
}
.orders-table tbody td {
    padding: 16px;
    vertical-align: middle;
    border-bottom: 1px solid #f0f0f0;
    font-size: 0.9rem;
}
.orders-table tbody tr:hover { background: #f8f9ff; }
.orders-table tbody tr { transition: background 0.2s; }

.order-number { color: #333; font-size: 0.9rem; }

.payment-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    color: #fff;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 700;
    letter-spacing: 0.3px;
    white-space: nowrap;
}
.payment-badge i { font-size: 0.8rem; }

.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    color: #fff;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 700;
    white-space: nowrap;
}
.status-badge i { font-size: 0.7rem; }

.status-select {
    width: 130px;
    border-radius: 8px;
    font-size: 0.85rem;
    padding: 6px 10px;
    border: 1px solid #dee2e6;
}
.save-btn {
    width: 34px;
    height: 34px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    padding: 0;
}
</style>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
