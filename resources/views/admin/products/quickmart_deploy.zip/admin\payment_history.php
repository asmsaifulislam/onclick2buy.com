<?php
$pageTitle = 'Payment History';
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn() || !isAdmin()) { redirect(SITE_URL . '/admin/login.php'); }

if (isset($_POST['action'])) {
    if ($_POST['action'] == 'mark_paid') {
        $oid = (int)$_POST['order_id'];
        query("UPDATE orders SET payment_status='paid', updated_at=? WHERE id=?", [date('Y-m-d H:i:s'), $oid]);
        query("INSERT INTO activity_log (user_id, action, details, created_at) VALUES (?, 'payment_marked_paid', ?, ?)", [$_SESSION['user_id'], "Order #{$oid} marked as paid", date('Y-m-d H:i:s')]);
        setAlert('success', "Order #{$oid} marked as paid.");
        header("Location: payment_history.php");
        exit;
    }
    if ($_POST['action'] == 'update_txn') {
        $oid = (int)$_POST['order_id'];
        $txn = trim($_POST['transaction_id']);
        query("UPDATE orders SET notes=? WHERE id=?", [$txn, $oid]);
        setAlert('success', "Transaction ID updated.");
        header("Location: payment_history.php");
        exit;
    }
}

require_once __DIR__ . '/../includes/admin_header.php';

$search = trim($_GET['search'] ?? '');
$filterMethod = $_GET['method'] ?? '';
$filterStatus = $_GET['status'] ?? '';
$filterDate = $_GET['date'] ?? '';
$customFrom = $_GET['from'] ?? '';
$customTo = $_GET['to'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$offset = ($page - 1) * $perPage;

$where = ["1=1"];
$params = [];

if ($search) {
    $where[] = "(o.order_number LIKE ? OR o.shipping_name LIKE ? OR o.shipping_phone LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}
if ($filterMethod) {
    $where[] = "o.payment_method = ?";
    $params[] = $filterMethod;
}
if ($filterStatus) {
    $where[] = "o.payment_status = ?";
    $params[] = $filterStatus;
}
if ($filterDate == 'today') {
    $where[] = "DATE(o.created_at) = ?";
    $params[] = date('Y-m-d');
} elseif ($filterDate == '7') {
    $where[] = "o.created_at >= ?";
    $params[] = date('Y-m-d H:i:s', strtotime('-7 days'));
} elseif ($filterDate == '30') {
    $where[] = "o.created_at >= ?";
    $params[] = date('Y-m-d H:i:s', strtotime('-30 days'));
} elseif ($filterDate == 'custom' && $customFrom && $customTo) {
    $where[] = "DATE(o.created_at) BETWEEN ? AND ?";
    $params[] = $customFrom;
    $params[] = $customTo;
}

$whereSql = implode(' AND ', $where);

$totalCount = count_rows("SELECT COUNT(*) FROM orders o WHERE {$whereSql}", $params);
$payments = fetchAll("SELECT o.*, u.username FROM orders o LEFT JOIN users u ON o.user_id=u.id WHERE {$whereSql} ORDER BY o.created_at DESC LIMIT {$perPage} OFFSET {$offset}", $params);
$totalPages = ceil($totalCount / $perPage);

$totalCollected = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE payment_status='paid'");
$pendingPayments = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE payment_status='pending'");
$totalRefunded = count_rows("SELECT COALESCE(SUM(amount),0) FROM refund_requests WHERE status='approved'");
$failedPayments = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE payment_status='failed' OR (payment_status='pending' AND created_at < ?)", [date('Y-m-d H:i:s', strtotime('-3 days'))]);

$paymentBreakdown = fetchAll("SELECT payment_method, COUNT(*) as cnt, SUM(total) as total FROM orders WHERE payment_status='paid' GROUP BY payment_method ORDER BY total DESC");
$dailyRevenue = fetchAll("SELECT DATE(created_at) as date, SUM(CASE WHEN payment_status='paid' THEN total ELSE 0 END) as collected, SUM(CASE WHEN payment_status='pending' THEN total ELSE 0 END) as pending FROM orders WHERE created_at >= ? GROUP BY DATE(created_at) ORDER BY date ASC", [date('Y-m-d H:i:s', strtotime('-30 days'))]);

$paymentLabels = json_encode(array_map(fn($p) => strtoupper($p['payment_method'] ?? 'N/A'), $paymentBreakdown));
$paymentTotals = json_encode(array_column($paymentBreakdown, 'total'));
$paymentCounts = json_encode(array_column($paymentBreakdown, 'cnt'));
$revenueLabels = json_encode(array_column($dailyRevenue, 'date'));
$revenueCollected = json_encode(array_column($dailyRevenue, 'collected'));
$revenuePending = json_encode(array_column($dailyRevenue, 'pending'));

$pieColors = ['#e94560','#0d6efd','#198754','#ffc107','#6f42c1','#0dcaf0'];

$methodBadges = ['bkash' => '#e91e63', 'nagad' => '#ff5722', 'rocket' => '#9c27b0', 'cod' => '#4caf50', 'visa' => '#1a237e', 'mastercard' => '#ff9800'];
$statusBadges = ['paid' => 'success', 'pending' => 'warning', 'failed' => 'danger', 'refunded' => 'secondary'];
?>

<style>
.payment-modal .modal-content{background:#1a1a2e;color:#e0e0e0;border:1px solid rgba(255,255,255,0.1);border-radius:16px}
.payment-modal .modal-header{border-bottom:1px solid rgba(255,255,255,0.1)}
.payment-modal .modal-footer{border-top:1px solid rgba(255,255,255,0.1)}
.payment-detail-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05)}
.payment-detail-row:last-child{border:none}
.payment-detail-label{color:#999;font-size:.85rem}
.payment-detail-val{font-weight:600;font-size:.9rem}
.txn-input{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;border-radius:6px;padding:4px 8px;font-size:.8rem;width:160px}
.txn-input:focus{border-color:#e94560;outline:none;box-shadow:0 0 0 2px rgba(233,69,96,0.2)}
.filter-chip{padding:6px 14px;border-radius:20px;font-size:.8rem;border:1px solid #ddd;background:#f8f9fa;color:#555;cursor:pointer;transition:all .2s;text-decoration:none}
.filter-chip:hover,.filter-chip.active{background:#e94560;color:#fff;border-color:#e94560}
.timeline-dot{width:12px;height:12px;border-radius:50%;display:inline-block}
.timeline-line{width:2px;height:30px;background:#333;margin-left:5px}
</style>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0"><i class="fas fa-credit-card text-primary"></i> Payment History</h4>
    <div class="d-flex gap-2">
        <button onclick="exportCSV()" class="btn btn-sm btn-outline-success"><i class="fas fa-file-csv"></i> CSV</button>
        <button onclick="window.print()" class="btn btn-sm btn-outline-secondary"><i class="fas fa-print"></i> Print</button>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div><p>Total Collected</p><h3 class="text-success"><?= formatPrice($totalCollected) ?></h3></div>
                <div class="icon bg-success-light"><i class="fas fa-check-circle"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div><p>Pending</p><h3 class="text-warning"><?= formatPrice($pendingPayments) ?></h3></div>
                <div class="icon bg-warning-light"><i class="fas fa-clock"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div><p>Refunded</p><h3 class="text-danger"><?= formatPrice($totalRefunded) ?></h3></div>
                <div class="icon bg-danger-light"><i class="fas fa-undo"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div><p>Failed/Overdue</p><h3 class="text-danger"><?= formatPrice($failedPayments) ?></h3></div>
                <div class="icon bg-danger-light"><i class="fas fa-exclamation-triangle"></i></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-xl-8">
        <div class="card card-custom">
            <div class="card-header"><h6>Revenue Timeline (30 Days)</h6></div>
            <div class="card-body"><canvas id="revenueChart" height="90"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Payment Methods</h6></div>
            <div class="card-body d-flex justify-content-center"><canvas id="paymentPie" height="180"></canvas></div>
        </div>
    </div>
</div>

<div class="card card-custom mb-4">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h6 class="mb-0">Payments (<?= $totalCount ?> records)</h6>
            <form class="d-flex gap-2 flex-wrap" method="GET">
                <input type="text" name="search" class="form-control form-control-sm" placeholder="Search order, customer, phone..." value="<?= htmlspecialchars($search) ?>" style="width:220px">
                <select name="method" class="form-select form-select-sm" style="width:130px">
                    <option value="">All Methods</option>
                    <option value="bkash" <?= $filterMethod=='bkash'?'selected':'' ?>>bKash</option>
                    <option value="nagad" <?= $filterMethod=='nagad'?'selected':'' ?>>Nagad</option>
                    <option value="rocket" <?= $filterMethod=='rocket'?'selected':'' ?>>Rocket</option>
                    <option value="cod" <?= $filterMethod=='cod'?'selected':'' ?>>COD</option>
                    <option value="visa" <?= $filterMethod=='visa'?'selected':'' ?>>Visa</option>
                    <option value="mastercard" <?= $filterMethod=='mastercard'?'selected':'' ?>>Mastercard</option>
                </select>
                <select name="status" class="form-select form-select-sm" style="width:130px">
                    <option value="">All Status</option>
                    <option value="paid" <?= $filterStatus=='paid'?'selected':'' ?>>Paid</option>
                    <option value="pending" <?= $filterStatus=='pending'?'selected':'' ?>>Pending</option>
                    <option value="failed" <?= $filterStatus=='failed'?'selected':'' ?>>Failed</option>
                    <option value="refunded" <?= $filterStatus=='refunded'?'selected':'' ?>>Refunded</option>
                </select>
                <select name="date" class="form-select form-select-sm" style="width:130px">
                    <option value="">All Time</option>
                    <option value="today" <?= $filterDate=='today'?'selected':'' ?>>Today</option>
                    <option value="7" <?= $filterDate=='7'?'selected':'' ?>>Last 7 Days</option>
                    <option value="30" <?= $filterDate=='30'?'selected':'' ?>>Last 30 Days</option>
                    <option value="custom" <?= $filterDate=='custom'?'selected':'' ?>>Custom</option>
                </select>
                <?php if ($filterDate == 'custom'): ?>
                <input type="date" name="from" class="form-control form-control-sm" value="<?= $customFrom ?>" style="width:140px">
                <input type="date" name="to" class="form-control form-control-sm" value="<?= $customTo ?>" style="width:140px">
                <?php endif; ?>
                <button class="btn btn-sm btn-primary"><i class="fas fa-search"></i></button>
                <a href="payment_history.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i></a>
            </form>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-custom table-sm" id="paymentTable">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll"></th>
                        <th>Order #</th>
                        <th>Customer</th>
                        <th>Amount</th>
                        <th>Method</th>
                        <th>Status</th>
                        <th>Transaction ID</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($payments)): ?>
                    <tr><td colspan="9" class="text-center text-muted py-4">No payments found</td></tr>
                <?php else: foreach ($payments as $p): ?>
                    <tr>
                        <td><input type="checkbox" class="row-check" value="<?= $p['id'] ?>"></td>
                        <td><a href="#" onclick="showDetail(<?= htmlspecialchars(json_encode($p)) ?>);return false" class="fw-bold text-primary">#<?= $p['order_number'] ?></a></td>
                        <div>
                            <td>
                                <div><?= htmlspecialchars($p['username'] ?? $p['shipping_name'] ?? 'Guest') ?></div>
                                <small class="text-muted"><?= htmlspecialchars($p['shipping_phone'] ?? '') ?></small>
                            </td>
                        </div>
                        <td class="fw-bold"><?= formatPrice($p['total']) ?></td>
                        <td><span class="badge" style="background:<?= $methodBadges[strtolower($p['payment_method'])] ?? '#666' ?>;color:#fff;text-transform:uppercase;font-size:.7rem"><?= htmlspecialchars($p['payment_method'] ?? 'N/A') ?></span></td>
                        <td><span class="badge badge-<?= $statusBadges[$p['payment_status']] ?? 'secondary' ?>"><?= ucfirst($p['payment_status'] ?? 'pending') ?></span></td>
                        <td>
                            <form method="POST" class="d-inline" onsubmit="return confirm('Update Transaction ID?')">
                                <input type="hidden" name="action" value="update_txn">
                                <input type="hidden" name="order_id" value="<?= $p['id'] ?>">
                                <input type="text" name="transaction_id" class="txn-input" placeholder="Enter TXN ID" value="<?= htmlspecialchars($p['notes'] ?? '') ?>">
                                <button class="btn btn-sm btn-outline-primary py-0" title="Save"><i class="fas fa-save"></i></button>
                            </form>
                        </td>
                        <td><small><?= date('M d, Y H:i', strtotime($p['created_at'])) ?></small></td>
                        <td>
                            <div class="d-flex gap-1">
                                <button class="btn btn-sm btn-outline-info py-0" onclick='showDetail(<?= htmlspecialchars(json_encode($p)) ?>)' title="View"><i class="fas fa-eye"></i></button>
                                <?php if (($p['payment_status'] ?? '') == 'pending'): ?>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Mark this as paid?')">
                                    <input type="hidden" name="action" value="mark_paid">
                                    <input type="hidden" name="order_id" value="<?= $p['id'] ?>">
                                    <button class="btn btn-sm btn-outline-success py-0" title="Mark Paid"><i class="fas fa-check"></i></button>
                                </form>
                                <?php endif; ?>
                                <a href="<?= SITE_URL ?>/store/invoice.php?order=<?= $p['order_number'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary py-0" title="Invoice"><i class="fas fa-file-invoice"></i></a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <small class="text-muted">Showing <?= $offset+1 ?>-<?= min($offset+$perPage, $totalCount) ?> of <?= $totalCount ?></small>
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if ($page > 1): ?>
                    <li class="page-item"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$page-1])) ?>">Prev</a></li>
                    <?php endif; ?>
                    <?php for ($i = max(1,$page-2); $i <= min($totalPages,$page+2); $i++): ?>
                    <li class="page-item <?= $i==$page?'active':'' ?>"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$i])) ?>"><?= $i ?></a></li>
                    <?php endfor; ?>
                    <?php if ($page < $totalPages): ?>
                    <li class="page-item"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$page+1])) ?>">Next</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="modal fade payment-modal" id="paymentModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-receipt"></i> Payment Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="paymentModalBody"></div>
            <div class="modal-footer">
                <button class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary btn-sm" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
            </div>
        </div>
    </div>
</div>

<script src="<?= SITE_URL ?>/assets/js/chart.umd.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/bootstrap.bundle.min.js"></script>
<script>
const pieColors = <?= json_encode($pieColors) ?>;

const revLabels = <?= $revenueLabels ?>;
const revCollected = <?= $revenueCollected ?>;
const revPending = <?= $revenuePending ?>;
new Chart(document.getElementById('revenueChart'), {
    type:'line',
    data:{
        labels:revLabels,
        datasets:[
            {label:'Collected',data:revCollected,borderColor:'#198754',backgroundColor:'rgba(25,135,84,0.08)',fill:true,tension:0.4,pointRadius:2},
            {label:'Pending',data:revPending,borderColor:'#ffc107',backgroundColor:'rgba(255,193,7,0.08)',fill:true,tension:0.4,pointRadius:2}
        ]
    },
    options:{responsive:true,plugins:{legend:{position:'bottom',labels:{boxWidth:12}}},scales:{y:{beginAtZero:true}}}
});

new Chart(document.getElementById('paymentPie'), {
    type:'pie',
    data:{labels:<?= $paymentLabels ?>,datasets:[{data:<?= $paymentTotals ?>,backgroundColor:pieColors}]},
    options:{responsive:true,plugins:{legend:{position:'bottom',labels:{boxWidth:12,padding:6}}}}
});

function showDetail(o) {
    var m = (o.payment_method||'N/A').toLowerCase();
    var methodColors = {bkash:'#e91e63',nagad:'#ff5722',rocket:'#9c27b0',cod:'#4caf50',visa:'#1a237e',mastercard:'#ff9800'};
    var statusColors = {paid:'#198754',pending:'#ffc107',failed:'#dc3545',refunded:'#6c757d'};
    var html = '<div class="row g-4">';
    html += '<div class="col-md-6">';
    html += '<h6 class="mb-3">Order Info</h6>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Order Number</span><span class="payment-detail-val">#'+o.order_number+'</span></div>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Customer</span><span class="payment-detail-val">'+(o.username||o.shipping_name||'Guest')+'</span></div>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Phone</span><span class="payment-detail-val">'+(o.shipping_phone||'N/A')+'</span></div>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Address</span><span class="payment-detail-val">'+(o.shipping_address||'N/A')+', '+(o.shipping_city||'')+'</span></div>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Date</span><span class="payment-detail-val">'+o.created_at+'</span></div>';
    html += '</div>';
    html += '<div class="col-md-6">';
    html += '<h6 class="mb-3">Payment Info</h6>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Amount</span><span class="payment-detail-val text-success" style="font-size:1.2rem">৳'+Number(o.total).toLocaleString()+'</span></div>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Method</span><span class="badge" style="background:'+methodColors[m]||'#666'+';color:#fff">'+(o.payment_method||'N/A').toUpperCase()+'</span></div>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Status</span><span class="badge" style="background:'+(statusColors[o.payment_status]||'#666')+';color:#fff">'+(o.payment_status||'pending').toUpperCase()+'</span></div>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Subtotal</span><span class="payment-detail-val">৳'+Number(o.subtotal||o.total).toLocaleString()+'</span></div>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Shipping</span><span class="payment-detail-val">৳'+Number(o.shipping_cost||0).toLocaleString()+'</span></div>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Discount</span><span class="payment-detail-val text-danger">-৳'+Number(o.discount||0).toLocaleString()+'</span></div>';
    html += '<div class="payment-detail-row"><span class="payment-detail-label">Transaction ID</span><span class="payment-detail-val">'+(o.notes||'N/A')+'</span></div>';
    html += '</div>';
    html += '</div>';
    html += '<div class="mt-3"><h6>Payment Timeline</h6><div class="d-flex align-items-center gap-3">';
    html += '<div class="text-center"><div class="timeline-dot bg-success"></div><small class="d-block mt-1">Created</small></div>';
    html += '<div class="timeline-line"></div>';
    if(o.payment_status=='paid'){
        html += '<div class="text-center"><div class="timeline-dot bg-success"></div><small class="d-block mt-1">Paid</small></div>';
    } else if(o.payment_status=='pending'){
        html += '<div class="text-center"><div class="timeline-dot bg-warning"></div><small class="d-block mt-1">Pending</small></div>';
    } else {
        html += '<div class="text-center"><div class="timeline-dot bg-danger"></div><small class="d-block mt-1">'+(o.payment_status||'Unknown')+'</small></div>';
    }
    html += '</div></div>';
    document.getElementById('paymentModalBody').innerHTML = html;
    new bootstrap.Modal(document.getElementById('paymentModal')).show();
}

document.getElementById('selectAll')?.addEventListener('change', function(){
    document.querySelectorAll('.row-check').forEach(c => c.checked = this.checked);
});

function exportCSV() {
    var rows = [['Order #','Customer','Amount','Method','Status','TXN ID','Date']];
    document.querySelectorAll('#paymentTable tbody tr').forEach(function(tr) {
        var cells = tr.querySelectorAll('td');
        if (cells.length >= 8) {
            rows.push([
                cells[1].textContent.trim(),
                cells[2].textContent.trim(),
                cells[3].textContent.trim(),
                cells[4].textContent.trim(),
                cells[5].textContent.trim(),
                cells[6].querySelector('input')?.value || cells[6].textContent.trim(),
                cells[7].textContent.trim()
            ]);
        }
    });
    var csv = rows.map(r => r.map(c => '"'+c.replace(/"/g,'""')+'"').join(',')).join('\n');
    var blob = new Blob([csv],{type:'text/csv'});
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'payment_history.csv'; a.click();
}
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
