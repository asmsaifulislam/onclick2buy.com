<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn()) { setAlert('danger', 'Please login first.'); redirect(SITE_URL . '/store/login.php'); }

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$productId = (int)($_POST['product_id'] ?? $_GET['product_id'] ?? 0);
$userId = $_SESSION['user_id'];

switch ($action) {
    case 'compare_add':
        if ($productId) {
            $count = count_rows("SELECT COUNT(*) FROM product_compare WHERE user_id=?", [$userId]);
            if ($count >= 4) { setAlert('danger', 'Max 4 products to compare.'); }
            else {
                $exists = count_rows("SELECT COUNT(*) FROM product_compare WHERE user_id=? AND product_id=?", [$userId, $productId]);
                if (!$exists) { query("INSERT INTO product_compare (user_id, product_id) VALUES (?,?)", [$userId, $productId]); setAlert('success', 'Added to compare!'); }
                else { setAlert('info', 'Already in comparison.'); }
            }
        }
        break;
    case 'compare_remove':
        if ($productId) { query("DELETE FROM product_compare WHERE user_id=? AND product_id=?", [$userId, $productId]); setAlert('success', 'Removed from compare.'); }
        break;
}

$referer = $_SERVER['HTTP_REFERER'] ?? SITE_URL . '/store/compare.php';
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
    header('Content-Type: application/json'); echo json_encode(['success' => true]); exit;
}
redirect($referer);
