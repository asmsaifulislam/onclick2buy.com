<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) session_start();

$step = $_GET['step'] ?? 'choose';

// Handle install actions
$action = $_GET['action'] ?? $_POST['action'] ?? '';
if ($action) {

    // ─── SQLite Install ───
    if ($action === 'install_sqlite') {
        $dbFile = __DIR__ . '/quickmart.db';
        if (file_exists($dbFile)) unlink($dbFile);

        $pdo = new PDO('sqlite:' . $dbFile);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("PRAGMA journal_mode=WAL");
        $pdo->exec("PRAGMA foreign_keys=ON");
        $pdo->exec(file_get_contents(__DIR__ . '/install_sqlite.sql'));

        // Write local config
        $cfg = "<?php\n";
        $cfg .= "define('DB_PATH', __DIR__ . '/quickmart.db');\n";
        $cfg .= "define('SITE_NAME', 'Quick Mart');\n";
        $cfg .= "define('ADMIN_EMAIL', 'admin@quickmart.com');\n";
        $cfg .= "session_start();\n";
        file_put_contents(__DIR__ . '/local_config.php', $cfg);

        header("Location: install.php?step=done&mode=sqlite");
        exit;
    }

    // ─── MySQL Install ───
    if ($action === 'install_mysql') {
        $host = trim($_POST['db_host'] ?? 'localhost');
        $name = trim($_POST['db_name'] ?? '');
        $user = trim($_POST['db_user'] ?? '');
        $pass = $_POST['db_pass'] ?? '';
        
        // Debug: log what we received
        error_log("MySQL Install: host=$host, name=$name, user=$user");

        try {
            // Try multiple connection methods
            $connected = false;
            $hosts = [$host, 'shareddb-y.hosting.stackcp.net', '127.0.0.1', 'localhost'];
            $lastError = null;
            foreach ($hosts as $tryHost) {
                try {
                    $pdo = new PDO("mysql:host=$tryHost;charset=utf8mb4", $user, $pass);
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $host = $tryHost;
                    $connected = true;
                    break;
                } catch (PDOException $e) {
                    $lastError = $e;
                    continue;
                }
            }
            if (!$connected) throw $lastError;

            // Create database if not exists (may fail on shared hosting — that's OK)
            try {
                $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            } catch (PDOException $e) {
                error_log("CREATE DATABASE skipped: " . $e->getMessage());
            }
            $pdo->exec("USE `$name`");

            // Drop all existing tables to allow fresh install
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
            $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            foreach ($tables as $table) {
                $pdo->exec("DROP TABLE IF EXISTS `$table`");
            }
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

            // Load and execute SQL
            $sql = file_get_contents(__DIR__ . '/install.sql');
            $pdo->exec($sql);

            // Write cPanel config
            $cfg = "<?php\n";
            $cfg .= "define('DB_HOST', " . var_export($host, true) . ");\n";
            $cfg .= "define('DB_NAME', " . var_export($name, true) . ");\n";
            $cfg .= "define('DB_USER', " . var_export($user, true) . ");\n";
            $cfg .= "define('DB_PASS', " . var_export($pass, true) . ");\n";
            $cfg .= "define('SITE_NAME', 'Quick Mart');\n";
            $cfg .= "define('ADMIN_EMAIL', 'admin@quickmart.com');\n";
            $cfg .= "session_start();\n";
            file_put_contents(__DIR__ . '/cpanel_config.php', $cfg);

            header("Location: install.php?step=done&mode=mysql");
            exit;
        } catch (PDOException $e) {
            $msg = $e->getMessage();
            if (strpos($msg, '2002') !== false) {
                $msg = "Cannot connect to MySQL server. Try these hosts: 127.0.0.1, localhost, or check your hosting panel for the correct MySQL Host address. Original: " . $msg;
            }
            header("Location: install.php?step=mysql&error=" . urlencode($msg) . "&db_host=" . urlencode($host) . "&db_name=" . urlencode($name) . "&db_user=" . urlencode($user));
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quick Mart - Installation</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Outfit', sans-serif; }
        body { background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%); color: #fff; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .install-card { background: rgba(255,255,255,0.05); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.1); border-radius: 20px; padding: 40px; max-width: 550px; width: 100%; }
        .install-card h2 { font-weight: 800; margin-bottom: 10px; }
        .btn-option { display: block; width: 100%; padding: 20px; border: 2px solid rgba(255,255,255,0.1); border-radius: 16px; background: rgba(255,255,255,0.03); color: #fff; text-align: left; cursor: pointer; transition: all 0.3s; margin-bottom: 14px; text-decoration: none; }
        .btn-option:hover { border-color: #e94560; background: rgba(233,69,96,0.08); transform: translateY(-2px); color: #fff; }
        .btn-option .icon { font-size: 2rem; color: #e94560; margin-bottom: 8px; display: block; }
        .btn-option .title { font-weight: 700; font-size: 1.1rem; }
        .btn-option .desc { font-size: 0.85rem; color: rgba(255,255,255,0.5); margin-top: 4px; }
        .btn-install { width: 100%; padding: 14px; border: none; border-radius: 12px; background: linear-gradient(135deg, #e94560, #c73e54); color: #fff; font-weight: 700; font-size: 1.05rem; cursor: pointer; transition: all 0.3s; }
        .btn-install:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(233,69,96,0.4); }
        .form-control { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 10px; padding: 10px 14px; }
        .form-control:focus { background: rgba(255,255,255,0.1); border-color: #e94560; box-shadow: 0 0 0 3px rgba(233,69,96,0.15); color: #fff; }
        .form-label { font-weight: 600; font-size: 0.9rem; color: rgba(255,255,255,0.8); }
        .alert { border-radius: 12px; font-size: 0.9rem; }
        .success-box { text-align: center; }
        .success-box i { font-size: 4rem; color: #28a745; margin-bottom: 16px; }
        .badge-mode { display: inline-block; padding: 4px 12px; border-radius: 50px; font-size: 0.75rem; font-weight: 600; }
        .badge-sqlite { background: rgba(40,167,69,0.15); color: #28a745; }
        .badge-mysql { background: rgba(0,123,255,0.15); color: #0d6efd; }
        hr { border-color: rgba(255,255,255,0.08); }
        a { color: #e94560; }
    </style>
</head>
<body>
<div class="install-card">
<?php if ($step === 'done'): ?>
    <div class="success-box">
        <i class="fas fa-check-circle"></i>
        <h2 class="mb-2">Installation Complete!</h2>
        <p class="mb-3">Your Quick Mart store is ready with 96 products, demo orders, coupons & more.</p>
        <span class="badge-mode badge-<?= ($_GET['mode'] ?? 'sqlite') === 'mysql' ? 'mysql' : 'sqlite' ?>">
            <?= ($_GET['mode'] ?? 'sqlite') === 'mysql' ? 'MySQL' : 'SQLite' ?> Database
        </span>
        <div class="mt-4">
            <a href="store/" class="btn btn-success btn-lg me-2"><i class="fas fa-store"></i> View Store</a>
            <a href="admin/" class="btn btn-warning btn-lg"><i class="fas fa-cog"></i> Admin Panel</a>
        </div>
        <hr>
        <p class="small" style="color:rgba(255,255,255,0.5)">
            Admin: <strong>admin</strong> / <strong>admin123</strong><br>
            <i class="fas fa-shield-alt"></i> Delete <code>install.php</code> for security.
        </p>
    </div>

<?php elseif ($step === 'mysql'): ?>
    <h2><i class="fas fa-database" style="color:#0d6efd"></i> MySQL Setup</h2>
    <p class="mb-4" style="color:rgba(255,255,255,0.6)">Enter your cPanel MySQL database credentials.</p>
    <?php if (!empty($_GET['error'])): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($_GET['error']) ?></div>
    <?php endif; ?>
    <div class="alert alert-info" style="background:rgba(0,123,255,0.1);border-color:rgba(0,123,255,0.2)">
        <strong>How to get credentials from your panel:</strong><br>
        1. Go to <strong>Web Tools → MySQL Databases</strong><br>
        2. Create a new database (e.g. <code>starkidb_quickmart</code>)<br>
        3. Create a user and add to the database<br>
        4. Copy the database name, username & password here<br><br>
        <strong>Database Host:</strong> Try <code>127.0.0.1</code> first. If that fails, check your panel for the correct MySQL Host address.
    </div>
    <form method="POST" action="install.php?action=install_mysql">
        <input type="hidden" name="step" value="mysql">
        <div class="mb-3">
            <label class="form-label">Database Host</label>
            <input type="text" name="db_host" class="form-control" value="<?= htmlspecialchars($_GET['db_host'] ?? 'shareddb-y.hosting.stackcp.net') ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Database Name</label>
            <input type="text" name="db_name" class="form-control" value="<?= htmlspecialchars($_GET['db_name'] ?? 'starkidb_quickmart-3135396a44') ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Database Username</label>
            <input type="text" name="db_user" class="form-control" value="<?= htmlspecialchars($_GET['db_user'] ?? 'quckmart') ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Database Password</label>
            <input type="password" name="db_pass" class="form-control" required>
        </div>
        <button type="submit" class="btn-install"><i class="fas fa-rocket"></i> Install with MySQL</button>
    </form>
    <p class="text-center mt-3"><a href="install.php">← Back</a></p>

<?php else: ?>
    <h2><i class="fas fa-bolt" style="color:#e94560"></i> Quick Mart Setup</h2>
    <p class="mb-4" style="color:rgba(255,255,255,0.6)">Choose your database type. One click and your store is ready!</p>

    <a href="?action=install_sqlite" class="btn-option">
        <span class="icon"><i class="fas fa-file-alt"></i></span>
        <span class="title">SQLite <span class="badge-mode badge-sqlite">Recommended</span></span>
        <span class="desc">No setup needed. Zero configuration. Just click and go. Best for quick start.</span>
    </a>

    <a href="?step=mysql" class="btn-option">
        <span class="icon"><i class="fas fa-server"></i></span>
        <span class="title">MySQL <span class="badge-mode badge-mysql">For Production</span></span>
        <span class="desc">Use your cPanel MySQL database. Better for high traffic & production use.</span>
    </a>

    <hr>
    <p class="text-center small" style="color:rgba(255,255,255,0.4)">
        Both options include 96 products, demo users, orders, coupons & blog posts.
    </p>
<?php endif; ?>
</div>
</body>
</html>
