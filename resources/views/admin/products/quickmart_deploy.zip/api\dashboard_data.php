<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn() || !isAdmin()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$period = $_GET['period'] ?? 'today';
$today = date('Y-m-d');
switch ($period) {
    case 'week': $startDate = date('Y-m-d', strtotime('-7 days')); break;
    case 'month': $startDate = date('Y-m-d', strtotime('-30 days')); break;
    case 'year': $startDate = date('Y-m-d', strtotime('-365 days')); break;
    default: $startDate = $today;
}
$yesterday = date('Y-m-d', strtotime('-1 day'));
$lastWeek = date('Y-m-d', strtotime('-14 days'));

$totalOrders = count_rows("SELECT COUNT(*) FROM orders WHERE created_at >= ?", [$startDate]);
$totalRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND created_at >= ?", [$startDate]);
$pendingOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status='pending' AND created_at >= ?", [$startDate]);
$confirmedOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status='confirmed' AND created_at >= ?", [$startDate]);
$shippedOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status='shipped' AND created_at >= ?", [$startDate]);
$deliveredOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status='delivered' AND created_at >= ?", [$startDate]);
$cancelledOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status='cancelled' AND created_at >= ?", [$startDate]);
$totalProducts = count_rows("SELECT COUNT(*) FROM products WHERE is_active=1 AND created_at >= ?", [$startDate]);
$newProducts = count_rows("SELECT COUNT(*) FROM products WHERE is_active=1 AND created_at >= ?", [$startDate]);
$totalCustomers = count_rows("SELECT COUNT(*) FROM users WHERE is_staff=0 AND created_at >= ?", [$startDate]);
$lowStockCount = count_rows("SELECT COUNT(*) FROM products WHERE is_active=1 AND stock <= 10");
$avgOrderValue = $totalOrders > 0 ? $totalRevenue / $totalOrders : 0;

$ydOrders = count_rows("SELECT COUNT(*) FROM orders WHERE created_at >= ? AND created_at < ?", [$yesterday, $today]);
$ydRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND created_at >= ? AND created_at < ?", [$yesterday, $today]);
$ordersChange = $totalOrders - $ydOrders;
$revenueChange = $totalRevenue - $ydRevenue;

$lwOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status != 'cancelled' AND created_at >= ? AND created_at < ?", [$lastWeek, $startDate]);
$lwRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND created_at >= ? AND created_at < ?", [$lastWeek, $startDate]);
$wowOrders = $lwOrders > 0 ? round(($totalOrders - $lwOrders) / $lwOrders * 100, 1) : 0;
$wowRevenue = $lwRevenue > 0 ? round(($totalRevenue - $lwRevenue) / $lwRevenue * 100, 1) : 0;

$targetAmount = count_rows("SELECT COALESCE(target_amount,0) FROM revenue_targets WHERE month=? AND year=?", [(int)date('m'), (int)date('Y')]);
$targetProgress = $targetAmount > 0 ? ($totalRevenue / $targetAmount * 100) : 0;

$newCustomers = count_rows("SELECT COUNT(*) FROM users WHERE is_staff=0 AND created_at >= ?", [$startDate]);
$allCustomers = count_rows("SELECT COUNT(*) FROM users WHERE is_staff=0");
$returningCustomers = $allCustomers - $newCustomers;
$returningRate = $allCustomers > 0 ? round($newCustomers / $allCustomers * 100) : 0;

$totalRefunds = count_rows("SELECT COALESCE(SUM(amount),0) FROM refund_requests WHERE status='approved' AND created_at >= ?", [$startDate]);
$refundRate = $totalRevenue > 0 ? round($totalRefunds / $totalRevenue * 100, 1) : 0;

$repeatCustomers = count_rows("SELECT COUNT(*) FROM (SELECT user_id FROM orders WHERE user_id IS NOT NULL AND status != 'cancelled' AND created_at >= ? GROUP BY user_id HAVING COUNT(*) > 1)", [$startDate]);
$repeatRate = $allCustomers > 0 ? round($repeatCustomers / $allCustomers * 100) : 0;

$couponUsed = count_rows("SELECT COUNT(*) FROM orders WHERE discount > 0 AND created_at >= ?", [$startDate]);
$couponRevenue = count_rows("SELECT COALESCE(SUM(discount),0) FROM orders WHERE discount > 0 AND created_at >= ?", [$startDate]);

$totalStockValue = count_rows("SELECT COALESCE(SUM(p.price * p.stock),0) FROM products p WHERE p.is_active=1");

$paymentBreakdown = fetchAll("SELECT payment_method, COUNT(*) as cnt, SUM(total) as total FROM orders WHERE status != 'cancelled' AND created_at >= ? GROUP BY payment_method ORDER BY total DESC", [$startDate]);

$topProducts = fetchAll("SELECT p.name, SUM(oi.quantity) as units, SUM(oi.price * oi.quantity) as revenue FROM order_items oi JOIN products p ON oi.product_id=p.id JOIN orders o ON oi.order_id=o.id WHERE o.status != 'cancelled' AND o.created_at >= ? GROUP BY p.id ORDER BY revenue DESC LIMIT 5", [$startDate]);

$topCategories = fetchAll("SELECT c.name, SUM(oi.price * oi.quantity) as revenue FROM order_items oi JOIN products p ON oi.product_id=p.id JOIN categories c ON p.category_id=c.id JOIN orders o ON oi.order_id=o.id WHERE o.status != 'cancelled' AND o.created_at >= ? GROUP BY c.id ORDER BY revenue DESC LIMIT 5", [$startDate]);

$recentOrders = fetchAll("SELECT o.*, u.username FROM orders o LEFT JOIN users u ON o.user_id=u.id WHERE o.created_at >= ? ORDER BY o.created_at DESC LIMIT 10", [$startDate]);
$newOrdersToday = fetchAll("SELECT o.*, u.username FROM orders o LEFT JOIN users u ON o.user_id=u.id WHERE o.status='pending' AND o.created_at >= ? ORDER BY o.created_at DESC LIMIT 5", [$startDate]);
$lowStockProducts = fetchAll("SELECT * FROM products WHERE is_active=1 AND stock <= 10 ORDER BY stock ASC LIMIT 5");

$hourlySales = fetchAll("SELECT " . sqlHour('created_at') . " as hour, COUNT(*) as cnt FROM orders WHERE status != 'cancelled' AND created_at >= ? GROUP BY hour ORDER BY hour", [$startDate]);
$hourlyMap = array_fill(0, 24, 0);
foreach ($hourlySales as $h) $hourlyMap[(int)$h['hour']] = (int)$h['cnt'];
$maxHourly = max($hourlyMap) > 0 ? max($hourlyMap) : 1;

$dayOfWeek = fetchAll("SELECT " . sqlDayOfWeek('created_at') . " as day, SUM(total) as revenue FROM orders WHERE status != 'cancelled' AND created_at >= ? GROUP BY day ORDER BY day", [$startDate]);
$dayRevMap = array_fill(0, 7, 0);
foreach ($dayOfWeek as $d) $dayRevMap[(int)$d['day']] = (int)$d['revenue'];

$salesData = [];
$chartDays = $period === 'today' ? 1 : ($period === 'week' ? 7 : ($period === 'month' ? 30 : 365));
if ($chartDays > 60) $chartDays = 60;
for ($i = $chartDays - 1; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} days"));
    $dayRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND DATE(created_at)=?", [$date]);
    $dayOrders = count_rows("SELECT COUNT(*) FROM orders WHERE DATE(created_at)=?", [$date]);
    $salesData[] = ['date' => date('M d', strtotime($date)), 'revenue' => (int)$dayRevenue, 'orders' => (int)$dayOrders];
}

$recentActivity = fetchAll("SELECT 'order' as type, o.order_number as ref, o.status as detail, o.created_at as time FROM orders o WHERE o.created_at >= ? UNION ALL SELECT 'refund' as type, " . sqlCastAsText('rr.id') . " as ref, rr.status as detail, rr.created_at as time FROM refund_requests rr WHERE rr.created_at >= ? ORDER BY time DESC LIMIT 10", [date('Y-m-d H:i:s', strtotime('-7 days')), date('Y-m-d H:i:s', strtotime('-7 days'))]);

$overdueOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status IN ('pending','confirmed') AND created_at < ?", [date('Y-m-d H:i:s', strtotime('-3 days'))]);

echo json_encode([
    'period' => $period,
    'cards' => [
        'totalOrders' => $totalOrders,
        'totalRevenue' => formatPrice($totalRevenue),
        'totalRevenueRaw' => (int)$totalRevenue,
        'pendingOrders' => $pendingOrders,
        'deliveredOrders' => $deliveredOrders,
        'cancelledOrders' => $cancelledOrders,
        'totalProducts' => $totalProducts,
        'totalCustomers' => $totalCustomers,
        'avgOrderValue' => formatPrice($avgOrderValue),
        'totalStockValue' => formatPrice($totalStockValue),
        'repeatRate' => $repeatRate,
        'repeatCustomers' => $repeatCustomers,
        'allCustomers' => $allCustomers,
        'refundRate' => $refundRate,
        'lowStockCount' => $lowStockCount,
    ],
    'badges' => [
        'ordersChange' => $ordersChange,
        'revenueChange' => formatPrice(abs($revenueChange)),
        'revenueChangeDir' => $revenueChange >= 0 ? 'up' : 'down',
        'wowRevenue' => $wowRevenue,
    ],
    'target' => [
        'amount' => formatPrice($targetAmount),
        'progress' => round($targetProgress, 1),
        'revenue' => formatPrice($totalRevenue),
        'show' => $targetAmount > 0,
        'color' => $targetProgress >= 100 ? 'success' : ($targetProgress >= 50 ? 'primary' : 'warning'),
    ],
    'pipeline' => [
        'pending' => $pendingOrders,
        'confirmed' => $confirmedOrders,
        'shipped' => $shippedOrders,
        'delivered' => $deliveredOrders,
        'cancelled' => $cancelledOrders,
    ],
    'charts' => [
        'salesData' => $salesData,
        'paymentLabels' => array_map(fn($p) => strtoupper($p['payment_method'] ?? 'N/A'), $paymentBreakdown),
        'paymentTotals' => array_column($paymentBreakdown, 'total'),
        'hourlyMap' => $hourlyMap,
        'maxHourly' => $maxHourly,
        'dayNames' => ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
        'dayRevMap' => $dayRevMap,
        'topProductNames' => array_map(fn($p) => (strlen($p['name']) > 15 ? substr($p['name'], 0, 15).'...' : $p['name']), $topProducts),
        'topProductRevenues' => array_column($topProducts, 'revenue'),
        'topCatLabels' => array_column($topCategories, 'name'),
        'topCatRevenues' => array_column($topCategories, 'revenue'),
    ],
    'summary' => [
        'couponUsed' => $couponUsed,
        'couponRevenue' => formatPrice($couponRevenue),
        'newCustomers' => $newCustomers,
    ],
    'recentOrders' => array_map(fn($o) => [
        'id' => $o['id'],
        'order_number' => $o['order_number'],
        'username' => $o['username'] ?? 'Guest',
        'status' => $o['status'],
        'payment_status' => $o['payment_status'] ?? 'pending',
        'total' => formatPrice($o['total']),
        'date' => date('M d, H:i', strtotime($o['created_at'])),
        'is_pending' => $o['status'] === 'pending',
    ], $recentOrders),
    'newOrders' => array_map(fn($o) => [
        'order_number' => $o['order_number'],
        'username' => $o['username'] ?? 'Guest',
        'total' => formatPrice($o['total']),
    ], $newOrdersToday),
    'lowStock' => array_map(fn($p) => [
        'name' => substr($p['name'], 0, 25),
        'stock' => $p['stock'],
    ], $lowStockProducts),
    'activity' => array_map(fn($a) => [
        'type' => $a['type'],
        'ref' => $a['ref'],
        'detail' => $a['detail'],
        'time' => date('M d H:i', strtotime($a['time'])),
    ], $recentActivity),
    'overdueOrders' => $overdueOrders,
]);
