<?php
$pageTitle = 'Size Guide - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
$guides = fetchAll("SELECT sg.*, c.name as cat_name FROM size_guides sg LEFT JOIN categories c ON sg.category_id=c.id ORDER BY sg.name");
?>
<h2 class="mb-4"><i class="fas fa-ruler"></i> Size Guide</h2>
<div class="row g-4">
    <?php foreach ($guides as $g): ?>
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h5><?= htmlspecialchars($g['name']) ?></h5>
            <?php if ($g['cat_name']): ?><span class="badge bg-primary mb-2"><?= htmlspecialchars($g['cat_name']) ?></span><?php endif; ?>
            <table class="table table-sm table-custom mt-2">
                <thead><tr><th>Size</th><th>Measurement</th></tr></thead>
                <tbody>
                    <?php $sizes = json_decode($g['sizes'], true); foreach ($sizes as $size => $meas): ?>
                    <tr><td><strong><?= $size ?></strong></td><td><?= $meas ?></td></tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
