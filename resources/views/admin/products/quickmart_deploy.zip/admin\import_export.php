<?php
$pageTitle = 'Bulk Import/Export';
require_once __DIR__ . '/../includes/admin_header.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['import_csv'])) {
        if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] == UPLOAD_ERR_OK) {
            $file = fopen($_FILES['csv_file']['tmp_name'], 'r');
            $header = fgetcsv($file);
            $imported = 0;
            while (($row = fgetcsv($file)) !== FALSE) {
                if (count($row) >= 4) {
                    $name = trim($row[0]);
                    $slug = strtolower(preg_replace('/[^a-z0-9]+/', '-', $name));
                    $price = (float)($row[1] ?? 0);
                    $stock = (int)($row[2] ?? 0);
                    $category = trim($row[3] ?? '');
                    $brand = trim($row[4] ?? '');
                    $desc = trim($row[5] ?? $name);
                    $catId = null;
                    if ($category) {
                        $cat = fetch("SELECT id FROM categories WHERE name=?", [$category]);
                        if ($cat) $catId = $cat['id'];
                    }
                    $existing = fetch("SELECT id FROM products WHERE slug=?", [$slug]);
                    if (!$existing) {
                        query("INSERT INTO products (name, slug, description, price, stock, category_id, brand) VALUES (?,?,?,?,?,?,?)", [$name, $slug, $desc, $price, $stock, $catId, $brand]);
                        $imported++;
                    }
                }
            }
            fclose($file);
            setAlert('success', "Imported $imported products successfully!");
        } else {
            setAlert('danger', 'Please upload a valid CSV file.');
        }
        redirect(SITE_URL . '/admin/import_export.php');
    }
    if (isset($_POST['export_csv'])) {
        $products = fetchAll("SELECT p.name, p.price, p.stock, c.name as category, p.brand, p.description FROM products p LEFT JOIN categories c ON p.category_id=c.id ORDER BY p.name");
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="quickmart_products_' . date('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Name', 'Price', 'Stock', 'Category', 'Brand', 'Description']);
        foreach ($products as $p) {
            fputcsv($out, [$p['name'], $p['price'], $p['stock'], $p['category'] ?? '', $p['brand'], $p['description']]);
        }
        fclose($out);
        exit;
    }
}

$lowStock = fetchAll("SELECT name, stock FROM products WHERE stock <= 10 AND is_active=1 ORDER BY stock ASC LIMIT 20");
$recentProducts = fetchAll("SELECT name, price, stock, created_at FROM products ORDER BY created_at DESC LIMIT 10");
?>
<h4 class="mb-4"><i class="fas fa-file-csv"></i> Bulk Import / Export</h4>
<div class="row g-4">
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h5><i class="fas fa-upload text-primary"></i> Import Products (CSV)</h5>
            <p class="text-muted small">CSV format: Name, Price, Stock, Category, Brand, Description</p>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="import_csv" value="1">
                <div class="mb-3"><input type="file" name="csv_file" class="form-control" accept=".csv" required></div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Import</button>
            </form>
            <hr>
            <h6>Sample CSV Format:</h6>
            <pre class="small bg-dark p-2 rounded">iPhone 15,169999,50,Electronics,Apple,Apple iPhone 15
Samsung S24,134999,30,Electronics,Samsung,Galaxy S24</pre>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h5><i class="fas fa-download text-success"></i> Export Products</h5>
            <p class="text-muted small">Download all products as CSV file.</p>
            <form method="POST">
                <input type="hidden" name="export_csv" value="1">
                <button type="submit" class="btn btn-success"><i class="fas fa-download"></i> Export All Products</button>
            </form>
        </div>
    </div>
</div>
<div class="row g-4 mt-2">
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h6><i class="fas fa-exclamation-triangle text-warning"></i> Low Stock Products (<?= count($lowStock) ?>)</h6>
            <?php if (empty($lowStock)): ?><p class="text-muted small">All products well stocked.</p>
            <?php else: ?><ul class="list-group list-group-flush"><?php foreach ($lowStock as $ls): ?>
            <li class="list-group-item d-flex justify-content-between small"><span><?= htmlspecialchars($ls['name']) ?></span><span class="badge bg-<?= $ls['stock']==0?'danger':'warning' ?>"><?= $ls['stock'] ?> left</span></li>
            <?php endforeach; ?></ul><?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h6><i class="fas fa-clock text-info"></i> Recently Added Products</h6>
            <?php foreach ($recentProducts as $rp): ?>
            <div class="d-flex justify-content-between small mb-1 py-1 border-bottom">
                <span><?= htmlspecialchars($rp['name']) ?></span>
                <span class="text-muted"><?= formatPrice($rp['price']) ?> | Stock: <?= $rp['stock'] ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
