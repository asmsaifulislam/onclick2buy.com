<?php
$pageTitle = 'Invoice Records';
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn() || !isAdmin()) { redirect(SITE_URL . '/admin/login.php'); }

if (isset($_POST['action']) && $_POST['action'] == 'edit_invoice') {
    $oid = (int)$_POST['order_id'];
    query("UPDATE orders SET shipping_name=?, shipping_phone=?, shipping_address=?, shipping_city=?, shipping_area=?, payment_method=?, payment_status=?, status=?, shipping_cost=?, discount=?, notes=?, updated_at=? WHERE id=?", [
        trim($_POST['shipping_name']),
        trim($_POST['shipping_phone']),
        trim($_POST['shipping_address']),
        trim($_POST['shipping_city']),
        trim($_POST['shipping_area']),
        $_POST['payment_method'],
        $_POST['payment_status'],
        $_POST['status'],
        (float)$_POST['shipping_cost'],
        (float)$_POST['discount'],
        trim($_POST['notes']),
        date('Y-m-d H:i:s'),
        $oid
    ]);
    $newTotal = (float)$_POST['subtotal'] + (float)$_POST['shipping_cost'] - (float)$_POST['discount'];
    query("UPDATE orders SET total=? WHERE id=?", [$newTotal, $oid]);
    query("INSERT INTO activity_log (user_id, action, details, created_at) VALUES (?, 'invoice_updated', ?, ?)", [$_SESSION['user_id'], "Invoice #{$oid} updated", date('Y-m-d H:i:s')]);
    setAlert('success', "Invoice updated successfully.");
    header("Location: invoices.php");
    exit;
}

require_once __DIR__ . '/../includes/admin_header.php';

$search = trim($_GET['search'] ?? '');
$filterStatus = $_GET['status'] ?? '';
$filterMethod = $_GET['method'] ?? '';
$filterDate = $_GET['date'] ?? '';
$customFrom = $_GET['from'] ?? '';
$customTo = $_GET['to'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$offset = ($page - 1) * $perPage;

$where = ["1=1"];
$params = [];

if ($search) {
    $where[] = "(o.order_number LIKE ? OR o.shipping_name LIKE ? OR o.shipping_phone LIKE ? OR u.username LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}
if ($filterStatus) {
    $where[] = "o.status = ?";
    $params[] = $filterStatus;
}
if ($filterMethod) {
    $where[] = "o.payment_method = ?";
    $params[] = $filterMethod;
}
if ($filterDate == 'today') {
    $where[] = "DATE(o.created_at) = ?";
    $params[] = date('Y-m-d');
} elseif ($filterDate == '7') {
    $where[] = "o.created_at >= ?";
    $params[] = date('Y-m-d H:i:s', strtotime('-7 days'));
} elseif ($filterDate == '30') {
    $where[] = "o.created_at >= ?";
    $params[] = date('Y-m-d H:i:s', strtotime('-30 days'));
} elseif ($filterDate == 'custom' && $customFrom && $customTo) {
    $where[] = "DATE(o.created_at) BETWEEN ? AND ?";
    $params[] = $customFrom;
    $params[] = $customTo;
}

$whereSql = implode(' AND ', $where);

$totalCount = count_rows("SELECT COUNT(*) FROM orders o LEFT JOIN users u ON o.user_id=u.id WHERE {$whereSql}", $params);
$invoices = fetchAll("SELECT o.*, u.username FROM orders o LEFT JOIN users u ON o.user_id=u.id WHERE {$whereSql} ORDER BY o.created_at DESC LIMIT {$perPage} OFFSET {$offset}", $params);
$totalPages = ceil($totalCount / $perPage);

$totalRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled'");
$totalPaid = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE payment_status='paid'");
$totalPending = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE payment_status='pending'");
$avgInvoice = $totalCount > 0 ? $totalRevenue / $totalCount : 0;

$methodColors = ['bkash' => '#e91e63', 'nagad' => '#ff5722', 'rocket' => '#9c27b0', 'cod' => '#4caf50', 'visa' => '#1a237e', 'mastercard' => '#ff9800'];
$statusColors = ['pending' => 'warning', 'confirmed' => 'info', 'shipped' => 'primary', 'delivered' => 'success', 'cancelled' => 'danger'];
?>

<style>
.inv-num{font-family:'Courier New',monospace;font-weight:700;color:#e94560;font-size:.85rem}
.inv-amount{font-weight:700;font-size:.95rem}
.inv-badge{padding:3px 10px;border-radius:6px;font-size:.7rem;font-weight:600;text-transform:uppercase}
.report-card{border-radius:14px;padding:20px;text-align:center;position:relative;overflow:hidden}
.report-card::before{content:'';position:absolute;top:-20px;right:-20px;width:80px;height:80px;border-radius:50%;opacity:.1}
.report-card h3{font-size:1.6rem;font-weight:800;margin:8px 0 4px}
.report-card p{font-size:.75rem;text-transform:uppercase;letter-spacing:1px;opacity:.7;margin:0}
.report-card .icon{font-size:2rem;opacity:.3;position:absolute;right:15px;top:15px}
.edit-modal .modal-content{background:#1a1a2e;color:#e0e0e0;border:1px solid rgba(255,255,255,0.1);border-radius:16px}
.edit-modal .modal-header{border-bottom:1px solid rgba(255,255,255,0.1)}
.edit-modal .modal-footer{border-top:1px solid rgba(255,255,255,0.1)}
.edit-modal .form-label{color:#aaa;font-size:.8rem}
.edit-modal .form-control,.edit-modal .form-select{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:#fff;border-radius:8px;font-size:.85rem}
.edit-modal .form-control:focus,.edit-modal .form-select:focus{border-color:#e94560;box-shadow:0 0 0 2px rgba(233,69,96,0.2);color:#fff}
.edit-modal .form-select option{background:#1a1a2e;color:#fff}
</style>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0"><i class="fas fa-file-invoice text-primary"></i> Invoice Records</h4>
    <div class="d-flex gap-2">
        <button onclick="exportCSV()" class="btn btn-sm btn-outline-success"><i class="fas fa-file-csv"></i> Excel/CSV</button>
        <button onclick="exportPDF()" class="btn btn-sm btn-outline-danger"><i class="fas fa-file-pdf"></i> PDF</button>
        <button onclick="window.print()" class="btn btn-sm btn-outline-secondary"><i class="fas fa-print"></i> Print</button>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="report-card" style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff">
            <i class="fas fa-file-invoice icon"></i>
            <p>Total Invoices</p>
            <h3><?= $totalCount ?></h3>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="report-card" style="background:linear-gradient(135deg,#11998e,#38ef7d);color:#fff">
            <i class="fas fa-check-circle icon"></i>
            <p>Total Revenue</p>
            <h3><?= formatPrice($totalRevenue) ?></h3>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="report-card" style="background:linear-gradient(135deg,#f093fb,#f5576c);color:#fff">
            <i class="fas fa-clock icon"></i>
            <p>Pending Amount</p>
            <h3><?= formatPrice($totalPending) ?></h3>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="report-card" style="background:linear-gradient(135deg,#4facfe,#00f2fe);color:#fff">
            <i class="fas fa-receipt icon"></i>
            <p>Avg Invoice</p>
            <h3><?= formatPrice($avgInvoice) ?></h3>
        </div>
    </div>
</div>

<div class="card card-custom mb-4">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h6 class="mb-0"><i class="fas fa-list"></i> All Invoices (<?= $totalCount ?>)</h6>
            <form class="d-flex gap-2 flex-wrap" method="GET">
                <input type="text" name="search" class="form-control form-control-sm" placeholder="Search invoice, customer, phone..." value="<?= htmlspecialchars($search) ?>" style="width:240px">
                <select name="status" class="form-select form-select-sm" style="width:130px">
                    <option value="">All Status</option>
                    <option value="pending" <?= $filterStatus=='pending'?'selected':'' ?>>Pending</option>
                    <option value="confirmed" <?= $filterStatus=='confirmed'?'selected':'' ?>>Confirmed</option>
                    <option value="shipped" <?= $filterStatus=='shipped'?'selected':'' ?>>Shipped</option>
                    <option value="delivered" <?= $filterStatus=='delivered'?'selected':'' ?>>Delivered</option>
                    <option value="cancelled" <?= $filterStatus=='cancelled'?'selected':'' ?>>Cancelled</option>
                </select>
                <select name="method" class="form-select form-select-sm" style="width:130px">
                    <option value="">All Methods</option>
                    <option value="bkash" <?= $filterMethod=='bkash'?'selected':'' ?>>bKash</option>
                    <option value="nagad" <?= $filterMethod=='nagad'?'selected':'' ?>>Nagad</option>
                    <option value="rocket" <?= $filterMethod=='rocket'?'selected':'' ?>>Rocket</option>
                    <option value="cod" <?= $filterMethod=='cod'?'selected':'' ?>>COD</option>
                    <option value="visa" <?= $filterMethod=='visa'?'selected':'' ?>>Visa</option>
                </select>
                <select name="date" class="form-select form-select-sm" style="width:130px">
                    <option value="">All Time</option>
                    <option value="today" <?= $filterDate=='today'?'selected':'' ?>>Today</option>
                    <option value="7" <?= $filterDate=='7'?'selected':'' ?>>7 Days</option>
                    <option value="30" <?= $filterDate=='30'?'selected':'' ?>>30 Days</option>
                    <option value="custom" <?= $filterDate=='custom'?'selected':'' ?>>Custom</option>
                </select>
                <?php if ($filterDate == 'custom'): ?>
                <input type="date" name="from" class="form-control form-control-sm" value="<?= $customFrom ?>" style="width:140px">
                <input type="date" name="to" class="form-control form-control-sm" value="<?= $customTo ?>" style="width:140px">
                <?php endif; ?>
                <button class="btn btn-sm btn-primary"><i class="fas fa-search"></i></button>
                <a href="invoices.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i></a>
            </form>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-custom table-sm" id="invoiceTable">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll"></th>
                        <th>Invoice #</th>
                        <th>Customer</th>
                        <th>Phone</th>
                        <th>Items</th>
                        <th>Subtotal</th>
                        <th>Shipping</th>
                        <th>Discount</th>
                        <th>Total</th>
                        <th>Method</th>
                        <th>Payment</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($invoices)): ?>
                    <tr><td colspan="14" class="text-center text-muted py-4">No invoices found</td></tr>
                <?php else: foreach ($invoices as $inv):
                    $itemCount = count_rows("SELECT COUNT(*) FROM order_items WHERE order_id=?", [$inv['id']]);
                ?>
                    <tr>
                        <td><input type="checkbox" class="row-check" value="<?= $inv['id'] ?>"></td>
                        <td><span class="inv-num">#<?= $inv['order_number'] ?></span></td>
                        <td><strong><?= htmlspecialchars($inv['username'] ?? $inv['shipping_name'] ?? 'Guest') ?></strong></td>
                        <td><small><?= htmlspecialchars($inv['shipping_phone'] ?? '') ?></small></td>
                        <td><span class="badge bg-light text-dark"><?= $itemCount ?></span></td>
                        <td><small><?= formatPrice($inv['subtotal'] ?? 0) ?></small></td>
                        <td><small><?= formatPrice($inv['shipping_cost'] ?? 0) ?></small></td>
                        <td><small class="text-danger"><?= ($inv['discount'] ?? 0) > 0 ? '-'.formatPrice($inv['discount']) : '—' ?></small></td>
                        <td class="inv-amount"><?= formatPrice($inv['total']) ?></td>
                        <td><span class="inv-badge" style="background:<?= $methodColors[strtolower($inv['payment_method'])] ?? '#666' ?>;color:#fff"><?= strtoupper($inv['payment_method'] ?? 'N/A') ?></span></td>
                        <td><span class="inv-badge badge-<?= $inv['payment_status']=='paid'?'success':($inv['payment_status']=='failed'?'danger':'warning') ?>"><?= ucfirst($inv['payment_status'] ?? 'pending') ?></span></td>
                        <td><span class="inv-badge badge-<?= $statusColors[$inv['status']] ?? 'secondary' ?>"><?= ucfirst($inv['status']) ?></span></td>
                        <td><small><?= date('M d, Y', strtotime($inv['created_at'])) ?></small></td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="<?= SITE_URL ?>/store/invoice.php?id=<?= $inv['id'] ?>" target="_blank" class="btn btn-sm btn-outline-primary py-0" title="View"><i class="fas fa-eye"></i></a>
                                <button class="btn btn-sm btn-outline-warning py-0" onclick='editInvoice(<?= json_encode($inv) ?>)' title="Edit"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-sm btn-outline-info py-0" onclick="printSingle(<?= $inv['id'] ?>)" title="Print"><i class="fas fa-print"></i></button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
                <tfoot>
                    <tr style="font-weight:700;background:#f8f9fa">
                        <td colspan="5" class="text-end">Total:</td>
                        <td><?= formatPrice(array_sum(array_column($invoices, 'subtotal'))) ?></td>
                        <td><?= formatPrice(array_sum(array_column($invoices, 'shipping_cost'))) ?></td>
                        <td class="text-danger">-<?= formatPrice(array_sum(array_column($invoices, 'discount'))) ?></td>
                        <td class="text-primary fs-6"><?= formatPrice(array_sum(array_column($invoices, 'total'))) ?></td>
                        <td colspan="5"></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <small class="text-muted">Showing <?= $offset+1 ?>-<?= min($offset+$perPage, $totalCount) ?> of <?= $totalCount ?> invoices</small>
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if ($page > 1): ?>
                    <li class="page-item"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$page-1])) ?>">&laquo;</a></li>
                    <?php endif; ?>
                    <?php for ($i = max(1,$page-2); $i <= min($totalPages,$page+2); $i++): ?>
                    <li class="page-item <?= $i==$page?'active':'' ?>"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$i])) ?>"><?= $i ?></a></li>
                    <?php endfor; ?>
                    <?php if ($page < $totalPages): ?>
                    <li class="page-item"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$page+1])) ?>">&raquo;</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="modal fade edit-modal" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="edit_invoice">
                <input type="hidden" name="order_id" id="editOrderId">
                <input type="hidden" name="subtotal" id="editSubtotal">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit text-warning"></i> Edit Invoice — <span id="editInvNum" class="text-primary"></span></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Customer Name</label>
                            <input type="text" name="shipping_name" id="editName" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Phone</label>
                            <input type="text" name="shipping_phone" id="editPhone" class="form-control">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Address</label>
                            <input type="text" name="shipping_address" id="editAddress" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">City</label>
                            <input type="text" name="shipping_city" id="editCity" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Area</label>
                            <input type="text" name="shipping_area" id="editArea" class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Payment Method</label>
                            <select name="payment_method" id="editMethod" class="form-select">
                                <option value="bkash">bKash</option>
                                <option value="nagad">Nagad</option>
                                <option value="rocket">Rocket</option>
                                <option value="cod">COD</option>
                                <option value="visa">Visa</option>
                                <option value="mastercard">Mastercard</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Payment Status</label>
                            <select name="payment_status" id="editPayStatus" class="form-select">
                                <option value="pending">Pending</option>
                                <option value="paid">Paid</option>
                                <option value="failed">Failed</option>
                                <option value="refunded">Refunded</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Order Status</label>
                            <select name="status" id="editStatus" class="form-select">
                                <option value="pending">Pending</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="shipped">Shipped</option>
                                <option value="delivered">Delivered</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Shipping Cost (৳)</label>
                            <input type="number" name="shipping_cost" id="editShipping" class="form-control" step="0.01" min="0">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Discount (৳)</label>
                            <input type="number" name="discount" id="editDiscount" class="form-control" step="0.01" min="0">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Total</label>
                            <input type="text" id="editTotalDisplay" class="form-control" readonly style="font-weight:700;color:#e94560">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" id="editNotes" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="<?= SITE_URL ?>/assets/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('selectAll')?.addEventListener('change', function(){
    document.querySelectorAll('.row-check').forEach(c => c.checked = this.checked);
});

function printSingle(id) { window.open('<?= SITE_URL ?>/store/invoice.php?id=' + id, '_blank'); }

function editInvoice(o) {
    document.getElementById('editOrderId').value = o.id;
    document.getElementById('editInvNum').textContent = '#' + o.order_number;
    document.getElementById('editName').value = o.shipping_name || '';
    document.getElementById('editPhone').value = o.shipping_phone || '';
    document.getElementById('editAddress').value = o.shipping_address || '';
    document.getElementById('editCity').value = o.shipping_city || '';
    document.getElementById('editArea').value = o.shipping_area || '';
    document.getElementById('editMethod').value = o.payment_method || 'cod';
    document.getElementById('editPayStatus').value = o.payment_status || 'pending';
    document.getElementById('editStatus').value = o.status || 'pending';
    document.getElementById('editShipping').value = o.shipping_cost || 0;
    document.getElementById('editDiscount').value = o.discount || 0;
    document.getElementById('editSubtotal').value = o.subtotal || 0;
    document.getElementById('editNotes').value = o.notes || '';
    calcTotal();
    new bootstrap.Modal(document.getElementById('editModal')).show();
}

function calcTotal() {
    var sub = parseFloat(document.getElementById('editSubtotal').value) || 0;
    var ship = parseFloat(document.getElementById('editShipping').value) || 0;
    var disc = parseFloat(document.getElementById('editDiscount').value) || 0;
    document.getElementById('editTotalDisplay').value = '৳' + (sub + ship - disc).toLocaleString(undefined, {minimumFractionDigits:0});
}

document.getElementById('editShipping')?.addEventListener('input', calcTotal);
document.getElementById('editDiscount')?.addEventListener('input', calcTotal);

function exportCSV() {
    var rows = [['Invoice #','Customer','Phone','Items','Subtotal','Shipping','Discount','Total','Method','Payment Status','Order Status','Date']];
    document.querySelectorAll('#invoiceTable tbody tr').forEach(function(tr) {
        var cells = tr.querySelectorAll('td');
        if (cells.length >= 13) {
            rows.push([cells[1].textContent.trim(),cells[2].textContent.trim(),cells[3].textContent.trim(),cells[4].textContent.trim(),cells[5].textContent.trim(),cells[6].textContent.trim(),cells[7].textContent.trim(),cells[8].textContent.trim(),cells[9].textContent.trim(),cells[10].textContent.trim(),cells[11].textContent.trim(),cells[12].textContent.trim()]);
        }
    });
    var csv = rows.map(function(r){ return r.map(function(c){ return '"'+c.replace(/"/g,'""')+'"'; }).join(','); }).join('\n');
    var blob = new Blob(['\uFEFF' + csv], {type:'text/csv;charset=utf-8'});
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'invoices_<?= date('Y-m-d') ?>.csv'; a.click();
}

function exportPDF() {
    var p = '<html><head><title>Invoices</title><link href="<?= SITE_URL ?>/assets/css/bootstrap.min.css" rel="stylesheet"><style>body{font-size:10px}h2{color:#e94560}.rh{border-bottom:3px solid #e94560;padding-bottom:10px;margin-bottom:15px}</style></head><body><div class="rh"><h2>Quick Mart — Invoices Report</h2><p>Generated: <?= date('F d, Y H:i') ?> | Total: <?= $totalCount ?> | Revenue: <?= formatPrice($totalRevenue) ?></p></div><table class="table table-bordered table-sm"><thead><tr><th>Invoice #</th><th>Customer</th><th>Phone</th><th>Total</th><th>Method</th><th>Payment</th><th>Status</th><th>Date</th></tr></thead><tbody>';
    document.querySelectorAll('#invoiceTable tbody tr').forEach(function(tr) {
        var c = tr.querySelectorAll('td');
        if (c.length >= 13) { p += '<tr><td>'+c[1].textContent.trim()+'</td><td>'+c[2].textContent.trim()+'</td><td>'+c[3].textContent.trim()+'</td><td>'+c[8].textContent.trim()+'</td><td>'+c[9].textContent.trim()+'</td><td>'+c[10].textContent.trim()+'</td><td>'+c[11].textContent.trim()+'</td><td>'+c[12].textContent.trim()+'</td></tr>'; }
    });
    p += '</tbody></table><p class="text-muted mt-3">Quick Mart — Confidential</p></body></html>';
    var w = window.open('','_blank'); w.document.write(p); w.document.close(); w.print();
}
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
