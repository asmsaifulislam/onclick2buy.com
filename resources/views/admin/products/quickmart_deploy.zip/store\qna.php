<?php
$pageTitle = 'Product Q&A - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');

$productId = (int)($_GET['product_id'] ?? $_POST['product_id'] ?? 0);
$product = fetch("SELECT id, name, slug FROM products WHERE id=?", [$productId]);
if (!$product) redirect(SITE_URL . '/store/products.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['question'])) {
        $question = trim($_POST['question']);
        if ($question) {
            query("INSERT INTO product_questions (user_id, product_id, question) VALUES (?,?,?)", [$_SESSION['user_id'], $productId, $question]);
            setAlert('success', 'Your question has been submitted!');
        }
    } elseif (isset($_POST['answer'])) {
        if (isAdmin()) {
            $qId = (int)$_POST['question_id'];
            $answer = trim($_POST['answer_text']);
            if ($qId && $answer) {
                query("UPDATE product_questions SET answer=?, answered_by=?, is_answered=1 WHERE id=?", [$answer, $_SESSION['user_id'], $qId]);
                setAlert('success', 'Answer posted!');
            }
        }
    }
    redirect(SITE_URL . '/store/qna.php?product_id=' . $productId);
}

$questions = fetchAll("SELECT pq.*, u.username as asker_name, au.username as answerer_name FROM product_questions pq LEFT JOIN users u ON pq.user_id=u.id LEFT JOIN users au ON pq.answered_by=au.id WHERE pq.product_id=? ORDER BY pq.created_at DESC", [$productId]);
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <h4 class="mb-2"><i class="fas fa-question-circle"></i> Q&A for <?= htmlspecialchars($product['name']) ?></h4>
        <p><a href="<?= SITE_URL ?>/store/product.php?slug=<?= $product['slug'] ?>"><i class="fas fa-arrow-left"></i> Back to product</a></p>

        <?php if (isLoggedIn()): ?>
        <div class="card card-custom p-4 mb-4">
            <h6>Ask a Question</h6>
            <form method="POST" class="d-flex gap-2">
                <input type="hidden" name="product_id" value="<?= $productId ?>">
                <input type="text" name="question" class="form-control" placeholder="Type your question about this product..." required>
                <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Ask</button>
            </form>
        </div>
        <?php endif; ?>

        <?php if (empty($questions)): ?>
        <div class="card card-custom p-4 text-center"><p class="text-muted mb-0">No questions yet. Be the first to ask!</p></div>
        <?php else: ?>
        <?php foreach ($questions as $q): ?>
        <div class="card card-custom p-4 mb-3">
            <div class="d-flex align-items-start mb-2">
                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2" style="width:32px;height:32px;font-size:14px;">Q</div>
                <div class="flex-grow-1">
                    <div class="d-flex justify-content-between">
                        <strong><?= htmlspecialchars($q['asker_name']) ?></strong>
                        <small class="text-muted"><?= date('M d, Y', strtotime($q['created_at'])) ?></small>
                    </div>
                    <p class="mb-0 mt-1"><?= htmlspecialchars($q['question']) ?></p>
                </div>
            </div>
            <?php if ($q['is_answered']): ?>
            <div class="d-flex align-items-start ms-4 mt-2 p-3 bg-light rounded">
                <div class="rounded-circle bg-success text-white d-flex align-items-center justify-content-center me-2" style="width:32px;height:32px;font-size:14px;">A</div>
                <div class="flex-grow-1">
                    <div class="d-flex justify-content-between">
                        <strong><?= htmlspecialchars($q['answerer_name'] ?? 'Admin') ?> <span class="badge bg-success">Staff</span></strong>
                    </div>
                    <p class="mb-0 mt-1"><?= nl2br(htmlspecialchars($q['answer'])) ?></p>
                </div>
            </div>
            <?php elseif (isAdmin()): ?>
            <form method="POST" class="ms-4 mt-2 p-3 bg-light rounded">
                <input type="hidden" name="product_id" value="<?= $productId ?>">
                <input type="hidden" name="question_id" value="<?= $q['id'] ?>">
                <label class="form-label fw-bold small">Your Answer:</label>
                <textarea name="answer_text" class="form-control mb-2" rows="2" required placeholder="Type your answer..."></textarea>
                <button type="submit" name="answer" value="1" class="btn btn-sm btn-success"><i class="fas fa-reply"></i> Post Answer</button>
            </form>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
