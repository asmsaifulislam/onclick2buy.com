<?php
$pageTitle = 'Loyalty Points - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');

$points = fetch("SELECT * FROM loyalty_points WHERE user_id=?", [$_SESSION['user_id']]);
if (!$points) { query("INSERT INTO loyalty_points (user_id, points, total_earned, total_redeemed) VALUES (?,?,?,?)", [$_SESSION['user_id'], 0, 0, 0]); $points = ['points'=>0,'total_earned'=>0,'total_redeemed'=>0]; }
$transactions = fetchAll("SELECT * FROM loyalty_transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 20", [$_SESSION['user_id']]);
$balance = $points['points'] ?? 0;
$redeemable = floor($balance / 100);
?>
<h2 class="mb-4"><i class="fas fa-star text-warning"></i> Loyalty Points</h2>
<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card card-custom p-4 text-center">
            <i class="fas fa-coins fa-3x text-warning mb-3"></i>
            <h2 class="text-primary"><?= number_format($balance) ?></h2>
            <p class="text-muted">Available Points</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-custom p-4 text-center">
            <i class="fas fa-arrow-up fa-3x text-success mb-3"></i>
            <h3 class="text-success"><?= number_format($points['total_earned'] ?? 0) ?></h3>
            <p class="text-muted">Total Earned</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-custom p-4 text-center">
            <i class="fas fa-arrow-down fa-3x text-danger mb-3"></i>
            <h3 class="text-danger"><?= number_format($points['total_redeemed'] ?? 0) ?></h3>
            <p class="text-muted">Total Redeemed</p>
        </div>
    </div>
</div>
<div class="card card-custom p-4 mb-4">
    <h5>Redeem Points</h5>
    <p class="text-muted">100 points = BDT 1 discount. You can redeem up to <?= $redeemable ?> BDT.</p>
    <p class="small text-muted">Earn 1 point for every BDT 10 spent on orders.</p>
</div>
<div class="card card-custom p-4">
    <h5>Points History</h5>
    <?php if (empty($transactions)): ?>
    <p class="text-muted">No transactions yet.</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-sm table-custom">
            <thead><tr><th>Date</th><th>Type</th><th>Points</th><th>Description</th></tr></thead>
            <tbody>
                <?php foreach ($transactions as $t): ?>
                <tr>
                    <td><?= date('M d, Y', strtotime($t['created_at'])) ?></td>
                    <td><span class="badge bg-<?= $t['tx_type']=='earned'?'success':'danger' ?>"><?= ucfirst($t['tx_type']) ?></span></td>
                    <td class="fw-bold <?= $t['tx_type']=='earned'?'text-success':'text-danger' ?>"><?= $t['tx_type']=='earned'?'+':'' ?><?= $t['points'] ?></td>
                    <td><?= htmlspecialchars($t['description']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
