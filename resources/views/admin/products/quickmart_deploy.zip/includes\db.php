<?php
require_once __DIR__ . '/../config.php';

function db() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dbPath = defined('DB_PATH') ? DB_PATH : (defined('DB_HOST') ? null : __DIR__ . '/../quickmart.db');
            if ($dbPath) {
                $pdo = new PDO('sqlite:' . $dbPath);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                $pdo->exec("PRAGMA journal_mode=WAL");
                $pdo->exec("PRAGMA foreign_keys=ON");
            } else {
                // Try multiple MySQL connection methods
                $hosts = [DB_HOST, 'shareddb-y.hosting.stackcp.net', '127.0.0.1', 'localhost'];
                foreach ($hosts as $tryHost) {
                    try {
                        $pdo = new PDO("mysql:host=$tryHost;dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                        break;
                    } catch (PDOException $e) {
                        $pdo = null;
                        continue;
                    }
                }
                if ($pdo === null) {
                    die("Database connection failed. Run install.php first.");
                }
            }
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage() . ". Run install.php first.");
        }
    }
    return $pdo;
}

function query($sql, $params = []) {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

function fetch($sql, $params = []) {
    return query($sql, $params)->fetch();
}

function fetchAll($sql, $params = []) {
    return query($sql, $params)->fetchAll();
}

function insertId($sql, $params = []) {
    query($sql, $params);
    return db()->lastInsertId();
}

function count_rows($sql, $params = []) {
    return query($sql, $params)->fetchColumn();
}
