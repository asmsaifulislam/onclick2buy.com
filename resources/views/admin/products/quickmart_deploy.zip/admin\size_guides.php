<?php
$pageTitle = 'Size Guides';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM size_guides WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/size_guides.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [(int)$_POST['category_id'], $_POST['name'], $_POST['sizes']];
    if ($id) { query("UPDATE size_guides SET category_id=?, name=?, sizes=? WHERE id=?", array_merge($data, [$id])); }
    else { query("INSERT INTO size_guides (category_id, name, sizes) VALUES (?,?,?)", $data); }
    setAlert('success', 'Size guide saved!'); redirect(SITE_URL . '/admin/size_guides.php');
}
$guides = fetchAll("SELECT sg.*, c.name as category_name FROM size_guides sg LEFT JOIN categories c ON sg.category_id=c.id ORDER BY sg.category_id, sg.name");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Size Guides</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_cat').value='';document.getElementById('f_size').value='';document.getElementById('f_meas').value='';document.getElementById('modalTitle').textContent='Add Size Guide';"><i class="fas fa-plus"></i> Add</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>Category</th><th>Size Name</th><th>Sizes (JSON)</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($guides as $g): ?>
<tr><td><strong><?= htmlspecialchars($g['category_name'] ?? 'N/A') ?></strong></td><td><?= htmlspecialchars($g['name']) ?></td><td class="small"><?= htmlspecialchars($g['sizes']) ?></td>
<td><button class="btn btn-sm btn-warning" onclick="document.getElementById('f_id').value='<?= $g['id'] ?>';document.getElementById('f_cat').value='<?= $g['category_id'] ?>';document.getElementById('f_size').value='<?= htmlspecialchars($g['name']) ?>';document.getElementById('f_meas').value='<?= htmlspecialchars($g['sizes']) ?>';document.getElementById('modalTitle').textContent='Edit Size Guide';new bootstrap.Modal(document.getElementById('modal')).show();"><i class="fas fa-edit"></i></button> <a href="?delete=<?= $g['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Size Guide</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">Category ID</label><input type="number" name="category_id" id="f_cat" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Size Name</label><input type="text" name="name" id="f_size" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Sizes (JSON)</label><textarea name="sizes" id="f_meas" class="form-control" required></textarea></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
