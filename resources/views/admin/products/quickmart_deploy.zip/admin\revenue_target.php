<?php
$pageTitle = 'Revenue Target';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM revenue_targets WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/revenue_target.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [(float)$_POST['target_amount'], (int)$_POST['month'], (int)$_POST['year']];
    if ($id) { query("UPDATE revenue_targets SET target_amount=?, month=?, year=? WHERE id=?", array_merge($data, [$id])); }
    else { query("INSERT INTO revenue_targets (target_amount, month, year) VALUES (?,?,?)", $data); }
    setAlert('success', 'Target saved!'); redirect(SITE_URL . '/admin/revenue_target.php');
}
$targets = fetchAll("SELECT rt.*, COALESCE(SUM(o.total), 0) as actual_revenue FROM revenue_targets rt LEFT JOIN orders o ON " . sqlMonth('o.created_at') . "=rt.month AND " . sqlYear('o.created_at') . "=rt.year AND o.status != 'cancelled' GROUP BY rt.id ORDER BY rt.year DESC, rt.month DESC");
$targetOptions = fetchAll("SELECT rt.*, COALESCE((SELECT SUM(o.total) FROM orders o WHERE " . sqlMonth('o.created_at') . "=rt.month AND " . sqlYear('o.created_at') . "=rt.year AND o.status != 'cancelled'),0) as actual FROM revenue_targets rt");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Revenue Targets</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_amount').value='';document.getElementById('f_month').value='';document.getElementById('f_year').value='';document.getElementById('modalTitle').textContent='Add Target';"><i class="fas fa-plus"></i> Add Target</button>
</div>
<?php foreach ($targets as $t): 
$pct = $t['target_amount'] > 0 ? min(100, round(($t['actual_revenue'] / $t['target_amount']) * 100)) : 0;
?>
<div class="card card-custom mb-3"><div class="card-body">
<div class="d-flex justify-content-between align-items-center mb-2">
<div><h5 class="mb-0">Target: <?= formatPrice($t['target_amount']) ?></h5><small class="text-muted"><?= $t['month'] ?>/<?= $t['year'] ?></small></div>
<div><a href="?delete=<?= $t['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></div></div>
<div class="row text-center mb-2"><div class="col"><strong class="text-success"><?= formatPrice($t['actual_revenue']) ?></strong><br><small>Actual</small></div>
<div class="col"><strong class="text-primary"><?= formatPrice($t['target_amount']) ?></strong><br><small>Target</small></div>
<div class="col"><strong class="<?= $pct>=100?'text-success':'text-warning' ?>"><?= $pct ?>%</strong><br><small>Progress</small></div></div>
<div class="progress" style="height:20px"><div class="progress-bar <?= $pct>=100?'bg-success':'bg-warning' ?>" style="width:<?= $pct ?>%"><?= $pct ?>%</div></div>
</div></div>
<?php endforeach; ?>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Target</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">Target Amount</label><input type="number" step="0.01" name="target_amount" id="f_amount" class="form-control" required></div>
<div class="row g-3 mb-3"><div class="col-6"><label class="form-label">Month</label><input type="number" min="1" max="12" name="month" id="f_month" class="form-control" required></div>
<div class="col-6"><label class="form-label">Year</label><input type="number" min="2020" max="2099" name="year" id="f_year" class="form-control" required></div></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
