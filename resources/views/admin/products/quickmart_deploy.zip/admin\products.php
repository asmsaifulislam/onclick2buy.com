<?php
$pageTitle = 'Manage Products';
require_once __DIR__ . '/../includes/admin_header.php';

if (isset($_GET['delete'])) {
    query("DELETE FROM products WHERE id=?", [(int)$_GET['delete']]);
    setAlert('success', 'Product deleted.');
    redirect(SITE_URL . '/admin/products.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [
        $_POST['name'], slugify($_POST['name']), $_POST['description'],
        (float)$_POST['price'], (int)$_POST['stock'], (int)$_POST['category_id'],
        $_POST['brand'] ?? '', $_POST['image'] ?? ''
    ];
    if ($id) {
        query("UPDATE products SET name=?, slug=?, description=?, price=?, stock=?, category_id=?, brand=?, image=? WHERE id=?", array_merge($data, [$id]));
        setAlert('success', 'Product updated!');
    } else {
        query("INSERT INTO products (name, slug, description, price, stock, category_id, brand, image) VALUES (?,?,?,?,?,?,?,?)", $data);
        setAlert('success', 'Product added!');
    }
    redirect(SITE_URL . '/admin/products.php');
}

$editProduct = null;
if (isset($_GET['edit'])) {
    $editProduct = fetch("SELECT * FROM products WHERE id=?", [(int)$_GET['edit']]);
}

$products = fetchAll("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id ORDER BY p.created_at DESC");
$categories = getCategories();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Products (<?= count($products) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#productModal" onclick="resetForm()">
        <i class="fas fa-plus"></i> Add Product
    </button>
</div>

<div class="card card-custom">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-custom">
                <thead><tr><th>ID</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Rating</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($products as $p): ?>
                    <tr>
                        <td><?= $p['id'] ?></td>
                        <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
                        <td><?= htmlspecialchars($p['cat_name'] ?? '-') ?></td>
                        <td class="text-primary fw-bold"><?= formatPrice($p['price']) ?></td>
                        <td><span class="badge bg-<?= $p['stock'] > 10 ? 'success' : ($p['stock'] > 0 ? 'warning' : 'danger') ?>"><?= $p['stock'] ?></span></td>
                        <td><?= $p['average_rating'] ?>/5</td>
                        <td>
                            <button class="btn btn-sm btn-warning" onclick='editProduct(<?= json_encode($p) ?>)'><i class="fas fa-edit"></i></button>
                            <a href="?delete=<?= $p['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this product?')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="productModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">Add Product</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="p_id">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" id="p_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" id="p_desc" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label">Price (BDT)</label>
                            <input type="number" name="price" id="p_price" class="form-control" step="0.01" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label">Stock</label>
                            <input type="number" name="stock" id="p_stock" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3 mt-3">
                        <label class="form-label">Category</label>
                        <select name="category_id" id="p_category" class="form-select" required>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Brand</label>
                        <input type="text" name="brand" id="p_brand" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Image filename</label>
                        <input type="text" name="image" id="p_image" class="form-control" placeholder="product.jpg">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('p_id').value = '';
    document.getElementById('p_name').value = '';
    document.getElementById('p_desc').value = '';
    document.getElementById('p_price').value = '';
    document.getElementById('p_stock').value = '';
    document.getElementById('p_brand').value = '';
    document.getElementById('p_image').value = '';
    document.getElementById('modalTitle').textContent = 'Add Product';
}
function editProduct(p) {
    document.getElementById('p_id').value = p.id;
    document.getElementById('p_name').value = p.name;
    document.getElementById('p_desc').value = p.description || '';
    document.getElementById('p_price').value = p.price;
    document.getElementById('p_stock').value = p.stock;
    document.getElementById('p_category').value = p.category_id || '';
    document.getElementById('p_brand').value = p.brand || '';
    document.getElementById('p_image').value = p.image || '';
    document.getElementById('modalTitle').textContent = 'Edit Product';
    new bootstrap.Modal(document.getElementById('productModal')).show();
}
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
