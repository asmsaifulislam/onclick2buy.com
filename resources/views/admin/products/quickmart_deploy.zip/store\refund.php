<?php
$pageTitle = 'Request Refund - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');

$orderId = (int)($_GET['id'] ?? $_POST['order_id'] ?? 0);
$order = fetch("SELECT * FROM orders WHERE id=? AND user_id=? AND status IN ('delivered','shipped')", [$orderId, $_SESSION['user_id']]);
if (!$order) { setAlert('danger', 'Order not eligible for refund.'); redirect(SITE_URL . '/store/orders.php'); }

$existing = fetch("SELECT * FROM refund_requests WHERE order_id=?", [$orderId]);
if ($existing) { setAlert('info', 'Refund already requested for this order.'); redirect(SITE_URL . '/store/order_detail.php?id=' . $orderId); }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $reason = trim($_POST['reason'] ?? '');
    $amount = (float)($_POST['amount'] ?? 0);
    if ($reason && $amount > 0 && $amount <= $order['total']) {
        query("INSERT INTO refund_requests (order_id, user_id, reason, amount, status) VALUES (?,?,?,?, 'pending')", [$orderId, $_SESSION['user_id'], $reason, $amount]);
        setAlert('success', 'Refund request submitted! We will process it within 3-5 business days.');
        redirect(SITE_URL . '/store/order_detail.php?id=' . $orderId);
    } else {
        setAlert('danger', 'Please provide a valid reason and amount.');
    }
}
$items = fetchAll("SELECT * FROM order_items WHERE order_id=?", [$orderId]);
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <h4 class="mb-3"><i class="fas fa-undo"></i> Request Refund for Order #<?= $order['order_number'] ?></h4>
        <div class="card card-custom p-4 mb-4">
            <div class="row mb-3">
                <div class="col-md-6"><strong>Order Date:</strong> <?= date('M d, Y', strtotime($order['created_at'])) ?></div>
                <div class="col-md-6"><strong>Total:</strong> <?= formatPrice($order['total']) ?></div>
                <div class="col-md-6"><strong>Status:</strong> <?= ucfirst($order['status']) ?></div>
                <div class="col-md-6"><strong>Payment:</strong> <?= strtoupper($order['payment_method']) ?></div>
            </div>
            <h6>Order Items:</h6>
            <?php foreach ($items as $item): ?>
            <div class="d-flex justify-content-between mb-1 py-1 border-bottom small">
                <span><?= htmlspecialchars($item['product_name']) ?> x<?= $item['quantity'] ?></span>
                <span><?= formatPrice($item['price'] * $item['quantity']) ?></span>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="card card-custom p-4">
            <h5 class="mb-3">Refund Details</h5>
            <form method="POST">
                <input type="hidden" name="order_id" value="<?= $orderId ?>">
                <div class="mb-3">
                    <label class="form-label fw-bold">Refund Amount (Max: <?= formatPrice($order['total']) ?>)</label>
                    <input type="number" step="0.01" name="amount" class="form-control" max="<?= $order['total'] ?>" value="<?= $order['total'] ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Reason for Refund</label>
                    <select class="form-select mb-2" onchange="if(this.value==='other')document.getElementById('customReason').style.display='block';else document.getElementById('customReason').style.display='none'">
                        <option value="">Select reason...</option>
                        <option value="wrong item received">Wrong item received</option>
                        <option value="item damaged">Item damaged/defective</option>
                        <option value="not as described">Not as described</option>
                        <option value="changed mind">Changed my mind</option>
                        <option value="quality issue">Quality issue</option>
                        <option value="late delivery">Late delivery</option>
                        <option value="other">Other (specify below)</option>
                    </select>
                    <textarea name="reason" id="customReason" class="form-control" rows="3" placeholder="Please describe the reason..." style="display:none" required></textarea>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-danger"><i class="fas fa-paper-plane"></i> Submit Refund Request</button>
                    <a href="<?= SITE_URL ?>/store/order_detail.php?id=<?= $orderId ?>" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
