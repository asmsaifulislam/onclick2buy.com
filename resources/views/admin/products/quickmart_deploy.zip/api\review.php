<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn()) { setAlert('danger', 'Please login first.'); redirect(SITE_URL . '/store/login.php'); }

$productId = (int)($_POST['product_id'] ?? 0);
$rating = max(1, min(5, (int)($_POST['rating'] ?? 5)));
$comment = trim($_POST['comment'] ?? '');

if ($productId && $comment) {
    query("INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?,?,?,?)", [$productId, $_SESSION['user_id'], $rating, $comment]);
    
    $avg = fetch("SELECT AVG(rating) as avg_rating, COUNT(*) as cnt FROM reviews WHERE product_id=?", [$productId]);
    query("UPDATE products SET average_rating=?, total_reviews=? WHERE id=?", [round($avg['avg_rating'], 2), $avg['cnt'], $productId]);
    
    setAlert('success', 'Review submitted!');
}

$product = fetch("SELECT slug FROM products WHERE id=?", [$productId]);
redirect(SITE_URL . '/store/product.php?slug=' . ($product['slug'] ?? ''));
