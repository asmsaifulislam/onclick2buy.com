<?php
$pageTitle = 'Track Order - Quick Mart';
require_once __DIR__ . '/../includes/header.php';

$order = null;
$tracking = [];
$trackingNumber = $_GET['number'] ?? $_POST['number'] ?? '';

if ($trackingNumber) {
    $order = fetch("SELECT * FROM orders WHERE order_number=?", [$trackingNumber]);
    if ($order) {
        $tracking = fetchAll("SELECT * FROM order_tracking WHERE order_id=? ORDER BY created_at ASC", [$order['id']]);
    }
}
?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card card-custom p-4 mb-4">
            <h4 class="mb-3"><i class="fas fa-search"></i> Track Your Order</h4>
            <form method="GET" class="d-flex gap-2">
                <input type="text" name="number" class="form-control" placeholder="Enter Order Number (e.g., QM20260101000001)" value="<?= htmlspecialchars($trackingNumber) ?>" required>
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Track</button>
            </form>
        </div>

        <?php if ($trackingNumber && !$order): ?>
        <div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> Order not found. Please check your order number.</div>
        <?php elseif ($order): ?>
        <div class="card card-custom p-4 mb-4">
            <div class="d-flex justify-content-between align-items-start mb-3">
                <div>
                    <h4>Order #<?= $order['order_number'] ?></h4>
                    <p class="text-muted mb-0">Placed on <?= date('M d, Y h:i A', strtotime($order['created_at'])) ?></p>
                </div>
                <span class="badge bg-<?= $order['status']=='pending'?'warning':($order['status']=='delivered'?'success':($order['status']=='cancelled'?'danger':($order['status']=='shipped'?'info':'primary'))) ?> fs-6"><?= ucfirst($order['status']) ?></span>
            </div>
            <div class="row mb-3">
                <div class="col-md-6"><strong>Name:</strong> <?= htmlspecialchars($order['shipping_name']) ?></div>
                <div class="col-md-6"><strong>Phone:</strong> <?= htmlspecialchars($order['shipping_phone']) ?></div>
                <div class="col-12"><strong>Address:</strong> <?= htmlspecialchars($order['shipping_address'] . ', ' . $order['shipping_city'] . ' ' . $order['shipping_area']) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4"><strong>Payment:</strong> <?= strtoupper($order['payment_method']) ?></div>
                <div class="col-md-4"><strong>Total:</strong> <?= formatPrice($order['total']) ?></div>
                <div class="col-md-4"><strong>Items:</strong> <?= count_rows("SELECT COUNT(*) FROM order_items WHERE order_id=?", [$order['id']]) ?> items</div>
            </div>
        </div>

        <div class="card card-custom p-4 mb-4">
            <h5 class="mb-3">Order Timeline</h5>
            <?php
            $statuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered'];
            $statusIcons = ['pending'=>'clock', 'confirmed'=>'check', 'processing'=>'cog', 'shipped'=>'truck', 'delivered'=>'check-circle'];
            $currentIdx = array_search($order['status'], $statuses);
            if ($currentIdx === false) $currentIdx = 0;
            foreach ($statuses as $i => $s):
                $done = $i <= $currentIdx;
                $active = $i === $currentIdx;
                $trackEntry = null;
                foreach ($tracking as $t) { if ($t['status'] == $s) { $trackEntry = $t; break; } }
            ?>
            <div class="d-flex mb-3 <?= !$done && $i > $currentIdx ? 'opacity-50' : '' ?>">
                <div class="me-3">
                    <div class="rounded-circle d-flex align-items-center justify-content-center" style="width:40px;height:40px;background:<?= $done ? '#0d6efd' : '#6c757d' ?>;color:#fff;">
                        <i class="fas fa-<?= $statusIcons[$s] ?>"></i>
                    </div>
                    <?php if ($i < count($statuses)-1): ?><div style="width:2px;height:30px;background:<?= $done ? '#0d6efd' : '#6c757d' ?>;margin:4px auto;"></div><?php endif; ?>
                </div>
                <div>
                    <strong class="<?= $active ? 'text-primary' : '' ?>"><?= ucfirst($s) ?></strong>
                    <?php if ($trackEntry): ?>
                    <p class="mb-0 small text-muted"><?= date('M d, Y h:i A', strtotime($trackEntry['created_at'])) ?>
                    <?php if ($trackEntry['location']): ?> - <?= htmlspecialchars($trackEntry['location']) ?><?php endif; ?>
                    <?php if ($trackEntry['note']): ?><br><?= htmlspecialchars($trackEntry['note']) ?><?php endif; ?></p>
                    <?php elseif ($done): ?>
                    <p class="mb-0 small text-muted">Completed</p>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="card card-custom p-4">
            <h5>Order Items</h5>
            <?php $items = fetchAll("SELECT * FROM order_items WHERE order_id=?", [$order['id']]); foreach ($items as $item): ?>
            <div class="d-flex justify-content-between mb-2 py-2 border-bottom">
                <span><?= htmlspecialchars($item['product_name']) ?> x<?= $item['quantity'] ?></span>
                <span class="fw-bold"><?= formatPrice($item['price'] * $item['quantity']) ?></span>
            </div>
            <?php endforeach; ?>
            <div class="d-flex justify-content-between mt-2"><strong>Total</strong><strong class="text-primary"><?= formatPrice($order['total']) ?></strong></div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
