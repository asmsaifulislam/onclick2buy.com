<?php
require_once __DIR__ . '/../includes/header.php';
$slug = $_GET['slug'] ?? '';
$product = fetch("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.slug=? AND p.is_active=1", [$slug]);
if (!$product) { echo '<div class="container py-5 text-center"><h3>Product not found</h3><a href="products.php" class="btn btn-primary">Browse Products</a></div>'; require_once __DIR__ . '/../includes/footer.php'; exit; }
$pageTitle = $product['name'] . ' - Quick Mart';
$reviews = fetchAll("SELECT r.*, u.username FROM reviews r LEFT JOIN users u ON r.user_id=u.id WHERE r.product_id=? ORDER BY r.created_at DESC", [$product['id']]);
$related = fetchAll("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.category_id=? AND p.id!=? AND p.is_active=1 LIMIT 4", [$product['category_id'], $product['id']]);
?>

<nav class="mb-4">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= SITE_URL ?>/store/">Home</a></li>
        <li class="breadcrumb-item"><a href="<?= SITE_URL ?>/store/products.php">Products</a></li>
        <li class="breadcrumb-item"><a href="<?= SITE_URL ?>/store/products.php?category=<?= $product['cat_name'] ?>"><?= htmlspecialchars($product['cat_name']) ?></a></li>
        <li class="breadcrumb-item active"><?= htmlspecialchars($product['name']) ?></li>
    </ol>
</nav>

<div class="row mb-5">
    <div class="col-md-6">
        <div class="card card-custom p-4 text-center">
            <i class="fas fa-box fa-8x text-primary mb-3" style="opacity:0.3"></i>
            <h5><?= htmlspecialchars($product['name']) ?></h5>
        </div>
    </div>
    <div class="col-md-6">
        <span class="badge bg-primary mb-2"><?= htmlspecialchars($product['cat_name']) ?></span>
        <?php if ($product['brand']): ?>
        <span class="badge bg-secondary mb-2"><?= htmlspecialchars($product['brand']) ?></span>
        <?php endif; ?>
        <h2><?= htmlspecialchars($product['name']) ?></h2>
        <div class="mb-3">
            <?php for ($i = 0; $i < 5; $i++): ?>
            <i class="fas fa-star <?= $i < $product['average_rating'] ? 'text-warning' : 'text-muted' ?>"></i>
            <?php endfor; ?>
            <span class="text-muted ms-2"><?= $product['average_rating'] ?> (<?= $product['total_reviews'] ?> reviews)</span>
        </div>
        <h3 class="text-primary mb-3"><?= formatPrice($product['price']) ?></h3>
        <p class="text-muted"><?= $product['stock'] > 0 ? "<span class='text-success'>In Stock (" . $product['stock'] . " available)</span>" : '<span class="text-danger">Out of Stock</span>' ?></p>
        <p><?= nl2br(htmlspecialchars($product['description'])) ?></p>

        <?php if ($product['stock'] > 0): ?>
        <div class="d-flex gap-2 mb-3 flex-wrap">
            <div class="input-group" style="max-width:130px;min-width:100px">
                <button class="btn btn-outline-secondary" onclick="changeQty(-1)">-</button>
                <input type="number" id="qty" class="form-control text-center" value="1" min="1" max="<?= $product['stock'] ?>">
                <button class="btn btn-outline-secondary" onclick="changeQty(1)">+</button>
            </div>
            <button class="btn btn-primary add-to-cart-btn" data-id="<?= $product['id'] ?>" data-qty="true">
                <i class="fas fa-cart-plus"></i> Add to Cart
            </button>
            <button class="buy-now-btn" data-id="<?= $product['id'] ?>">
                <i class="fas fa-bolt"></i> Buy Now
            </button>
            <button class="btn btn-outline-danger add-to-wishlist-btn" data-id="<?= $product['id'] ?>">
                <i class="fas fa-heart"></i>
            </button>
        </div>
        <?php endif; ?>

        <div class="mt-3">
            <p class="small text-muted"><i class="fas fa-truck"></i> Inside Dhaka: BDT 80 | Outside Dhaka: BDT 120</p>
            <p class="small text-muted"><i class="fas fa-money-bill"></i> Cash on Delivery Available</p>
        </div>
    </div>
</div>

<?php if ($related): ?>
<section class="mb-5">
    <h4>Related Products</h4>
    <div class="row g-4">
        <?php foreach ($related as $p): ?>
        <div class="col-6 col-md-3">
            <div class="card h-100 card-custom">
                <div class="card-body">
                    <h6><?= htmlspecialchars($p['name']) ?></h6>
                    <h5 class="text-primary"><?= formatPrice($p['price']) ?></h5>
                    <a href="<?= SITE_URL ?>/store/product.php?slug=<?= $p['slug'] ?>" class="btn btn-sm btn-outline-primary">View</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<section class="mb-5">
    <h4>Reviews (<?= count($reviews) ?>)</h4>
    <?php if (isLoggedIn()): ?>
    <form method="POST" action="<?= SITE_URL ?>/api/review.php" class="card card-custom p-3 mb-4">
        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
        <div class="mb-2">
            <label class="form-label fw-bold">Rating</label>
            <select name="rating" class="form-select" style="width:150px">
                <option value="5">5 Stars</option>
                <option value="4">4 Stars</option>
                <option value="3">3 Stars</option>
                <option value="2">2 Stars</option>
                <option value="1">1 Star</option>
            </select>
        </div>
        <div class="mb-2">
            <textarea name="comment" class="form-control" rows="3" placeholder="Write your review..." required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit Review</button>
    </form>
    <?php else: ?>
    <p><a href="<?= SITE_URL ?>/store/login.php">Login</a> to write a review.</p>
    <?php endif; ?>

    <?php foreach ($reviews as $r): ?>
    <div class="card card-custom p-3 mb-2">
        <div class="d-flex justify-content-between">
            <div>
                <strong><?= htmlspecialchars($r['username'] ?? 'Anonymous') ?></strong>
                <span class="ms-2">
                    <?php for ($i = 0; $i < 5; $i++): ?>
                    <i class="fas fa-star <?= $i < $r['rating'] ? 'text-warning' : 'text-muted' ?>" style="font-size:12px"></i>
                    <?php endfor; ?>
                </span>
            </div>
            <small class="text-muted"><?= timeAgo($r['created_at']) ?></small>
        </div>
        <p class="mb-0 mt-2"><?= htmlspecialchars($r['comment']) ?></p>
    </div>
    <?php endforeach; ?>
</section>

<script>
function changeQty(d) {
    var el = document.getElementById('qty');
    var v = parseInt(el.value) + d;
    if (v >= 1 && v <= parseInt(el.max)) el.value = v;
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
