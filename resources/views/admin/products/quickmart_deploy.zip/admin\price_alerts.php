<?php
$pageTitle = 'Price Alerts';
require_once __DIR__ . '/../includes/admin_header.php';
$alerts = fetchAll("SELECT pa.*, u.username, p.name as product_name, p.price as current_price FROM price_alerts pa LEFT JOIN users u ON pa.user_id=u.id LEFT JOIN products p ON pa.product_id=p.id ORDER BY pa.created_at DESC");
?>
<h4 class="mb-4">Price Alerts (<?= count($alerts) ?>)</h4>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>User</th><th>Product</th><th>Current Price</th><th>Target Price</th><th>Status</th><th>Created</th></tr></thead>
<tbody><?php foreach ($alerts as $a): ?>
<tr><td><?= htmlspecialchars($a['username'] ?? 'N/A') ?></td><td><?= htmlspecialchars($a['product_name'] ?? 'Deleted') ?></td>
<td><strong><?= formatPrice($a['current_price']) ?></strong></td><td><span class="text-warning"><?= formatPrice($a['target_price']) ?></span></td>
<td><span class="badge bg-<?= $a['status']=='triggered'?'success':($a['status']=='notified'?'info':'warning') ?>"><?= ucfirst($a['status']) ?></span></td>
<td><?= $a['created_at'] ?></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
