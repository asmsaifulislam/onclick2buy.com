<?php
$pageTitle = 'Wallets';
require_once __DIR__ . '/../includes/admin_header.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['adjust'])) {
    $userId = (int)$_POST['user_id'];
    $amount = (float)$_POST['amount'];
    $type = $_POST['tx_type'];
    if ($userId && $amount != 0) {
        $wallet = fetch("SELECT * FROM wallets WHERE user_id=?", [$userId]);
        if ($wallet) {
            $newBal = $type == 'credit' ? $wallet['balance'] + $amount : $wallet['balance'] - $amount;
            if ($newBal >= 0) {
                query("UPDATE wallets SET balance=? WHERE user_id=?", [$newBal, $userId]);
                query("INSERT INTO wallet_transactions (user_id, amount, tx_type, description, reference_type) VALUES (?,?,?,?,'admin_adjustment')", [$userId, $type == 'credit' ? $amount : -$amount, $type, 'Admin adjustment']);
                setAlert('success', 'Wallet adjusted!');
            } else { setAlert('danger', 'Insufficient balance.'); }
        }
    }
    redirect(SITE_URL . '/admin/wallets.php');
}
$wallets = fetchAll("SELECT w.*, u.username FROM wallets w LEFT JOIN users u ON w.user_id=u.id ORDER BY w.balance DESC");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Customer Wallets</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal"><i class="fas fa-plus"></i> Adjust Wallet</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>User</th><th>Balance</th><th>Total Loaded</th><th>Total Spent</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($wallets as $w): ?>
<tr><td><?= htmlspecialchars($w['username'] ?? 'N/A') ?></td><td><strong class="text-success"><?= formatPrice($w['balance']) ?></strong></td><td><?= formatPrice($w['total_loaded']) ?></td><td><?= formatPrice($w['total_spent']) ?></td>
<td><button class="btn btn-sm btn-warning" onclick="document.getElementById('f_user').value='<?= $w['user_id'] ?>';new bootstrap.Modal(document.getElementById('modal')).show();"><i class="fas fa-edit"></i> Adjust</button></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title">Adjust Wallet</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="adjust" value="1">
<div class="mb-3"><label class="form-label">User</label><select name="user_id" id="f_user" class="form-select" required><?php foreach ($wallets as $w): ?><option value="<?= $w['user_id'] ?>"><?= htmlspecialchars($w['username'] ?? 'User #'.$w['user_id']) ?> (Bal: <?= formatPrice($w['balance']) ?>)</option><?php endforeach; ?></select></div>
<div class="mb-3"><label class="form-label">Amount</label><input type="number" step="0.01" name="amount" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Type</label><select name="tx_type" class="form-select"><option value="credit">Credit (+)</option><option value="debit">Debit (-)</option></select></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
