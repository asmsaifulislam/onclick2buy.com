<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

if (!isLoggedIn()) { echo json_encode(['error' => 'not logged in']); exit; }

$userId = $_SESSION['user_id'];
$isAdmin = isAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $msg = trim($data['message'] ?? '');
    $chatWith = (int)($data['chat_with'] ?? 0);
    if (!$msg) { echo json_encode(['error' => 'empty message']); exit; }
    $receiver = $isAdmin ? $chatWith : 1;
    query("INSERT INTO chat_messages (sender_id, receiver_id, message, is_read) VALUES (?,?,?,0)", [$userId, $receiver, $msg]);
    echo json_encode(['ok' => true, 'time' => date('M d H:i')]);
    exit;
}

$action = $_GET['action'] ?? 'messages';

// Get conversation list (for admin sidebar refresh)
if ($action === 'conversations' && $isAdmin) {
    $convs = fetchAll("SELECT cm.sender_id, u.username, MAX(cm.created_at) as last_msg, MAX(CASE WHEN cm.is_read=0 AND cm.receiver_id=? THEN cm.id ELSE 0 END) as last_unread, COUNT(CASE WHEN cm.is_read=0 AND cm.receiver_id=? THEN 1 END) as unread FROM chat_messages cm LEFT JOIN users u ON cm.sender_id=u.id WHERE cm.sender_id != ? GROUP BY cm.sender_id ORDER BY last_msg DESC", [$userId, $userId, $userId]);
    echo json_encode(['conversations' => $convs]);
    exit;
}

// Get messages
$chatWith = (int)($_GET['chat_with'] ?? 0);
if ($isAdmin && $chatWith) {
    $lastId = (int)($_GET['last_id'] ?? 0);
    $msgs = fetchAll("SELECT cm.*, u.username as sender_name FROM chat_messages cm LEFT JOIN users u ON cm.sender_id=u.id WHERE ((cm.sender_id=? AND cm.receiver_id=?) OR (cm.sender_id=? AND cm.receiver_id=?)) AND cm.id > ? ORDER BY cm.created_at ASC", [$userId, $chatWith, $chatWith, $userId, $lastId]);
    query("UPDATE chat_messages SET is_read=1 WHERE sender_id=? AND receiver_id=?", [$chatWith, $userId]);
    echo json_encode(['messages' => $msgs, 'chat_with' => $chatWith]);
} elseif (!$isAdmin) {
    $lastId = (int)($_GET['last_id'] ?? 0);
    $msgs = fetchAll("SELECT cm.*, u.username as sender_name FROM chat_messages cm LEFT JOIN users u ON cm.sender_id=u.id WHERE ((cm.sender_id=? AND cm.receiver_id=1) OR (cm.sender_id=1 AND cm.receiver_id=?)) AND cm.id > ? ORDER BY cm.created_at ASC", [$userId, $userId, $lastId]);
    echo json_encode(['messages' => $msgs]);
} else {
    echo json_encode(['messages' => []]);
}
