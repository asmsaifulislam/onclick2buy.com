<?php
$pageTitle = 'Push Notifications';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM push_notifications WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/push_notifications.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [$_POST['title'], $_POST['message'], $_POST['type']];
    if ($id) { query("UPDATE push_notifications SET title=?, message=?, type=? WHERE id=?", array_merge($data, [$id])); }
    else { query("INSERT INTO push_notifications (title, message, type) VALUES (?,?,?)", $data); }
    setAlert('success', 'Notification saved!'); redirect(SITE_URL . '/admin/push_notifications.php');
}
$notifs = fetchAll("SELECT * FROM push_notifications ORDER BY created_at DESC");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Push Notifications</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_title').value='';document.getElementById('f_msg').value='';document.getElementById('f_type').value='info';document.getElementById('modalTitle').textContent='Add Notification';"><i class="fas fa-plus"></i> Add</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>Title</th><th>Message</th><th>Type</th><th>Sent</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($notifs as $n): ?>
<tr><td><strong><?= htmlspecialchars($n['title']) ?></strong></td><td><?= htmlspecialchars($n['message']) ?></td>
<td><span class="badge bg-<?= $n['type']=='info'?'primary':($n['type']=='warning'?'warning':'danger') ?>"><?= ucfirst($n['type']) ?></span></td>
<td><?= $n['created_at'] ?></td>
<td><a href="?delete=<?= $n['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Notification</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">Title</label><input type="text" name="title" id="f_title" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Message</label><textarea name="message" id="f_msg" class="form-control" required></textarea></div>
<div class="mb-3"><label class="form-label">Type</label><select name="type" id="f_type" class="form-select"><option value="info">Info</option><option value="warning">Warning</option><option value="urgent">Urgent</option></select></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
