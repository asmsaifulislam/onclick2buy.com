<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$sid = getCartSession();
$userId = $_SESSION['user_id'] ?? null;

switch ($action) {
    case 'add':
        $productId = (int)($_POST['product_id'] ?? $_GET['product_id'] ?? 0);
        $qty = max(1, (int)($_POST['quantity'] ?? 1));
        if ($userId) {
            $existing = fetch("SELECT id, quantity FROM cart_items WHERE user_id=? AND product_id=?", [$userId, $productId]);
        } else {
            $existing = fetch("SELECT id, quantity FROM cart_items WHERE session_id=? AND product_id=?", [$sid, $productId]);
        }
        if ($existing) {
            query("UPDATE cart_items SET quantity = quantity + ? WHERE id=?", [$qty, $existing['id']]);
        } else {
            if ($userId) {
                query("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?,?,?)", [$userId, $productId, $qty]);
            } else {
                query("INSERT INTO cart_items (session_id, product_id, quantity) VALUES (?,?,?)", [$sid, $productId, $qty]);
            }
        }
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'cart_count' => getCartCount()]);
        } else {
            setAlert('success', 'Product added to cart!');
            header("Location: " . $_SERVER['HTTP_REFERER'] ?? SITE_URL . '/store/cart.php');
        }
        exit;

    case 'update':
        $itemId = (int)($_POST['item_id'] ?? 0);
        $qty = max(1, (int)($_POST['quantity'] ?? 1));
        query("UPDATE cart_items SET quantity=? WHERE id=?", [$qty, $itemId]);
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'cart_count' => getCartCount()]);
        } else {
            redirect(SITE_URL . '/store/cart.php');
        }
        exit;

    case 'remove':
        $itemId = (int)($_POST['item_id'] ?? 0);
        query("DELETE FROM cart_items WHERE id=?", [$itemId]);
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'cart_count' => getCartCount()]);
        } else {
            redirect(SITE_URL . '/store/cart.php');
        }
        exit;

    case 'coupon':
        $code = strtoupper(trim($_POST['coupon_code'] ?? ''));
        $coupon = fetch("SELECT * FROM coupons WHERE code=? AND is_active=1 AND valid_from<=CURDATE() AND valid_to>=CURDATE()", [$code]);
        if ($coupon) {
            $_SESSION['coupon_id'] = $coupon['id'];
            $_SESSION['coupon_discount'] = $coupon['discount_percent'];
            setAlert('success', "Coupon applied! {$coupon['discount_percent']}% off");
        } else {
            setAlert('danger', 'Invalid or expired coupon.');
        }
        redirect(SITE_URL . '/store/cart.php');
        exit;

    case 'cancel_order':
        $orderId = (int)($_POST['order_id'] ?? 0);
        if ($userId) {
            query("UPDATE orders SET status='cancelled' WHERE id=? AND user_id=? AND status='pending'", [$orderId, $userId]);
            setAlert('success', 'Order cancelled.');
        }
        redirect(SITE_URL . '/store/orders.php');
        exit;
}

header("Location: " . SITE_URL . '/store/');
