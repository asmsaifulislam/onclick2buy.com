<?php
$pageTitle = 'Compare Products - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');

$compare = fetchAll("SELECT pc.*, p.name, p.price, p.stock, p.average_rating, p.total_reviews, p.brand, p.description, c.name as cat_name FROM product_compare pc JOIN products p ON pc.product_id=p.id LEFT JOIN categories c ON p.category_id=c.id WHERE pc.user_id=? ORDER BY pc.created_at DESC", [$_SESSION['user_id']]);
?>

<h2 class="mb-4"><i class="fas fa-balance-scale"></i> Compare Products</h2>

<?php if (empty($compare)): ?>
<div class="text-center py-5">
    <i class="fas fa-balance-scale fa-4x text-muted mb-3" style="opacity:0.3"></i>
    <h5>No products to compare</h5>
    <p class="text-muted">Add products from the product page to compare them side by side.</p>
    <a href="<?= SITE_URL ?>/store/products.php" class="btn btn-primary">Browse Products</a>
</div>
<?php else: ?>
<div class="table-responsive">
    <table class="table table-custom">
        <thead>
            <tr>
                <th>Feature</th>
                <?php foreach ($compare as $p): ?>
                <th class="text-center">
                    <?= htmlspecialchars($p['name']) ?>
                    <br><a href="?remove=<?= $p['product_id'] ?>" class="text-danger small">Remove</a>
                </th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
            <tr><td><strong>Price</strong></td><?php foreach ($compare as $p): ?><td class="text-center fw-bold text-primary"><?= formatPrice($p['price']) ?></td><?php endforeach; ?></tr>
            <tr><td><strong>Category</strong></td><?php foreach ($compare as $p): ?><td class="text-center"><?= htmlspecialchars($p['cat_name']) ?></td><?php endforeach; ?></tr>
            <tr><td><strong>Brand</strong></td><?php foreach ($compare as $p): ?><td class="text-center"><?= htmlspecialchars($p['brand'] ?? '-') ?></td><?php endforeach; ?></tr>
            <tr><td><strong>Stock</strong></td><?php foreach ($compare as $p): ?><td class="text-center"><span class="badge bg-<?= $p['stock']>10?'success':($p['stock']>0?'warning':'danger') ?>"><?= $p['stock'] ?></span></td><?php endforeach; ?></tr>
            <tr><td><strong>Rating</strong></td><?php foreach ($compare as $p): ?><td class="text-center"><?= $p['average_rating'] ?>/5 (<?= $p['total_reviews'] ?>)</td><?php endforeach; ?></tr>
            <tr>
                <td><strong>Action</strong></td>
                <?php foreach ($compare as $p): ?>
                <td class="text-center">
                    <button class="btn btn-sm btn-primary add-to-cart-btn" data-id="<?= $p['product_id'] ?>"><i class="fas fa-cart-plus"></i></button>
                    <button class="buy-now-btn buy-now-btn-sm mt-1" data-id="<?= $p['product_id'] ?>" title="Buy Now"><i class="fas fa-bolt"></i></button>
                </td>
                <?php endforeach; ?>
            </tr>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php if (isset($_GET['remove'])) {
    query("DELETE FROM product_compare WHERE user_id=? AND product_id=?", [$_SESSION['user_id'], (int)$_GET['remove']]);
    redirect(SITE_URL . '/store/compare.php');
} ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
