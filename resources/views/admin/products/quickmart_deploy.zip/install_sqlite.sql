CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    is_staff INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT,
    price REAL NOT NULL DEFAULT 0,
    stock INTEGER DEFAULT 0,
    category_id INTEGER,
    image TEXT,
    brand TEXT,
    is_active INTEGER DEFAULT 1,
    average_rating REAL DEFAULT 0,
    total_reviews INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS product_variants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    price_adjust REAL DEFAULT 0,
    stock INTEGER DEFAULT 0,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS cart_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT,
    user_id INTEGER DEFAULT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    order_number TEXT UNIQUE NOT NULL,
    total REAL NOT NULL DEFAULT 0,
    subtotal REAL DEFAULT 0,
    shipping_cost REAL DEFAULT 0,
    discount REAL DEFAULT 0,
    status TEXT DEFAULT 'pending',
    payment_method TEXT DEFAULT 'cod',
    payment_status TEXT DEFAULT 'pending',
    shipping_name TEXT,
    shipping_phone TEXT,
    shipping_address TEXT,
    shipping_city TEXT,
    shipping_area TEXT,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER,
    product_name TEXT,
    price REAL NOT NULL,
    quantity INTEGER DEFAULT 1,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    user_id INTEGER,
    rating INTEGER DEFAULT 5,
    comment TEXT,
    is_approved INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS coupons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    discount_percent REAL DEFAULT 0,
    discount_amount REAL DEFAULT 0,
    min_purchase REAL DEFAULT 0,
    max_uses INTEGER DEFAULT 0,
    used_count INTEGER DEFAULT 0,
    valid_from DATE,
    valid_to DATE,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS wishlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE (user_id, product_id)
);

CREATE TABLE IF NOT EXISTS blog_posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    content TEXT,
    is_published INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS site_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT UNIQUE NOT NULL,
    value TEXT
);

-- Default admin user (password: admin123)
INSERT INTO users (username, email, password, is_staff) VALUES
('admin', 'admin@quickmart.com', '$2y$10$C7Qrik0YeDXjEZXFgyjECOR.8/i38uuOJVasav.8UVPjtZil5hKHu', 1);

-- Demo users (password: admin123)
INSERT INTO users (username, email, password, is_staff) VALUES
('demo_user1', 'demo1@test.com', '$2y$10$C7Qrik0YeDXjEZXFgyjECOR.8/i38uuOJVasav.8UVPjtZil5hKHu', 0),
('demo_user2', 'demo2@test.com', '$2y$10$C7Qrik0YeDXjEZXFgyjECOR.8/i38uuOJVasav.8UVPjtZil5hKHu', 0),
('demo_user3', 'demo3@test.com', '$2y$10$C7Qrik0YeDXjEZXFgyjECOR.8/i38uuOJVasav.8UVPjtZil5hKHu', 0),
('demo_user4', 'demo4@test.com', '$2y$10$C7Qrik0YeDXjEZXFgyjECOR.8/i38uuOJVasav.8UVPjtZil5hKHu', 0),
('demo_user5', 'demo5@test.com', '$2y$10$C7Qrik0YeDXjEZXFgyjECOR.8/i38uuOJVasav.8UVPjtZil5hKHu', 0),
('rafiq', 'rafiq@test.com', '$2y$10$C7Qrik0YeDXjEZXFgyjECOR.8/i38uuOJVasav.8UVPjtZil5hKHu', 0),
('sumaiya', 'sumaiya@test.com', '$2y$10$C7Qrik0YeDXjEZXFgyjECOR.8/i38uuOJVasav.8UVPjtZil5hKHu', 0),
('kamal', 'kamal@test.com', '$2y$10$C7Qrik0YeDXjEZXFgyjECOR.8/i38uuOJVasav.8UVPjtZil5hKHu', 0),
('nusrat', 'nusrat@test.com', '$2y$10$C7Qrik0YeDXjEZXFgyjECOR.8/i38uuOJVasav.8UVPjtZil5hKHu', 0),
('tanvir', 'tanvir@test.com', '$2y$10$C7Qrik0YeDXjEZXFgyjECOR.8/i38uuOJVasav.8UVPjtZil5hKHu', 0);

INSERT INTO categories (name, slug, description) VALUES
('Electronics', 'electronics', 'Smartphones, laptops, gadgets and more'),
('Fashion', 'fashion', 'Clothing, shoes, watches and accessories'),
('Home & Kitchen', 'home-kitchen', 'Appliances, furniture and home essentials'),
('Beauty & Health', 'beauty-health', 'Skincare, makeup, supplements and wellness'),
('Groceries', 'groceries', 'Daily essentials, food and beverages'),
('Books', 'books', 'Fiction, non-fiction, academic and more');

INSERT INTO products (name, slug, description, price, stock, category_id, brand, average_rating, total_reviews) VALUES
('iPhone 15 Pro Max', 'iphone-15-pro-max', 'Apple iPhone 15 Pro Max 256GB', 169999, 378, 1, 'Apple', 4.8, 245),
('Samsung Galaxy S24 Ultra', 'samsung-galaxy-s24-ultra', 'Samsung Galaxy S24 Ultra 512GB', 134999, 373, 1, 'Samsung', 4.7, 198),
('OnePlus 12', 'oneplus-12', 'OnePlus 12 5G 256GB', 69999, 204, 1, 'OnePlus', 4.6, 156),
('Xiaomi Redmi Note 13 Pro', 'xiaomi-redmi-note-13-pro', 'Xiaomi Redmi Note 13 Pro 5G', 27999, 311, 1, 'Xiaomi', 4.5, 234),
('Samsung Galaxy A54 5G', 'samsung-galaxy-a54-5g', 'Samsung Galaxy A54 5G 128GB', 42999, 25, 1, 'Samsung', 4.4, 167),
('Realme Narzo 60X 5G', 'realme-narzo-60x-5g', 'Realme Narzo 60X 5G 128GB', 18999, 35, 1, 'Realme', 4.3, 89),
('iPad Air M2', 'ipad-air-m2', 'Apple iPad Air M2 11-inch 256GB', 89999, 476, 1, 'Apple', 4.8, 178),
('Samsung Galaxy Tab S9', 'samsung-galaxy-tab-s9', 'Samsung Galaxy Tab S9 256GB', 79999, 397, 1, 'Samsung', 4.6, 134),
('Sony WH-1000XM5', 'sony-wh-1000xm5', 'Sony WH-1000XM5 Wireless Headphones', 39999, 497, 1, 'Sony', 4.9, 312),
('JBL Flip 6 Speaker', 'jbl-flip-6-speaker', 'JBL Flip 6 Portable Bluetooth Speaker', 14999, 20, 1, 'JBL', 4.7, 189),
('JBL Flip 6', 'jbl-flip-6', 'JBL Flip 6 Waterproof Speaker', 12999, 271, 1, 'JBL', 4.7, 156),
('Apple Watch Series 9', 'apple-watch-series-9', 'Apple Watch Series 9 GPS 45mm', 49999, 97, 1, 'Apple', 4.8, 201),
('Canon EOS R50', 'canon-eos-r50', 'Canon EOS R50 Mirrorless Camera', 89999, 220, 1, 'Canon', 4.6, 67),
('Canon PIXMA G3010', 'canon-pixma-g3010', 'Canon PIXMA G3010 Wireless Printer', 24999, 10, 1, 'Canon', 4.3, 45),
('Dell 24 Monitor', 'dell-24-monitor', 'Dell 24-inch Full HD Monitor', 22999, 12, 1, 'Dell', 4.4, 78),
('Logitech MX Master 3S', 'logitech-mx-master-3s', 'Logitech MX Master 3S Wireless Mouse', 9999, 15, 1, 'Logitech', 4.8, 134),
('TP-Link Archer AX73', 'tp-link-archer-ax73', 'TP-Link Archer AX73 WiFi 6 Router', 8999, 18, 1, 'TP-Link', 4.5, 98),
('Anker PowerCore 20000', 'anker-powercore-20000', 'Anker PowerCore 20000mAh Power Bank', 4999, 50, 1, 'Anker', 4.6, 87),
('Nike Air Max 270', 'nike-air-max-270', 'Nike Air Max 270 Sneakers', 14999, 358, 2, 'Nike', 4.7, 234),
('Nike Air Max 270 Sneakers', 'nike-air-max-270-sneakers', 'Nike Air Max 270 Running Shoes', 14999, 20, 2, 'Nike', 4.7, 123),
('Adidas Ultraboost 23', 'adidas-ultraboost-23', 'Adidas Ultraboost 23 Running Shoes', 16999, 272, 2, 'Adidas', 4.8, 189),
('Levis 501 Original Jeans', 'levis-501-original-jeans', 'Levis 501 Original Fit Jeans', 4999, 302, 2, 'Levis', 4.5, 167),
('Levis 511 Slim Fit Jeans', 'levis-511-slim-fit-jeans', 'Levis 511 Slim Fit Jeans', 5999, 30, 2, 'Levis', 4.5, 89),
('Polo Ralph Lauren T-Shirt', 'polo-ralph-lauren-t-shirt', 'Polo Ralph Lauren Classic T-Shirt', 5999, 440, 2, 'Polo', 4.6, 145),
('Polo Ralph Lauren T-Shirt Premium', 'polo-ralph-lauren-t-shirt-premium', 'Polo Ralph Lauren Premium Tee', 3999, 45, 2, 'Polo', 4.6, 78),
('Watch Casio G-Shock', 'watch-casio-g-shock', 'Casio G-Shock Classic Watch', 12999, 459, 2, 'Casio', 4.8, 267),
('Casio G-Shock GA-2100', 'casio-g-shock-ga-2100', 'Casio G-Shock GA-2100CasiOak', 12999, 15, 2, 'Casio', 4.8, 134),
('Fastrack Analog Watch Women', 'fastrack-analog-watch-women', 'Fastrack Analog Watch for Women', 2499, 35, 2, 'Fastrack', 4.3, 56),
('Sun Ray-Ban Aviator', 'sun-ray-ban-aviator', 'Ray-Ban Aviator Classic Sunglasses', 9999, 182, 2, 'Ray-Ban', 4.7, 112),
('Handbag Leather Premium', 'handbag-leather-premium', 'Premium Leather Handbag', 6999, 221, 2, 'Generic', 4.5, 89),
('Woodland Leather Boots', 'woodland-leather-boots', 'Woodland Leather Boots', 6999, 18, 2, 'Woodland', 4.6, 67),
('Shirt Formal Cotton', 'shirt-formal-cotton', 'Formal Cotton Shirt', 3499, 553, 2, 'Generic', 4.4, 123),
('Saree Silk Banarasi', 'saree-silk-banarasi', 'Banarasi Silk Saree', 8999, 435, 2, 'Generic', 4.7, 178),
('Silk Saree Banarasi', 'silk-saree-banarasi', 'Pure Silk Banarasi Saree', 7999, 25, 2, 'Generic', 4.7, 56),
('Panjabi Cotton White', 'panjabi-cotton-white', 'White Cotton Panjabi', 2999, 545, 2, 'Generic', 4.5, 134),
('Bengali Panjabi Cotton', 'bengali-panjabi-cotton', 'Traditional Bengali Cotton Panjabi', 2499, 60, 2, 'Generic', 4.5, 45),
('Walton Refrigerator 265L', 'walton-refrigerator-265l', 'Walton 265L Frost Refrigerator', 32999, 183, 3, 'Walton', 4.4, 98),
('Walton 208L Refrigerator', 'walton-208l-refrigerator', 'Walton 208L Direct Cool Refrigerator', 34999, 8, 3, 'Walton', 4.3, 56),
('Midea Washing Machine 8kg', 'midea-washing-machine-8kg', 'Midea 8kg Automatic Washing Machine', 29999, 486, 3, 'Midea', 4.5, 167),
('Philips Air Fryer XXL', 'philips-air-fryer-xxl', 'Philips Air Fryer XXL 7.3L', 14999, 385, 3, 'Philips', 4.7, 234),
('Philips Air Fryer HD9200', 'philips-air-fryer-hd9200', 'Philips Air Fryer HD9200 4.1L', 18999, 15, 3, 'Philips', 4.7, 89),
('Orient Ceiling Fan', 'orient-ceiling-fan', 'Orient Electric Ceiling Fan', 4999, 182, 3, 'Orient', 4.4, 112),
('Orient Electric Fan 400mm', 'orient-electric-fan-400mm', 'Orient 400mm Table Fan', 4299, 18, 3, 'Orient', 4.4, 56),
('Water Purifier Pureit', 'water-purifier-pureit', 'Pureit Water Purifier 7L', 19999, 255, 3, 'Pureit', 4.5, 134),
('Prestige Cooker 5L', 'prestige-cooker-5l', 'Prestige Pressure Cooker 5L', 3999, 468, 3, 'Prestige', 4.6, 178),
('Prestige Pressure Cooker 5L', 'prestige-pressure-cooker-5l', 'Prestige Deluxe Pressure Cooker 5L', 5499, 25, 3, 'Prestige', 4.6, 45),
('Non-Stick Pan Set', 'non-stick-pan-set', 'Non-Stick Frying Pan Set 3pcs', 2999, 376, 3, 'Generic', 4.4, 123),
('Vatti Non-Stick Fry Pan', 'vatti-non-stick-fry-pan', 'Vatti Non-Stick Fry Pan 28cm', 2999, 40, 3, 'Vatti', 4.4, 34),
('Miyako Blender 1.5L', 'miyako-blender-15l', 'Miyako Electric Blender 1.5L', 3999, 30, 3, 'Miyako', 4.3, 56),
('Miyako Rice Cooker 1.8L', 'miyako-rice-cooker-18l', 'Miyako Rice Cooker 1.8L', 3999, 285, 3, 'Miyako', 4.5, 89),
('National Rice Cooker 1.8L', 'national-rice-cooker-18l', 'National Rice Cooker 1.8L', 4499, 20, 3, 'National', 4.5, 67),
('Cello Opalware Dinner Set', 'cello-opalware-dinner-set', 'Cello Opalware Dinner Set 33pcs', 3499, 22, 3, 'Cello', 4.4, 78),
('Nova Hair Dryer', 'nova-hair-dryer', 'Nova Professional Hair Dryer', 2499, 188, 3, 'Nova', 4.3, 56),
('Bedding Queen Size', 'bedding-queen-size', 'Premium Cotton Bedsheet Queen Size', 4999, 388, 3, 'Generic', 4.5, 145),
('Garnier Micellar Water 400ml', 'garnier-micellar-water-400ml', 'Garnier Micellar Cleansing Water 400ml', 699, 55, 4, 'Garnier', 4.5, 134),
('Gillette Fusion ProGlide', 'gillette-fusion-proglide', 'Gillette Fusion ProGlide Razor', 1499, 409, 4, 'Gillette', 4.6, 89),
('Hair Oil Coconut', 'hair-oil-coconut', 'Pure Coconut Hair Oil 500ml', 399, 575, 4, 'Generic', 4.4, 123),
('Himalaya Neem Face Wash 200ml', 'himalaya-neem-face-wash-200ml', 'Himalaya Neem Face Wash 200ml', 399, 80, 4, 'Himalaya', 4.5, 167),
('Loreal Paris Serum', 'loreal-paris-serum', 'Loreal Paris Hyaluron Serum 30ml', 2999, 346, 4, 'Loreal', 4.7, 112),
('Loreal Paris Serum 30ml', 'loreal-paris-serum-30ml', 'Loreal Paris Revitalift Serum 30ml', 2499, 35, 4, 'Loreal', 4.7, 78),
('Mamaearth Vitamin C Serum', 'mamaearth-vitamin-c-serum', 'Mamaearth Vitamin C Face Serum 30ml', 599, 45, 4, 'Mamaearth', 4.6, 189),
('Maybelline Lipstick Set', 'maybelline-lipstick-set', 'Maybelline Color Sensational Lipstick Set', 1999, 515, 4, 'Maybelline', 4.5, 134),
('Nivea Body Lotion', 'nivea-body-lotion', 'Nivea Body Lotion 400ml', 899, 378, 4, 'Nivea', 4.5, 156),
('Nivea Soft Moisturizer 200ml', 'nivea-soft-moisturizer-200ml', 'Nivea Soft Moisturizing Cream 200ml', 499, 100, 4, 'Nivea', 4.5, 112),
('Protein Powder 2kg', 'protein-powder-2kg', 'MuscleBlaze Protein Powder 2kg', 4999, 336, 4, 'MuscleBlaze', 4.6, 89),
('Sunscreen SPF 50+', 'sunscreen-spf-50', 'La Shield Fisico Sunscreen SPF 50+', 1499, 395, 4, 'La Shield', 4.7, 134),
('Vitamin C Supplement', 'vitamin-c-supplement', 'HealthVit Vitamin C 1000mg 60 tabs', 1299, 484, 4, 'HealthVit', 4.5, 67),
('Whey Protein Isolate 2lbs', 'whey-protein-isolate-2lbs', 'Optimum Nutrition Whey Protein Isolate 2lbs', 4999, 20, 4, 'ON', 4.8, 56),
('Basmati Rice 5kg', 'basmati-rice-5kg', 'India Gate Basmati Rice 5kg', 899, 343, 5, 'India Gate', 4.5, 134),
('Teer Basmati Rice 5kg', 'teer-basmati-rice-5kg', 'Teer Premium Basmati Rice 5kg', 899, 100, 5, 'Teer', 4.5, 56),
('Cooking Oil 5L', 'cooking-oil-5l', 'Rupchanda Soybean Oil 5L', 799, 689, 5, 'Rupchanda', 4.4, 178),
('Chicken Breast 1kg', 'chicken-breast-1kg', 'Fresh Chicken Breast Boneless 1kg', 499, 320, 5, 'Fresh', 4.3, 89),
('Eggs 30 pcs', 'eggs-30-pcs', 'Fresh Farm Eggs 30 pcs', 360, 569, 5, 'Fresh', 4.5, 234),
('Atta Flour 5kg', 'atta-flour-5kg', 'Pilsbury Atta Flour 5kg', 399, 524, 5, 'Pilsbury', 4.5, 145),
('Sugar 2kg', 'sugar-2kg', 'Local Sugar 2kg', 180, 469, 5, 'Local', 4.3, 67),
('Tea Leaves 500g', 'tea-leaves-500g', 'Brooke Bond Red Label Tea 500g', 399, 352, 5, 'Brooke Bond', 4.5, 134),
('ACI Pure Salt 1kg', 'aci-pure-salt-1kg', 'ACI Pure Salt 1kg', 55, 200, 5, 'ACI', 4.3, 56),
('Fresh Farm Milk 1L', 'fresh-farm-milk-1l', 'Aarong Fresh Milk 1L', 120, 200, 5, 'Aarong', 4.5, 112),
('Olpers Milk 1L', 'olpers-milk-1l', 'Olpers Full Cream Milk 1L', 130, 453, 5, 'Olpers', 4.5, 156),
('Pran Tomato Ketchup 500g', 'pran-tomato-ketchup-500g', 'Pran Tomato Ketchup 500g', 165, 120, 5, 'Pran', 4.4, 78),
('Radhuni Turmeric Powder 200g', 'radhuni-turmeric-powder-200g', 'Radhuni Turmeric Powder 200g', 180, 150, 5, 'Radhuni', 4.5, 56),
('Shwapno Chicken Breast 1kg', 'shwapno-chicken-breast-1kg', 'Shwapno Chicken Breast 1kg', 480, 60, 5, 'Shwapno', 4.3, 34),
('Atomic Habits - James Clear', 'atomic-habits-james-clear', 'Atomic Habits by James Clear', 599, 542, 6, 'Penguin', 4.9, 345),
('Rich Dad Poor Dad - Kiyosaki', 'rich-dad-poor-dad-kiyosaki', 'Rich Dad Poor Dad by Robert Kiyosaki', 499, 380, 6, 'Plata', 4.8, 267),
('The Psychology of Money', 'the-psychology-of-money', 'The Psychology of Money by Morgan Housel', 499, 273, 6, 'Harriman', 4.8, 234),
('Sapiens - Yuval Harari', 'sapiens-yuval-harari', 'Sapiens by Yuval Noah Harari', 699, 190, 6, 'Harper', 4.8, 189),
('Sapiens by Yuval Noah Harari', 'sapiens-by-yuval-noah-harari', 'Sapiens A Brief History of Humankind', 650, 25, 6, 'Harper', 4.8, 56),
('The Alchemist - Paulo Coelho', 'the-alchemist-paulo-coelho', 'The Alchemist by Paulo Coelho', 399, 565, 6, 'Harper', 4.7, 312),
('Harry Potter Box Set', 'harry-potter-box-set', 'Harry Potter Complete Box Set 7 Books', 4999, 207, 6, 'Bloomsbury', 4.9, 234),
('Deep Work - Cal Newport', 'deep-work-cal-newport', 'Deep Work by Cal Newport', 549, 242, 6, 'Grand', 4.7, 112),
('Thinking Fast and Slow', 'thinking-fast-and-slow', 'Thinking Fast and Slow by Daniel Kahneman', 649, 137, 6, 'Penguin', 4.7, 145),
('The Art of War - Sun Tzu', 'the-art-of-war-sun-tzu', 'The Art of War by Sun Tzu', 350, 30, 6, 'Classic', 4.6, 78),
('Python Programming Handbook', 'python-programming-handbook', 'Python Programming Complete Handbook', 899, 15, 6, 'Tech', 4.5, 56),
('Bangla Sahitya Classic Collection', 'bangla-sahitya-classic-collection', 'Bangla Sahitya Classic Collection', 499, 20, 6, 'Ananda', 4.5, 34);

INSERT INTO coupons (code, discount_percent, discount_amount, min_purchase, max_uses, used_count, valid_from, valid_to, is_active) VALUES
('WELCOME10', 10, 0, 500, 100, 0, '2025-01-01', '2026-12-31', 1),
('SAVE20', 20, 0, 1000, 50, 0, '2025-01-01', '2026-12-31', 1),
('FLAT500', 0, 500, 2000, 30, 0, '2025-01-01', '2026-12-31', 1),
('FREESHIP', 0, 0, 1500, 200, 0, '2025-01-01', '2026-12-31', 1),
('EID25', 25, 0, 3000, 25, 0, '2025-01-01', '2026-12-31', 1);

INSERT INTO blog_posts (title, slug, content) VALUES
('Top 10 Electronics Deals This Week', 'top-10-electronics-deals-this-week', 'Discover the best electronics deals available this week at Quick Mart. From smartphones to laptops, we have amazing discounts on top brands.'),
('Fashion Trends 2026 in Bangladesh', 'fashion-trends-2026-in-bangladesh', 'Explore the latest fashion trends hitting Bangladesh in 2026. From traditional wear to modern streetwear, find your style.'),
('Healthy Eating on a Budget', 'healthy-eating-on-a-budget', 'Learn how to maintain a healthy diet without breaking the bank. Tips and tricks for affordable nutrition.'),
('Best Kitchen Appliances for Your Home', 'best-kitchen-appliances-for-your-home', 'Upgrade your kitchen with these must-have appliances. From air fryers to rice cookers, find the best options.');

INSERT INTO reviews (product_id, user_id, rating, comment) VALUES
(1, 2, 5, 'Best phone I ever used! Camera is amazing.'),
(1, 3, 5, 'Worth every penny. Great performance.'),
(1, 4, 4, 'Excellent phone but a bit expensive.'),
(2, 2, 5, 'Superb camera and display quality.'),
(2, 5, 4, 'Great phone, battery life could be better.'),
(3, 3, 5, 'Fast and smooth. Best value for money.'),
(3, 6, 4, 'Good phone but heats up sometimes.'),
(9, 2, 5, 'Best noise cancelling headphones.'),
(9, 7, 5, 'Amazing sound quality and comfort.'),
(19, 3, 5, 'Perfect running shoes. Very comfortable.'),
(19, 8, 4, 'Good quality but runs slightly small.'),
(21, 4, 5, 'Super comfortable and stylish.'),
(31, 5, 4, 'Great watch. Very durable.'),
(37, 6, 5, 'Excellent refrigerator. Works perfectly.'),
(39, 7, 5, 'Best air fryer in this price range.'),
(49, 2, 5, 'Best protein powder for beginners.'),
(53, 3, 5, 'Good quality rice. Tastes great.'),
(57, 4, 4, 'Fresh eggs. Good packaging.'),
(65, 5, 5, 'Must read book. Changed my perspective.'),
(66, 6, 5, 'Excellent financial advice in simple language.');

-- Demo orders
INSERT INTO orders (user_id, order_number, total, subtotal, shipping_cost, status, payment_method, payment_status, shipping_name, shipping_phone, shipping_address, shipping_city, shipping_area) VALUES
(2, 'QM20260101000001', 170079, 169999, 80, 'delivered', 'bkash', 'paid', 'Demo User', '01700000001', 'House 1, Road 1', 'Dhaka', 'Gulshan'),
(3, 'QM20260102000002', 135079, 134999, 80, 'shipped', 'cod', 'pending', 'Demo User 2', '01700000002', 'House 2, Road 2', 'Dhaka', 'Banani'),
(4, 'QM20260103000003', 70079, 69999, 80, 'confirmed', 'nagad', 'paid', 'Demo User 3', '01700000003', 'House 3, Road 3', 'Chittagong', 'Agrabad'),
(5, 'QM20260104000004', 40079, 39999, 80, 'pending', 'cod', 'pending', 'Demo User 4', '01700000004', 'House 4, Road 4', 'Sylhet', 'Zindabazar'),
(2, 'QM20260105000005', 15079, 14999, 80, 'delivered', 'visa', 'paid', 'Demo User', '01700000001', 'House 1, Road 1', 'Dhaka', 'Gulshan');

INSERT INTO order_items (order_id, product_id, product_name, price, quantity) VALUES
(1, 1, 'iPhone 15 Pro Max', 169999, 1),
(2, 2, 'Samsung Galaxy S24 Ultra', 134999, 1),
(3, 3, 'OnePlus 12', 69999, 1),
(4, 11, 'JBL Flip 6', 12999, 1),
(5, 19, 'Nike Air Max 270', 14999, 1);

-- Advanced feature tables
CREATE TABLE IF NOT EXISTS product_compare (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE(user_id, product_id)
);

CREATE TABLE IF NOT EXISTS size_guides (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    size_name TEXT NOT NULL,
    measurements TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bundles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    bundle_price REAL NOT NULL,
    stock_limit INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bundle_products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bundle_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER DEFAULT 1,
    FOREIGN KEY (bundle_id) REFERENCES bundles(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS wallets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    balance REAL DEFAULT 0,
    total_loaded REAL DEFAULT 0,
    total_spent REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS wallet_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    tx_type TEXT NOT NULL,
    description TEXT,
    reference_type TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS store_locations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT,
    city TEXT,
    phone TEXT,
    email TEXT,
    hours TEXT,
    latitude REAL DEFAULT 0,
    longitude REAL DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS flash_sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    discount_percent REAL NOT NULL,
    start_date DATETIME,
    end_date DATETIME,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS flash_sale_products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    flash_sale_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    sale_price REAL NOT NULL,
    FOREIGN KEY (flash_sale_id) REFERENCES flash_sales(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS gift_wraps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_gift_wraps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    gift_wrap_id INTEGER,
    message TEXT,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (gift_wrap_id) REFERENCES gift_wraps(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS loyalty_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    points INTEGER DEFAULT 0,
    total_earned INTEGER DEFAULT 0,
    total_redeemed INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS loyalty_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    points INTEGER NOT NULL,
    tx_type TEXT NOT NULL,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS price_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    target_price REAL NOT NULL,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    plan_name TEXT,
    frequency TEXT DEFAULT 'monthly',
    price REAL NOT NULL,
    status TEXT DEFAULT 'active',
    next_delivery DATE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS push_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    message TEXT,
    type TEXT DEFAULT 'info',
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS staff_roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    permissions TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS affiliate_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    affiliate_code TEXT UNIQUE NOT NULL,
    commission_rate REAL DEFAULT 10,
    clicks INTEGER DEFAULT 0,
    conversions INTEGER DEFAULT 0,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS activity_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action TEXT NOT NULL,
    details TEXT,
    ip_address TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS revenue_targets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_name TEXT NOT NULL,
    target_amount REAL NOT NULL,
    period_start DATE,
    period_end DATE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS barcodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    barcode TEXT UNIQUE NOT NULL,
    product_id INTEGER,
    variant_id INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

-- Seed advanced data
INSERT INTO size_guides (category, size_name, measurements) VALUES
('T-Shirts', 'S', '{"chest":"36-38","length":"27","shoulder":"17"}'),
('T-Shirts', 'M', '{"chest":"38-40","length":"28","shoulder":"18"}'),
('T-Shirts', 'L', '{"chest":"40-42","length":"29","shoulder":"19"}'),
('T-Shirts', 'XL', '{"chest":"42-44","length":"30","shoulder":"20"}'),
('Jeans', '30', '{"waist":"30","inseam":"32","fit":"Slim"}'),
('Jeans', '32', '{"waist":"32","inseam":"32","fit":"Slim"}'),
('Jeans', '34', '{"waist":"34","inseam":"32","fit":"Regular"}'),
('Shoes', '40', '{"eu":"40","us":"8","uk":"7","cm":"25.5"}'),
('Shoes', '42', '{"eu":"42","us":"9","uk":"8","cm":"27"}'),
('Shoes', '44', '{"eu":"44","us":"10","uk":"9","cm":"28.5"}');

INSERT INTO bundles (name, description, bundle_price, stock_limit) VALUES
('Tech Starter Pack', 'Headphones + Power Bank + Mouse', 19999, 100),
('Kitchen Essentials', 'Cooker + Pan Set + Blender', 9999, 50),
('Fitness Bundle', 'Protein Powder + Supplement + Shaker', 6999, 75);

INSERT INTO bundle_products (bundle_id, product_id, quantity) VALUES
(1, 10, 1), (1, 23, 1), (1, 21, 1),
(2, 30, 1), (2, 32, 1), (2, 34, 1),
(3, 40, 1), (3, 42, 1), (3, 42, 1);

INSERT INTO wallets (user_id, balance, total_loaded, total_spent) VALUES
(2, 500, 1000, 500),
(3, 200, 500, 300),
(4, 100, 300, 200);

INSERT INTO store_locations (name, address, city, phone, email, hours, latitude, longitude) VALUES
('Quick Mart Gulshan', 'Plot 12, Road 135, Gulshan-2', 'Dhaka', '+8801700000000', 'gulshan@quickmart.com', 'Sat-Thu: 10AM-10PM', 23.7925, 90.4078),
('Quick Mart Banani', 'Road 11, Banani DOHS', 'Dhaka', '+8801700000001', 'banani@quickmart.com', 'Sat-Thu: 10AM-10PM', 23.7937, 90.4023),
('Quick Mart Uttara', 'Sector 7, Uttara', 'Dhaka', '+8801700000002', 'uttara@quickmart.com', 'Sat-Thu: 10AM-10PM', 23.8759, 90.3795),
('Quick Mart Chittagong', 'Agrabad Commercial Area', 'Chittagong', '+8801700000003', 'chittagong@quickmart.com', 'Sat-Thu: 10AM-9PM', 22.3603, 91.7830),
('Quick Mart Sylhet', 'Zindabazar Main Road', 'Sylhet', '+8801700000004', 'sylhet@quickmart.com', 'Sat-Thu: 10AM-9PM', 24.8949, 91.8687);

INSERT INTO gift_wraps (name, description, price) VALUES
('Standard Gift Wrap', 'Brown kraft paper with ribbon', 50),
('Premium Gift Box', 'Decorative box with tissue paper', 150),
('Birthday Special', 'Colorful birthday themed wrapping', 100),
('Love Theme', 'Red and pink romantic wrapping', 120);

INSERT INTO flash_sales (name, discount_percent, start_date, end_date) VALUES
('Summer Mega Sale', 25, '2026-06-01', '2026-06-30'),
('Flash Friday', 30, '2026-06-05', '2026-06-06'),
('Clearance Sale', 40, '2026-06-15', '2026-07-15');

INSERT INTO flash_sale_products (flash_sale_id, product_id, sale_price) VALUES
(1, 1, 127499), (1, 2, 101249), (1, 3, 52499),
(2, 9, 29999), (2, 19, 10499), (2, 21, 9749),
(3, 11, 7799), (3, 30, 2999), (3, 48, 359);

INSERT INTO loyalty_points (user_id, points, total_earned, total_redeemed) VALUES
(2, 500, 800, 300),
(3, 200, 400, 200),
(4, 100, 200, 100);

INSERT INTO loyalty_transactions (user_id, points, tx_type, description) VALUES
(2, 50, 'earned', 'Purchase QM20260101000001'),
(2, 50, 'earned', 'Purchase QM20260105000005'),
(2, -300, 'redeemed', 'Discount redemption'),
(3, 40, 'earned', 'Purchase QM20260102000002'),
(3, -200, 'redeemed', 'Discount redemption');

INSERT INTO affiliate_links (user_id, affiliate_code, commission_rate, clicks, conversions, status) VALUES
(2, 'AFF-DEMO1-2026', 10, 150, 12, 'active'),
(3, 'AFF-DEMO2-2026', 15, 80, 5, 'active');

INSERT INTO activity_log (user_id, action, details, ip_address) VALUES
(1, 'login', 'Admin login', '127.0.0.1'),
(2, 'login', 'User login', '127.0.0.1'),
(2, 'add_to_cart', 'iPhone 15 Pro Max x1', '127.0.0.1'),
(2, 'place_order', 'Order QM20260101000001 placed', '127.0.0.1'),
(3, 'login', 'User login', '127.0.0.1'),
(3, 'add_to_cart', 'Samsung Galaxy S24 Ultra x1', '127.0.0.1'),
(3, 'place_order', 'Order QM20260102000002 placed', '127.0.0.1'),
(1, 'product_update', 'Updated iPhone 15 Pro Max stock', '127.0.0.1'),
(1, 'order_status', 'Order QM20260101000001 marked delivered', '127.0.0.1');

INSERT INTO revenue_targets (target_name, target_amount, period_start, period_end) VALUES
('June 2026 Target', 500000, '2026-06-01', '2026-06-30'),
('Q2 2026 Target', 1500000, '2026-04-01', '2026-06-30'),
('Annual 2026 Target', 5000000, '2026-01-01', '2026-12-31');

CREATE TABLE IF NOT EXISTS refund_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    reason TEXT,
    amount REAL DEFAULT 0,
    status TEXT DEFAULT 'pending',
    admin_notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS order_tracking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    status TEXT NOT NULL,
    location TEXT,
    note TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS product_questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    question TEXT NOT NULL,
    answer TEXT,
    answered_by INTEGER,
    is_answered INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (answered_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    phone TEXT,
    address TEXT,
    city TEXT,
    is_customer INTEGER DEFAULT 1,
    is_staff_member INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS stock_movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    movement_type TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    notes TEXT,
    created_by INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS promotions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    promotion_type TEXT DEFAULT 'discount',
    discount_percent REAL DEFAULT 0,
    discount_amount REAL DEFAULT 0,
    min_purchase REAL DEFAULT 0,
    start_date DATETIME,
    end_date DATETIME,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vendors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    shop_name TEXT NOT NULL,
    description TEXT,
    phone TEXT,
    address TEXT,
    is_verified INTEGER DEFAULT 0,
    commission_rate REAL DEFAULT 10,
    total_earnings REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    payment_method TEXT NOT NULL,
    amount REAL NOT NULL,
    transaction_id TEXT,
    card_last_four TEXT,
    card_type TEXT,
    status TEXT DEFAULT 'completed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS recently_viewed (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    session_key TEXT,
    product_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER NOT NULL,
    receiver_id INTEGER NOT NULL,
    message TEXT NOT NULL,
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS cart_abandonment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    session_key TEXT,
    items_summary TEXT,
    cart_total REAL DEFAULT 0,
    recovery_sent INTEGER DEFAULT 0,
    email_sent INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS sms_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER,
    phone TEXT NOT NULL,
    message TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS email_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER,
    email TEXT NOT NULL,
    subject TEXT,
    body TEXT,
    status TEXT DEFAULT 'sent',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
);

INSERT INTO barcodes (barcode, product_id) VALUES
('QM2026010001', 1), ('QM2026010002', 2), ('QM2026010003', 3),
('QM2026010004', 4), ('QM2026010005', 5), ('QM2026010006', 9),
('QM2026010007', 19), ('QM2026010008', 21), ('QM2026010009', 37),
('QM2026010010', 48);

INSERT INTO profiles (user_id, phone, address, city) VALUES
(1, '01700000000', 'Dhanmondi', 'Dhaka'),
(2, '01700000001', 'Gulshan', 'Dhaka'),
(3, '01700000002', 'Banani', 'Dhaka'),
(4, '01700000003', 'Agrabad', 'Chittagong'),
(5, '01700000004', 'Zindabazar', 'Sylhet');

INSERT INTO promotions (name, promotion_type, discount_percent, discount_amount, min_purchase, start_date, end_date, status) VALUES
('Summer Clearance', 'clearance', 30, 0, 500, '2026-06-01', '2026-07-31', 'active'),
('Flat 500 Off', 'flat', 0, 500, 2000, '2026-06-01', '2026-06-30', 'active'),
('EID Special', 'discount', 20, 0, 1000, '2026-06-15', '2026-06-20', 'active');

INSERT INTO order_tracking (order_id, status, location, note) VALUES
(1, 'pending', 'System', 'Order placed'),
(1, 'confirmed', 'System', 'Order confirmed'),
(1, 'processing', 'Dhaka Warehouse', 'Packing in progress'),
(1, 'shipped', 'Dhaka Hub', 'Shipped via Pathao Courier'),
(1, 'delivered', 'Gulshan', 'Delivered to customer'),
(2, 'pending', 'System', 'Order placed'),
(2, 'confirmed', 'System', 'Order confirmed'),
(2, 'processing', 'Dhaka Warehouse', 'Packing in progress'),
(2, 'shipped', 'Dhaka Hub', 'Shipped via Pathao Courier');

INSERT INTO payments (order_id, payment_method, amount, transaction_id, status) VALUES
(1, 'bkash', 170079, 'BK-20260101-001', 'completed'),
(2, 'cod', 135079, NULL, 'pending'),
(3, 'nagad', 70079, 'NG-20260103-001', 'completed'),
(5, 'visa', 15079, 'VS-20260105-001', 'completed');
