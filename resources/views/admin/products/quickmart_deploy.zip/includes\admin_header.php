<?php
require_once __DIR__ . '/functions.php';
if (!isLoggedIn() || !isAdmin()) { redirect(SITE_URL . '/admin/login.php'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/svg+xml" href="<?= SITE_URL ?>/favicon.svg">
    <title><?= $pageTitle ?? 'Admin' ?> - Quick Mart</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="<?= SITE_URL ?>/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= SITE_URL ?>/assets/css/all.min.css" rel="stylesheet">
    <link href="<?= SITE_URL ?>/assets/css/admin.css" rel="stylesheet">
</head>
<body>
<div class="d-flex" id="wrapper">
<aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <i class="fas fa-store"></i>
        <span>Quick Mart</span>
    </div>
    <nav class="sidebar-nav">
        <a href="<?= SITE_URL ?>/admin/" class="<?= basename($_SERVER['SCRIPT_NAME'])=='index.php'?'active':'' ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="<?= SITE_URL ?>/admin/bi360.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='bi360.php'?'active':'' ?>"><i class="fas fa-chart-pie"></i> BI 360</a>
        <div class="sidebar-divider"><small>ORDERS</small></div>
        <?php if (hasPermission('can_manage_orders')): ?>
        <a href="<?= SITE_URL ?>/admin/orders.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='orders.php'?'active':'' ?>"><i class="fas fa-shopping-cart"></i> All Orders</a>
        <a href="<?= SITE_URL ?>/admin/payment_history.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='payment_history.php'?'active':'' ?>"><i class="fas fa-credit-card"></i> Payment History</a>
        <a href="<?= SITE_URL ?>/admin/invoices.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='invoices.php'?'active':'' ?>"><i class="fas fa-file-invoice"></i> Invoice Records</a>
        <?php endif; ?>
        <div class="sidebar-divider"><small>STORE</small></div>
        <?php if (hasPermission('can_manage_products')): ?>
        <a href="<?= SITE_URL ?>/admin/products.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='products.php'?'active':'' ?>"><i class="fas fa-box"></i> Products</a>
        <a href="<?= SITE_URL ?>/admin/variants.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='variants.php'?'active':'' ?>"><i class="fas fa-layer-group"></i> Variants</a>
        <a href="<?= SITE_URL ?>/admin/categories.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='categories.php'?'active':'' ?>"><i class="fas fa-tags"></i> Categories</a>
        <?php endif; ?>
        <a href="<?= SITE_URL ?>/admin/coupons.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='coupons.php'?'active':'' ?>"><i class="fas fa-ticket-alt"></i> Coupons</a>
        <a href="<?= SITE_URL ?>/admin/gift_wraps.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='gift_wraps.php'?'active':'' ?>"><i class="fas fa-gift"></i> Gift Wraps</a>
        <div class="sidebar-divider"><small>CONTENT</small></div>
        <a href="<?= SITE_URL ?>/admin/blog.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='blog.php'?'active':'' ?>"><i class="fas fa-blog"></i> Blog Posts</a>
        <div class="sidebar-divider"><small>ANALYTICS</small></div>
        <a href="<?= SITE_URL ?>/admin/inventory.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='inventory.php'?'active':'' ?>"><i class="fas fa-warehouse"></i> Inventory</a>
        <?php if (hasPermission('can_manage_reports')): ?>
        <a href="<?= SITE_URL ?>/admin/sales.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='sales.php'?'active':'' ?>"><i class="fas fa-chart-line"></i> Sales</a>
        <div class="sidebar-divider"><small>REPORTS</small></div>
        <a href="<?= SITE_URL ?>/admin/reports.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='reports.php'?'active':'' ?>"><i class="fas fa-chart-bar"></i> Reports</a>
        <?php endif; ?>
        <div class="sidebar-divider"><small>PROMOTIONS</small></div>
        <a href="<?= SITE_URL ?>/admin/promotions.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='promotions.php'?'active':'' ?>"><i class="fas fa-percent"></i> Promotions</a>
        <a href="<?= SITE_URL ?>/admin/flash_sales.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='flash_sales.php'?'active':'' ?>"><i class="fas fa-bolt"></i> Flash Sale</a>
        <div class="sidebar-divider"><small>SUPPORT</small></div>
        <a href="<?= SITE_URL ?>/store/chat.php" class=""><i class="fas fa-comments"></i> Live Chat</a>
        <a href="<?= SITE_URL ?>/admin/sms_settings.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='sms_settings.php'?'active':'' ?>"><i class="fas fa-sms"></i> SMS Settings</a>
        <a href="<?= SITE_URL ?>/admin/email_notifications.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='email_notifications.php'?'active':'' ?>"><i class="fas fa-envelope"></i> Email</a>
        <div class="sidebar-divider"><small>GROWTH</small></div>
        <a href="<?= SITE_URL ?>/admin/wallets.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='wallets.php'?'active':'' ?>"><i class="fas fa-wallet"></i> Wallet</a>
        <a href="<?= SITE_URL ?>/admin/bundles.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='bundles.php'?'active':'' ?>"><i class="fas fa-boxes"></i> Bundles</a>
        <a href="<?= SITE_URL ?>/admin/affiliates.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='affiliates.php'?'active':'' ?>"><i class="fas fa-link"></i> Affiliates</a>
        <a href="<?= SITE_URL ?>/admin/loyalty.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='loyalty.php'?'active':'' ?>"><i class="fas fa-star"></i> Loyalty Points</a>
        <a href="<?= SITE_URL ?>/admin/revenue_target.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='revenue_target.php'?'active':'' ?>"><i class="fas fa-bullseye"></i> Revenue Target</a>
        <a href="<?= SITE_URL ?>/admin/customers.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='customers.php'?'active':'' ?>"><i class="fas fa-users"></i> Customers</a>
        <a href="<?= SITE_URL ?>/admin/vendors.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='vendors.php'?'active':'' ?>"><i class="fas fa-store-alt"></i> Vendors</a>
        <a href="<?= SITE_URL ?>/admin/users.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='users.php'?'active':'' ?>"><i class="fas fa-user-cog"></i> User Control</a>
        <div class="sidebar-divider"><small>TOOLS</small></div>
        <a href="<?= SITE_URL ?>/admin/size_guides.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='size_guides.php'?'active':'' ?>"><i class="fas fa-ruler"></i> Size Guide</a>
        <a href="<?= SITE_URL ?>/admin/push_notifications.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='push_notifications.php'?'active':'' ?>"><i class="fas fa-bell"></i> Push Notifications</a>
        <?php if (hasPermission('can_manage_settings')): ?>
        <a href="<?= SITE_URL ?>/admin/staff.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='staff.php'?'active':'' ?>"><i class="fas fa-user-shield"></i> Staff Roles</a>
        <?php endif; ?>
        <a href="<?= SITE_URL ?>/admin/barcodes.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='barcodes.php'?'active':'' ?>"><i class="fas fa-barcode"></i> Barcodes</a>
        <a href="<?= SITE_URL ?>/admin/store_locations.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='store_locations.php'?'active':'' ?>"><i class="fas fa-map-marker-alt"></i> Store Locations</a>
        <a href="<?= SITE_URL ?>/admin/activity_log.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='activity_log.php'?'active':'' ?>"><i class="fas fa-history"></i> Activity Log</a>
        <a href="<?= SITE_URL ?>/admin/subscriptions.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='subscriptions.php'?'active':'' ?>"><i class="fas fa-sync-alt"></i> Subscriptions</a>
        <a href="<?= SITE_URL ?>/admin/price_alerts.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='price_alerts.php'?'active':'' ?>"><i class="fas fa-bell"></i> Price Alerts</a>
        <div class="sidebar-divider"><small>SYSTEM</small></div>
        <?php if (hasPermission('can_manage_settings')): ?>
        <a href="<?= SITE_URL ?>/admin/site_config.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='site_config.php'?'active':'' ?>"><i class="fas fa-cog"></i> Site Config</a>
        <?php endif; ?>
        <a href="<?= SITE_URL ?>/admin/cart_recovery.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='cart_recovery.php'?'active':'' ?>"><i class="fas fa-redo"></i> Cart Recovery</a>
        <a href="<?= SITE_URL ?>/admin/import_export.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='import_export.php'?'active':'' ?>"><i class="fas fa-file-import"></i> Import/Export</a>
        <a href="<?= SITE_URL ?>/admin/auto_backup.php" class="<?= basename($_SERVER['SCRIPT_NAME'])=='auto_backup.php'?'active':'' ?>"><i class="fas fa-database"></i> Backup</a>
        <div style="height:20px"></div>
    </nav>
</aside>
<div id="sidebar-overlay"></div>
<div class="main-content" id="mainContent">
    <nav class="navbar navbar-expand-lg top-navbar">
        <div class="container-fluid">
            <button class="btn btn-sm" id="toggle-sidebar"><i class="fas fa-bars"></i></button>
            <div class="admin-global-search position-relative ms-3">
                <i class="fas fa-search search-icon"></i>
                <input type="text" id="adminSearchInput" class="form-control form-control-sm" placeholder="Search products, orders, customers, pages..." autocomplete="off">
                <kbd class="search-kbd d-none d-md-inline">Ctrl+K</kbd>
                <div id="adminSearchResults" class="admin-search-dropdown"></div>
            </div>
            <div class="d-flex align-items-center ms-auto gap-2">
                <a href="<?= SITE_URL ?>/store/" class="text-decoration-none"><i class="fas fa-user"></i> <?= htmlspecialchars($_SESSION['username']) ?></a>
                <a href="<?= SITE_URL ?>/store/" class="btn btn-outline-primary btn-sm"><i class="fas fa-store"></i> Store</a>
                <a href="<?= SITE_URL ?>/store/logout.php" class="btn btn-outline-danger btn-sm"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </nav>
    <script>
    (function(){
        const input = document.getElementById('adminSearchInput');
        const dropdown = document.getElementById('adminSearchResults');
        let timer = null;
        if (!input || !dropdown) return;
        input.addEventListener('input', function(){
            clearTimeout(timer);
            const q = this.value.trim();
            if (q.length < 2) { dropdown.style.display='none'; dropdown.innerHTML=''; return; }
            timer = setTimeout(function(){
                fetch('<?= SITE_URL ?>/admin/search_api.php?q='+encodeURIComponent(q))
                    .then(r=>r.json())
                    .then(data=>{
                        if (!data.length) { dropdown.innerHTML='<div class="search-item text-muted">No results found</div>'; dropdown.style.display='block'; return; }
                        let html='';
                        data.forEach(function(r){
                            html+='<a href="'+r.url+'" class="search-item"><div class="d-flex align-items-center gap-2"><i class="'+r.icon+'" style="color:'+r.color+';width:20px;text-align:center"></i><div><div class="search-title">'+r.title+'</div><div class="search-sub">'+r.subtitle+'</div></div><span class="search-type badge" style="background:'+r.color+'20;color:'+r.color+'">'+r.type+'</span></div></a>';
                        });
                        dropdown.innerHTML=html;
                        dropdown.style.display='block';
                    });
            },300);
        });
        input.addEventListener('focus',function(){ if(dropdown.innerHTML) dropdown.style.display='block'; });
        document.addEventListener('click',function(e){ if(!e.target.closest('.admin-global-search')) dropdown.style.display='none'; });
        document.addEventListener('keydown',function(e){ if((e.ctrlKey||e.metaKey)&&e.key==='k'){e.preventDefault();input.focus();} if(e.key==='Escape'){dropdown.style.display='none';input.blur();} });
        input.addEventListener('keydown',function(e){
            const items=dropdown.querySelectorAll('.search-item:not(.text-muted)');
            const active=dropdown.querySelector('.search-item.active');
            let idx=Array.from(items).indexOf(active);
            if(e.key==='ArrowDown'){e.preventDefault();if(active)active.classList.remove('active');idx=idx<items.length-1?idx+1:0;items[idx]?.classList.add('active');}
            if(e.key==='ArrowUp'){e.preventDefault();if(active)active.classList.remove('active');idx=idx>0?idx-1:items.length-1;items[idx]?.classList.add('active');}
            if(e.key==='Enter'&&active){e.preventDefault();active.click();}
        });
    })();
    </script>
    <div class="content-wrapper">
    <?= getAlert() ?>
