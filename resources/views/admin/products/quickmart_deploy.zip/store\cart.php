<?php
$pageTitle = 'Shopping Cart - Quick Mart';
require_once __DIR__ . '/../includes/header.php';

$sid = getCartSession();
if (isLoggedIn()) {
    $cartItems = fetchAll("SELECT c.*, p.name, p.price, p.stock, p.slug FROM cart_items c JOIN products p ON c.product_id=p.id WHERE c.user_id=?", [$_SESSION['user_id']]);
} else {
    $cartItems = fetchAll("SELECT c.*, p.name, p.price, p.stock, p.slug FROM cart_items c JOIN products p ON c.product_id=p.id WHERE c.session_id=?", [$sid]);
}

$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
$shipping = $subtotal > 0 ? 80 : 0;
$total = $subtotal + $shipping;
?>

<h2 class="mb-4"><i class="fas fa-shopping-cart"></i> Shopping Cart</h2>

<?php if (empty($cartItems)): ?>
<div class="text-center py-5">
    <i class="fas fa-shopping-cart fa-4x text-muted mb-3"></i>
    <h5>Your cart is empty</h5>
    <a href="<?= SITE_URL ?>/store/products.php" class="btn btn-primary mt-3">Start Shopping</a>
</div>
<?php else: ?>
<div class="table-responsive">
    <table class="table table-custom">
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cartItems as $item): ?>
            <tr>
                <td>
                    <a href="<?= SITE_URL ?>/store/product.php?slug=<?= $item['slug'] ?>" class="text-decoration-none fw-bold">
                        <?= htmlspecialchars($item['name']) ?>
                    </a>
                </td>
                <td><?= formatPrice($item['price']) ?></td>
                <td style="width:120px">
                    <form method="POST" action="<?= SITE_URL ?>/api/cart.php" class="d-flex">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                        <input type="number" name="quantity" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['stock'] ?>" class="form-control form-control-sm">
                        <button type="submit" class="btn btn-sm btn-outline-primary ms-1"><i class="fas fa-sync"></i></button>
                    </form>
                </td>
                <td class="fw-bold"><?= formatPrice($item['price'] * $item['quantity']) ?></td>
                <td>
                    <form method="POST" action="<?= SITE_URL ?>/api/cart.php" style="display:inline">
                        <input type="hidden" name="action" value="remove">
                        <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<div class="row">
    <div class="col-md-6">
        <form method="POST" action="<?= SITE_URL ?>/api/cart.php" class="card card-custom p-3">
            <input type="hidden" name="action" value="coupon">
            <div class="input-group">
                <input type="text" name="coupon_code" class="form-control" placeholder="Coupon code">
                <button type="submit" class="btn btn-primary">Apply</button>
            </div>
        </form>
    </div>
    <div class="col-md-6">
        <div class="card card-custom p-3">
            <h5>Order Summary</h5>
            <div class="d-flex justify-content-between mb-2">
                <span>Subtotal</span><span><?= formatPrice($subtotal) ?></span>
            </div>
            <div class="d-flex justify-content-between mb-2">
                <span>Shipping (Inside Dhaka)</span><span><?= formatPrice($shipping) ?></span>
            </div>
            <hr>
            <div class="d-flex justify-content-between mb-3">
                <strong>Total</strong><strong class="text-primary"><?= formatPrice($total) ?></strong>
            </div>
            <?php if (isLoggedIn()): ?>
            <a href="<?= SITE_URL ?>/store/checkout.php" class="btn btn-primary w-100">Proceed to Checkout</a>
            <?php else: ?>
            <a href="<?= SITE_URL ?>/store/login.php" class="btn btn-primary w-100">Login to Checkout</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
