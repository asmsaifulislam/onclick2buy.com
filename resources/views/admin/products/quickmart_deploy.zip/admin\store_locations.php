<?php
$pageTitle = 'Store Locations';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM store_locations WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/store_locations.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [$_POST['name'], $_POST['address'], $_POST['city'], $_POST['phone'], $_POST['email'], $_POST['hours'], (float)$_POST['latitude'], (float)$_POST['longitude']];
    if ($id) { query("UPDATE store_locations SET name=?, address=?, city=?, phone=?, email=?, hours=?, latitude=?, longitude=? WHERE id=?", array_merge($data, [$id])); }
    else { query("INSERT INTO store_locations (name, address, city, phone, email, hours, latitude, longitude) VALUES (?,?,?,?,?,?,?,?)", $data); }
    setAlert('success', 'Location saved!'); redirect(SITE_URL . '/admin/store_locations.php');
}
$locations = fetchAll("SELECT * FROM store_locations ORDER BY name");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Store Locations (<?= count($locations) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_name').value='';document.getElementById('f_addr').value='';document.getElementById('f_city').value='';document.getElementById('f_phone').value='';document.getElementById('f_email').value='';document.getElementById('f_hours').value='';document.getElementById('f_lat').value='';document.getElementById('f_lng').value='';document.getElementById('modalTitle').textContent='Add Location';"><i class="fas fa-plus"></i> Add Location</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>Name</th><th>Address</th><th>City</th><th>Phone</th><th>Hours</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($locations as $l): ?>
<tr><td><strong><?= htmlspecialchars($l['name']) ?></strong></td><td class="small"><?= htmlspecialchars($l['address']) ?></td><td><?= htmlspecialchars($l['city']) ?></td><td><?= htmlspecialchars($l['phone']) ?></td><td class="small"><?= htmlspecialchars($l['hours']) ?></td>
<td><button class="btn btn-sm btn-warning" onclick="document.getElementById('f_id').value='<?= $l['id'] ?>';document.getElementById('f_name').value='<?= htmlspecialchars($l['name']) ?>';document.getElementById('f_addr').value='<?= htmlspecialchars($l['address']) ?>';document.getElementById('f_city').value='<?= htmlspecialchars($l['city']) ?>';document.getElementById('f_phone').value='<?= htmlspecialchars($l['phone']) ?>';document.getElementById('f_email').value='<?= htmlspecialchars($l['email']) ?>';document.getElementById('f_hours').value='<?= htmlspecialchars($l['hours']) ?>';document.getElementById('f_lat').value='<?= $l['latitude'] ?>';document.getElementById('f_lng').value='<?= $l['longitude'] ?>';document.getElementById('modalTitle').textContent='Edit Location';new bootstrap.Modal(document.getElementById('modal')).show();"><i class="fas fa-edit"></i></button> <a href="?delete=<?= $l['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Location</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" id="f_name" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Address</label><input type="text" name="address" id="f_addr" class="form-control" required></div>
<div class="row g-3 mb-3"><div class="col-6"><label class="form-label">City</label><input type="text" name="city" id="f_city" class="form-control" required></div>
<div class="col-6"><label class="form-label">Phone</label><input type="text" name="phone" id="f_phone" class="form-control"></div></div>
<div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" id="f_email" class="form-control"></div>
<div class="mb-3"><label class="form-label">Hours</label><input type="text" name="hours" id="f_hours" class="form-control" placeholder="e.g., Sat-Thu: 10AM-10PM"></div>
<div class="row g-3 mb-3"><div class="col-6"><label class="form-label">Latitude</label><input type="number" step="any" name="latitude" id="f_lat" class="form-control"></div>
<div class="col-6"><label class="form-label">Longitude</label><input type="number" step="any" name="longitude" id="f_lng" class="form-control"></div></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
