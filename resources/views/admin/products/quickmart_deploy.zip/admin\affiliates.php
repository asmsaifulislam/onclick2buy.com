<?php
$pageTitle = 'Affiliate Links';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM affiliate_links WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/affiliates.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $code = $_POST['affiliate_code'] ?? uniqid('aff-');
    $data = [$_POST['user_id'], $code, (float)$_POST['commission_rate'], (int)$_POST['is_active']];
    if ($id) { query("UPDATE affiliate_links SET user_id=?, code=?, commission_rate=?, is_active=? WHERE id=?", array_merge($data, [$id])); }
    else { query("INSERT INTO affiliate_links (user_id, code, commission_rate, is_active) VALUES (?,?,?,?)", $data); }
    setAlert('success', 'Affiliate link saved!'); redirect(SITE_URL . '/admin/affiliates.php');
}
$affiliates = fetchAll("SELECT al.*, u.username FROM affiliate_links al LEFT JOIN users u ON al.user_id=u.id ORDER BY al.created_at DESC");
$users = fetchAll("SELECT id, username FROM users ORDER BY username");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Affiliate Links (<?= count($affiliates) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_user').value='';document.getElementById('f_code').value='';document.getElementById('f_rate').value='10';document.getElementById('f_active').value='1';document.getElementById('modalTitle').textContent='Add Affiliate';"><i class="fas fa-plus"></i> Add</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>User</th><th>Code</th><th>Commission</th><th>Clicks</th><th>Sales</th><th>Earnings</th><th>Status</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($affiliates as $a): ?>
<tr><td><?= htmlspecialchars($a['username'] ?? 'N/A') ?></td><td><code><?= htmlspecialchars($a['code']) ?></code></td><td><?= $a['commission_rate'] ?>%</td><td><?= $a['total_clicks'] ?></td><td><?= $a['total_sales'] ?></td><td><?= formatPrice($a['total_earned']) ?></td>
<td><span class="badge bg-<?= $a['is_active']?'success':'secondary' ?>"><?= $a['is_active']?'Active':'Inactive' ?></span></td>
<td><a href="?delete=<?= $a['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Affiliate</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">User</label><select name="user_id" id="f_user" class="form-select" required><option value="">Select User</option><?php foreach ($users as $u): ?><option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['username']) ?></option><?php endforeach; ?></select></div>
<div class="mb-3"><label class="form-label">Affiliate Code</label><input type="text" name="affiliate_code" id="f_code" class="form-control"></div>
<div class="mb-3"><label class="form-label">Commission Rate %</label><input type="number" step="0.1" name="commission_rate" id="f_rate" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Status</label><select name="is_active" id="f_active" class="form-select"><option value="1">Active</option><option value="0">Inactive</option></select></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
