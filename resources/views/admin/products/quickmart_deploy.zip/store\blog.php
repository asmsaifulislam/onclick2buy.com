<?php
$pageTitle = 'Blog - Quick Mart';
require_once __DIR__ . '/../includes/header.php';

$posts = fetchAll("SELECT * FROM blog_posts WHERE is_published=1 ORDER BY created_at DESC");
?>

<h2 class="mb-4"><i class="fas fa-newspaper"></i> Blog</h2>

<div class="row g-4">
    <?php if (empty($posts)): ?>
    <div class="col-12 text-center py-5">
        <i class="fas fa-newspaper fa-4x text-muted mb-3"></i>
        <h5>No blog posts yet</h5>
    </div>
    <?php else: ?>
    <?php foreach ($posts as $post): ?>
    <div class="col-md-6">
        <div class="card h-100 card-custom">
            <div class="card-body">
                <h5><?= htmlspecialchars($post['title']) ?></h5>
                <p class="text-muted small"><?= date('F d, Y', strtotime($post['created_at'])) ?></p>
                <p><?= htmlspecialchars(strlen($post['content']) > 200 ? substr($post['content'], 0, 200) . '...' : $post['content']) ?></p>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
