<?php
$pageTitle = 'Subscriptions - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productId = (int)($_POST['product_id'] ?? 0);
    $plan = $_POST['plan_name'] ?? '';
    $freq = $_POST['frequency'] ?? 'monthly';
    $product = fetch("SELECT * FROM products WHERE id=?", [$productId]);
    if ($product && $plan) {
        query("INSERT INTO subscriptions (user_id, product_id, plan_name, frequency, price, status, next_delivery) VALUES (?,?,?,?,?,?,'')", [$_SESSION['user_id'], $productId, $plan, $freq, $product['price'], 'active']);
        setAlert('success', 'Subscription created!');
        redirect(SITE_URL . '/store/subscriptions.php');
    }
}
if (isset($_GET['cancel'])) {
    query("UPDATE subscriptions SET status='cancelled' WHERE id=? AND user_id=?", [(int)$_GET['cancel'], $_SESSION['user_id']]);
    setAlert('success', 'Subscription cancelled.');
    redirect(SITE_URL . '/store/subscriptions.php');
}

$subs = fetchAll("SELECT s.*, p.name as product_name FROM subscriptions s LEFT JOIN products p ON s.product_id=p.id WHERE s.user_id=? ORDER BY s.created_at DESC", [$_SESSION['user_id']]);
$products = fetchAll("SELECT id, name, price FROM products WHERE is_active=1 ORDER BY name LIMIT 50");
?>
<h2 class="mb-4"><i class="fas fa-sync-alt"></i> My Subscriptions</h2>
<div class="card card-custom p-4 mb-4">
    <h5>New Subscription</h5>
    <form method="POST" class="row g-3">
        <div class="col-md-3">
            <select name="product_id" class="form-select" required>
                <option value="">Select Product</option>
                <?php foreach ($products as $p): ?>
                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?> (<?= formatPrice($p['price']) ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3"><input type="text" name="plan_name" class="form-control" placeholder="Plan name" required></div>
        <div class="col-md-2">
            <select name="frequency" class="form-select">
                <option value="weekly">Weekly</option>
                <option value="monthly" selected>Monthly</option>
                <option value="quarterly">Quarterly</option>
            </select>
        </div>
        <div class="col-md-2"><button type="submit" class="btn btn-primary w-100">Subscribe</button></div>
    </form>
</div>
<div class="row g-4">
    <?php if (empty($subs)): ?>
    <div class="col-12 text-center py-5"><i class="fas fa-sync-alt fa-4x text-muted mb-3" style="opacity:0.3"></i><h5>No subscriptions yet</h5></div>
    <?php else: ?>
    <?php foreach ($subs as $s): ?>
    <div class="col-md-4">
        <div class="card card-custom p-4 h-100">
            <div class="d-flex justify-content-between">
                <span class="badge bg-<?= $s['status']=='active'?'success':($s['status']=='paused'?'warning':'danger') ?>"><?= ucfirst($s['status']) ?></span>
                <small class="text-muted"><?= ucfirst($s['frequency']) ?></small>
            </div>
            <h5 class="mt-2"><?= htmlspecialchars($s['plan_name']) ?></h5>
            <p class="text-muted small"><?= htmlspecialchars($s['product_name'] ?? 'Custom') ?></p>
            <h4 class="text-primary"><?= formatPrice($s['price']) ?>/<small><?= $s['frequency']=='weekly'?'wk':($s['frequency']=='monthly'?'mo':'qtr') ?></small></h4>
            <?php if ($s['status']=='active'): ?>
            <a href="?cancel=<?= $s['id'] ?>" class="btn btn-sm btn-outline-danger mt-2" onclick="return confirm('Cancel subscription?')">Cancel</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
