<?php require_once __DIR__ . '/functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/svg+xml" href="<?= SITE_URL ?>/favicon.svg">
    <title><?= $pageTitle ?? 'Quick Mart' ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="<?= SITE_URL ?>/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= SITE_URL ?>/assets/css/all.min.css" rel="stylesheet">
    <link href="<?= SITE_URL ?>/assets/css/style.css" rel="stylesheet">
    <meta name="site-url" content="<?= SITE_URL ?>">
    <script src="<?= SITE_URL ?>/assets/js/lenis.min.js"></script>
</head>
<body>

<!-- Top Info Bar -->
<?php $sc = getSiteConfig(); ?>
<div class="navbar-top-bar">
    <div class="container">
        <div class="d-flex align-items-center gap-3">
            <?php if (!empty($sc['store_phone'])): ?>
            <span><i class="fas fa-phone-alt me-1"></i> <?= htmlspecialchars($sc['store_phone']) ?></span>
            <?php endif; ?>
            <span class="d-none d-md-inline"><i class="fas fa-truck me-1"></i> Free shipping on orders over ৳2000</span>
        </div>
        <div class="d-flex align-items-center gap-3">
            <?php if (!empty($sc['store_address'])): ?>
            <span class="d-none d-sm-inline"><i class="fas fa-map-marker-alt me-1"></i> <?= htmlspecialchars($sc['store_address']) ?></span>
            <?php endif; ?>
            <div class="top-socials d-none d-sm-flex">
                <a href="<?= htmlspecialchars($sc['social_facebook'] ?? '#') ?>" target="_blank" rel="noopener"><i class="fab fa-facebook-f"></i></a>
                <a href="<?= htmlspecialchars($sc['social_instagram'] ?? '#') ?>" target="_blank" rel="noopener"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </div>
</div>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary navbar-glass">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= SITE_URL ?>/store/">
            <i class="fas fa-bolt text-warning"></i> Quick Mart
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <button class="btn btn-sm d-lg-none position-absolute" style="top:16px;right:16px;color:#fff;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.15);border-radius:8px;padding:6px 12px;z-index:1100" onclick="document.getElementById('navbarNav').classList.remove('show')"><i class="fas fa-times"></i> Close</button>
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="<?= SITE_URL ?>/store/">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= SITE_URL ?>/store/products.php">Products</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Shop</a>
                    <ul class="dropdown-menu">
                        <?php foreach (getCategories() as $cat): ?>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/products.php?category=<?= $cat['slug'] ?>"><?= htmlspecialchars($cat['name']) ?></a></li>
                        <?php endforeach; ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/flash_sale.php"><i class="fas fa-bolt text-warning"></i> Flash Sales</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/bundles.php"><i class="fas fa-layer-group"></i> Bundles</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Tools</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/compare.php"><i class="fas fa-balance-scale"></i> Compare</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/size_guide.php"><i class="fas fa-ruler"></i> Size Guide</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/emi_calculator.php"><i class="fas fa-calculator"></i> EMI Calculator</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/store_locator.php"><i class="fas fa-map-marker-alt"></i> Store Locator</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/gift_wrap.php"><i class="fas fa-gift"></i> Gift Wrapping</a></li>
                    </ul>
                </li>
                <li class="nav-item"><a class="nav-link" href="<?= SITE_URL ?>/store/order_tracking.php"><i class="fas fa-truck"></i> Track Order</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= SITE_URL ?>/store/blog.php">Blog</a></li>
            </ul>
            <div class="position-relative me-3 d-none d-md-block">
                <input type="text" id="searchBox" class="form-control form-control-sm" placeholder="Search products..." autocomplete="off" style="width:220px">
                <div id="searchResults" class="position-absolute bg-white shadow rounded w-100" style="display:none;z-index:9999;max-height:300px;overflow-y:auto;top:100%"></div>
            </div>
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="<?= SITE_URL ?>/store/compare.php" title="Compare"><i class="fas fa-balance-scale"></i></a></li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= SITE_URL ?>/store/wishlist.php" title="Wishlist">
                        <i class="fas fa-heart"></i>
                        <?php if (getWishlistCount() > 0): ?><span class="badge bg-danger"><?= getWishlistCount() ?></span><?php endif; ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= SITE_URL ?>/store/cart.php" title="Cart">
                        <i class="fas fa-shopping-cart"></i>
                        <?php if (getCartCount() > 0): ?><span class="badge bg-danger"><?= getCartCount() ?></span><?php endif; ?>
                    </a>
                </li>
                <?php if (isLoggedIn()): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="fas fa-user"></i> <?= htmlspecialchars($_SESSION['username']) ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/profile.php"><i class="fas fa-id-card"></i> My Profile</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/orders.php"><i class="fas fa-box"></i> My Orders</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/order_tracking.php"><i class="fas fa-truck"></i> Track Order</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/wishlist.php"><i class="fas fa-heart"></i> Wishlist</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/compare.php"><i class="fas fa-balance-scale"></i> Compare</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/wallet.php"><i class="fas fa-wallet"></i> Wallet</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/loyalty.php"><i class="fas fa-star text-warning"></i> Loyalty Points</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/price_alerts.php"><i class="fas fa-bell"></i> Price Alerts</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/subscriptions.php"><i class="fas fa-sync-alt"></i> Subscriptions</a></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/chat.php"><i class="fas fa-comments"></i> Live Support</a></li>
                        <?php if (isAdmin()): ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/admin/"><i class="fas fa-cog"></i> Admin Panel</a></li>
                        <?php endif; ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= SITE_URL ?>/store/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </li>
                <?php else: ?>
                <li class="nav-item"><a class="nav-link" href="<?= SITE_URL ?>/store/login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<main class="main-content-area">
<div class="container py-3">
<?= getAlert() ?>
<script>
document.getElementById('searchBox')?.addEventListener('input', function() {
    var q = this.value.trim();
    var box = document.getElementById('searchResults');
    if (q.length < 2) { box.style.display = 'none'; return; }
    fetch('<?= SITE_URL ?>/api/search.php?q=' + encodeURIComponent(q))
        .then(r => r.json())
        .then(data => {
            if (data.length === 0) { box.style.display = 'none'; return; }
            box.innerHTML = data.map(p => '<a href="' + p.url + '" class="d-flex align-items-center p-2 text-dark text-decoration-none border-bottom"><div class="flex-grow-1"><div class="fw-bold small">' + p.name + '</div><div class="text-primary small">' + p.price + '</div></div></a>').join('');
            box.style.display = 'block';
        });
});
document.addEventListener('click', function(e) { if (!e.target.closest('#searchBox') && !e.target.closest('#searchResults')) document.getElementById('searchResults').style.display = 'none'; });
</script>
