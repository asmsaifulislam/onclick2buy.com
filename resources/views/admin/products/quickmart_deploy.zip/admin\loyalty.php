<?php
$pageTitle = 'Loyalty Points';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['adjust'])) {
    $userId = (int)$_GET['adjust'];
    $points = (int)($_GET['points'] ?? 0);
    $type = $_GET['type'] ?? 'earn';
    if ($userId && $points > 0) {
        $lp = fetch("SELECT * FROM loyalty_points WHERE user_id=?", [$userId]);
        if (!$lp) { query("INSERT INTO loyalty_points (user_id, points, total_earned, total_redeemed) VALUES (?,?,?,?)", [$userId, 0, 0, 0]); $lp = ['points'=>0, 'total_earned'=>0, 'total_redeemed'=>0]; }
        if ($type == 'earn') {
            query("UPDATE loyalty_points SET points=points+?, total_earned=total_earned+? WHERE user_id=?", [$points, $points, $userId]);
            query("INSERT INTO loyalty_transactions (user_id, points, tx_type, description) VALUES (?,?,'earned','Admin award')", [$userId, $points]);
        } else {
            $newBal = max(0, $lp['points'] - $points);
            query("UPDATE loyalty_points SET points=?, total_redeemed=total_redeemed+? WHERE user_id=?", [$newBal, $points, $userId]);
            query("INSERT INTO loyalty_transactions (user_id, points, tx_type, description) VALUES (?,?,'redeemed','Admin deduction')", [$userId, $points]);
        }
        setAlert('success', 'Points adjusted!');
    }
    redirect(SITE_URL . '/admin/loyalty.php');
}
$accounts = fetchAll("SELECT lp.*, u.username FROM loyalty_points lp LEFT JOIN users u ON lp.user_id=u.id ORDER BY lp.points DESC");
?>
<h4 class="mb-4">Loyalty Points Management</h4>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>User</th><th>Balance</th><th>Total Earned</th><th>Total Redeemed</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($accounts as $a): ?>
<tr><td><?= htmlspecialchars($a['username'] ?? 'N/A') ?></td><td><strong class="text-warning"><?= number_format($a['points']) ?></strong></td><td class="text-success"><?= number_format($a['total_earned']) ?></td><td class="text-danger"><?= number_format($a['total_redeemed']) ?></td>
<td>
<div class="input-group input-group-sm" style="width:200px">
<input type="number" id="pts_<?= $a['user_id'] ?>" class="form-control" placeholder="Points" min="1">
<button class="btn btn-success btn-sm" onclick="location.href='?adjust=<?= $a['user_id'] ?>&points='+document.getElementById('pts_<?= $a['user_id'] ?>').value+'&type=earn'" title="Award">+ Award</button>
<button class="btn btn-danger btn-sm" onclick="location.href='?adjust=<?= $a['user_id'] ?>&points='+document.getElementById('pts_<?= $a['user_id'] ?>').value+'&type=deduct'" title="Deduct">- Deduct</button>
</div>
</td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
