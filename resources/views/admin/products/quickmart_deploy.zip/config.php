<?php
ob_start();
session_start();

define('SITE_NAME', 'Quick Mart');
define('ADMIN_EMAIL', 'admin@quickmart.com');

// cPanel MySQL config (created by install.php)
$cpanelConfig = __DIR__ . '/cpanel_config.php';
$localConfig  = __DIR__ . '/local_config.php';

if (file_exists($cpanelConfig)) {
    require $cpanelConfig;
} elseif (file_exists($localConfig)) {
    require $localConfig;
} else {
    // Auto-detect: try cPanel MySQL env vars, fallback to SQLite
    $dbHost = getenv('DB_HOST') ?: '';
    $dbName = getenv('DB_NAME') ?: '';
    $dbUser = getenv('DB_USER') ?: '';
    $dbPass = getenv('DB_PASS') ?: '';

    if ($dbHost && $dbName && $dbUser) {
        define('DB_HOST', $dbHost);
        define('DB_NAME', $dbName);
        define('DB_USER', $dbUser);
        define('DB_PASS', $dbPass);
    } else {
        // Fallback: SQLite (for local testing)
        define('DB_PATH', __DIR__ . '/quickmart.db');
    }
}

// Auto-detect SITE_URL
if (!defined('SITE_URL')) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $path = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    // Remove /store, /admin, /api from path to get base URL
    $path = preg_replace('#/(store|admin|api)$#', '', $path);
    define('SITE_URL', $protocol . '://' . $host . $path);
}
