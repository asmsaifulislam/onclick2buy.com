<?php
$pageTitle = 'Staff Roles';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM staff_roles WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/staff.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [(int)$_POST['user_id'], $_POST['role'], (int)($_POST['can_manage_products'] ?? 0), (int)($_POST['can_manage_orders'] ?? 0), (int)($_POST['can_manage_payments'] ?? 0), (int)($_POST['can_manage_reports'] ?? 0), (int)($_POST['can_manage_settings'] ?? 0)];
    if ($id) { query("UPDATE staff_roles SET user_id=?, role=?, can_manage_products=?, can_manage_orders=?, can_manage_payments=?, can_manage_reports=?, can_manage_settings=? WHERE id=?", array_merge($data, [$id])); }
    else { query("INSERT INTO staff_roles (user_id, role, can_manage_products, can_manage_orders, can_manage_payments, can_manage_reports, can_manage_settings) VALUES (?,?,?,?,?,?,?)", $data); }
    setAlert('success', 'Staff role saved!'); redirect(SITE_URL . '/admin/staff.php');
}
$roles = fetchAll("SELECT r.*, u.username FROM staff_roles r LEFT JOIN users u ON r.user_id=u.id ORDER BY r.role");
$users = fetchAll("SELECT id, username FROM users ORDER BY username");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Staff Roles (<?= count($roles) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_user').value='';document.getElementById('f_role').value='';document.getElementById('f_perms_products').checked=false;document.getElementById('f_perms_orders').checked=false;document.getElementById('f_perms_payments').checked=false;document.getElementById('f_perms_reports').checked=false;document.getElementById('f_perms_settings').checked=false;document.getElementById('modalTitle').textContent='Add Staff Role';"><i class="fas fa-plus"></i> Add</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>User</th><th>Role</th><th>Permissions</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($roles as $r): ?>
<tr><td><strong><?= htmlspecialchars($r['username'] ?? 'N/A') ?></strong></td><td><?= htmlspecialchars($r['role']) ?></td><td><code><?php
$perms = [];
if ($r['can_manage_products']) $perms[] = 'Products';
if ($r['can_manage_orders']) $perms[] = 'Orders';
if ($r['can_manage_payments']) $perms[] = 'Payments';
if ($r['can_manage_reports']) $perms[] = 'Reports';
if ($r['can_manage_settings']) $perms[] = 'Settings';
echo htmlspecialchars(implode(', ', $perms) ?: 'None');
?></code></td>
<td><button class="btn btn-sm btn-warning" onclick="document.getElementById('f_id').value='<?= $r['id'] ?>';document.getElementById('f_user').value='<?= $r['user_id'] ?>';document.getElementById('f_role').value='<?= htmlspecialchars($r['role']) ?>';document.getElementById('f_perms_products').checked=<?= $r['can_manage_products']?'true':'false' ?>;document.getElementById('f_perms_orders').checked=<?= $r['can_manage_orders']?'true':'false' ?>;document.getElementById('f_perms_payments').checked=<?= $r['can_manage_payments']?'true':'false' ?>;document.getElementById('f_perms_reports').checked=<?= $r['can_manage_reports']?'true':'false' ?>;document.getElementById('f_perms_settings').checked=<?= $r['can_manage_settings']?'true':'false' ?>;document.getElementById('modalTitle').textContent='Edit Role';new bootstrap.Modal(document.getElementById('modal')).show();"><i class="fas fa-edit"></i></button> <a href="?delete=<?= $r['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Staff Role</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">User</label><select name="user_id" id="f_user" class="form-select" required><option value="">Select User</option><?php foreach ($users as $u): ?><option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['username']) ?></option><?php endforeach; ?></select></div>
<div class="mb-3"><label class="form-label">Role</label><input type="text" name="role" id="f_role" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Permissions</label>
<div class="form-check"><input class="form-check-input" type="checkbox" name="can_manage_products" value="1" id="f_perms_products"><label class="form-check-label">Manage Products</label></div>
<div class="form-check"><input class="form-check-input" type="checkbox" name="can_manage_orders" value="1" id="f_perms_orders"><label class="form-check-label">Manage Orders</label></div>
<div class="form-check"><input class="form-check-input" type="checkbox" name="can_manage_payments" value="1" id="f_perms_payments"><label class="form-check-label">Manage Payments</label></div>
<div class="form-check"><input class="form-check-input" type="checkbox" name="can_manage_reports" value="1" id="f_perms_reports"><label class="form-check-label">Manage Reports</label></div>
<div class="form-check"><input class="form-check-input" type="checkbox" name="can_manage_settings" value="1" id="f_perms_settings"><label class="form-check-label">Manage Settings</label></div>
</div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
