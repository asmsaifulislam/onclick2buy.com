<?php
$pageTitle = 'Inventory Management';
require_once __DIR__ . '/../includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['adjust_stock'])) {
    $productId = (int)$_POST['product_id'];
    $adjustment = (int)$_POST['adjustment'];
    $type = $_POST['movement_type'];
    $notes = trim($_POST['notes'] ?? '');
    if ($productId && $adjustment != 0) {
        $newStock = $type == 'in' ? (int)fetch("SELECT stock FROM products WHERE id=?", [$productId])['stock'] + $adjustment : max(0, (int)fetch("SELECT stock FROM products WHERE id=?", [$productId])['stock'] - abs($adjustment));
        query("UPDATE products SET stock=? WHERE id=?", [$newStock, $productId]);
        query("INSERT INTO stock_movements (product_id, movement_type, quantity, notes, created_by) VALUES (?,?,?,?,?)", [$productId, $type, abs($adjustment), $notes, $_SESSION['user_id']]);
        setAlert('success', "Stock adjusted for product #$productId!");
    }
    redirect(SITE_URL . '/admin/inventory.php');
}

$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? 'stock_asc';
$orderSql = match($sort) { 'stock_asc' => 'stock ASC', 'stock_desc' => 'stock DESC', 'name_asc' => 'name ASC', 'name_desc' => 'name DESC', default => 'stock ASC' };
$where = $search ? "WHERE p.name LIKE '%$search%'" : "";
$products = fetchAll("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id=c.id $where ORDER BY $orderSql");
$lowStockCount = count_rows("SELECT COUNT(*) FROM products WHERE stock <= 10 AND is_active=1");
$outOfStock = count_rows("SELECT COUNT(*) FROM products WHERE stock = 0 AND is_active=1");
$movements = fetchAll("SELECT sm.*, p.name as product_name, u.username FROM stock_movements sm LEFT JOIN products p ON sm.product_id=p.id LEFT JOIN users u ON sm.created_by=u.id ORDER BY sm.created_at DESC LIMIT 20");
?>
<div class="row g-4 mb-4">
    <div class="col-md-3"><div class="card card-custom p-3 text-center"><h3 class="text-primary"><?= count($products) ?></h3><p class="text-muted mb-0">Total Products</p></div></div>
    <div class="col-md-3"><div class="card card-custom p-3 text-center"><h3 class="text-warning"><?= $lowStockCount ?></h3><p class="text-muted mb-0">Low Stock (≤10)</p></div></div>
    <div class="col-md-3"><div class="card card-custom p-3 text-center"><h3 class="text-danger"><?= $outOfStock ?></h3><p class="text-muted mb-0">Out of Stock</p></div></div>
    <div class="col-md-3"><div class="card card-custom p-3 text-center"><h3 class="text-success"><?= count($movements) ?></h3><p class="text-muted mb-0">Recent Movements</p></div></div>
</div>

<div class="card card-custom mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Stock Management</h5>
        <form class="d-flex gap-2 flex-wrap" method="GET">
            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search products..." value="<?= htmlspecialchars($search) ?>">
            <select name="sort" class="form-select form-control-sm" style="width:150px">
                <option value="stock_asc" <?= $sort=='stock_asc'?'selected':'' ?>>Stock: Low to High</option>
                <option value="stock_desc" <?= $sort=='stock_desc'?'selected':'' ?>>Stock: High to Low</option>
                <option value="name_asc" <?= $sort=='name_asc'?'selected':'' ?>>Name: A-Z</option>
            </select>
            <button class="btn btn-sm btn-primary"><i class="fas fa-search"></i></button>
        </form>
    </div>
    <div class="card-body"><div class="table-responsive">
    <table class="table table-custom table-sm"><thead><tr><th>Product</th><th>Category</th><th>Stock</th><th>Threshold</th><th>Status</th><th>Adjust</th></tr></thead>
    <tbody><?php foreach ($products as $p):
        $status = $p['stock']==0 ? 'out' : ($p['stock'] <= 10 ? 'low' : 'ok');
    ?>
    <tr class="<?= $status=='out'?'table-danger':($status=='low'?'table-warning':'') ?>">
        <td><?= htmlspecialchars($p['name']) ?></td><td class="small"><?= htmlspecialchars($p['category_name'] ?? '-') ?></td>
        <td><strong><?= $p['stock'] ?></strong></td><td class="small">10</td>
        <td><span class="badge bg-<?= $status=='out'?'danger':($status=='low'?'warning':'success') ?>"><?= $status=='out'?'Out of Stock':($status=='low'?'Low Stock':'In Stock') ?></span></td>
        <td>
            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#adjustModal" onclick="document.getElementById('adj_prod').value='<?= $p['id'] ?>';document.getElementById('adj_prod_name').textContent='<?= htmlspecialchars($p['name']) ?>';"><i class="fas fa-edit"></i></button>
        </td>
    </tr><?php endforeach; ?></tbody></table></div></div>
</div>

<div class="card card-custom mb-4">
    <div class="card-header"><h5 class="mb-0">Recent Stock Movements</h5></div>
    <div class="card-body"><div class="table-responsive">
    <table class="table table-custom table-sm"><thead><tr><th>Date</th><th>Product</th><th>Type</th><th>Qty</th><th>Notes</th><th>By</th></tr></thead>
    <tbody><?php foreach ($movements as $m): ?>
    <tr><td class="small"><?= $m['created_at'] ?></td><td><?= htmlspecialchars($m['product_name'] ?? 'N/A') ?></td>
    <td><span class="badge bg-<?= $m['movement_type']=='in'?'success':($m['movement_type']=='out'?'danger':'info') ?>"><?= ucfirst($m['movement_type']) ?></span></td>
    <td><?= $m['quantity'] ?></td><td class="small"><?= htmlspecialchars($m['notes']) ?></td><td><?= htmlspecialchars($m['username'] ?? 'System') ?></td></tr>
    <?php endforeach; ?></tbody></table></div></div>
</div>

<div class="modal fade" id="adjustModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title">Adjust Stock - <span id="adj_prod_name"></span></h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="adjust_stock" value="1"><input type="hidden" name="product_id" id="adj_prod">
<div class="mb-3"><label class="form-label">Movement Type</label><select name="movement_type" class="form-select"><option value="in">Stock In (+)</option><option value="out">Stock Out (-)</option><option value="adjustment">Adjustment</option><option value="return">Return (+)</option></select></div>
<div class="mb-3"><label class="form-label">Quantity</label><input type="number" name="adjustment" class="form-control" min="1" required></div>
<div class="mb-3"><label class="form-label">Notes</label><input type="text" name="notes" class="form-control" placeholder="Reason for adjustment"></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Adjust</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
