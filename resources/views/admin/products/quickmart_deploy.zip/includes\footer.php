</main>
<!-- ═══════ FOOTER ═══════ -->
<footer class="footer-main">
    <div class="container position-relative" style="z-index:1;">
        <div class="row g-4">
            <!-- Brand & Description -->
            <div class="col-lg-4 col-md-6">
                <a href="<?= SITE_URL ?>/store/" class="footer-brand"><i class="fas fa-store"></i> Quick Mart</a>
                <p class="footer-desc">Your one-stop e-commerce destination. Shop thousands of products with fast delivery across Bangladesh. Quality guaranteed.</p>
                <div class="trust-badges mt-3">
                    <div class="trust-badge"><i class="fas fa-shield-alt"></i> Secure Payment</div>
                    <div class="trust-badge"><i class="fas fa-truck"></i> Fast Delivery</div>
                    <div class="trust-badge"><i class="fas fa-undo"></i> Easy Returns</div>
                </div>
                <div class="footer-social mt-3">
                    <?php $sc = getSiteConfig(); ?>
                    <a href="<?= htmlspecialchars($sc['social_facebook'] ?? '#') ?>" title="Facebook" target="_blank" rel="noopener"><i class="fab fa-facebook-f"></i></a>
                    <a href="<?= htmlspecialchars($sc['social_instagram'] ?? '#') ?>" title="Instagram" target="_blank" rel="noopener"><i class="fab fa-instagram"></i></a>
                    <a href="<?= htmlspecialchars($sc['social_youtube'] ?? '#') ?>" title="YouTube" target="_blank" rel="noopener"><i class="fab fa-youtube"></i></a>
                    <a href="<?= htmlspecialchars($sc['social_twitter'] ?? '#') ?>" title="Twitter" target="_blank" rel="noopener"><i class="fab fa-twitter"></i></a>
                    <a href="<?= htmlspecialchars($sc['social_whatsapp'] ?? '#') ?>" title="WhatsApp" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="col-lg-2 col-md-6">
                <h6 class="footer-heading">Quick Links</h6>
                <ul class="footer-links">
                    <li><a href="<?= SITE_URL ?>/store/"><i class="fas fa-chevron-right"></i> Home</a></li>
                    <li><a href="<?= SITE_URL ?>/store/products.php"><i class="fas fa-chevron-right"></i> All Products</a></li>
                    <li><a href="<?= SITE_URL ?>/store/wishlist.php"><i class="fas fa-chevron-right"></i> Wishlist</a></li>
                    <li><a href="<?= SITE_URL ?>/store/cart.php"><i class="fas fa-chevron-right"></i> Cart</a></li>
                    <li><a href="<?= SITE_URL ?>/store/orders.php"><i class="fas fa-chevron-right"></i> My Orders</a></li>
                    <li><a href="<?= SITE_URL ?>/store/blog.php"><i class="fas fa-chevron-right"></i> Blog</a></li>
                </ul>
            </div>

            <!-- Customer Service -->
            <div class="col-lg-3 col-md-6">
                <h6 class="footer-heading">Customer Service</h6>
                <ul class="footer-links">
                    <li><a href="<?= SITE_URL ?>/store/order_tracking.php"><i class="fas fa-chevron-right"></i> Track Order</a></li>
                    <li><a href="<?= SITE_URL ?>/store/refund.php"><i class="fas fa-chevron-right"></i> Return Policy</a></li>
                    <li><a href="<?= SITE_URL ?>/store/size_guide.php"><i class="fas fa-chevron-right"></i> Shipping Info</a></li>
                    <li><a href="#"><i class="fas fa-chevron-right"></i> Privacy Policy</a></li>
                    <li><a href="#"><i class="fas fa-chevron-right"></i> Terms & Conditions</a></li>
                </ul>
            </div>

            <!-- Contact & Newsletter -->
            <div class="col-lg-3 col-md-6">
                <h6 class="footer-heading">Contact Us</h6>
                <ul class="footer-links footer-contact">
                    <li><i class="fas fa-map-marker-alt"></i> <span>Dhanmondi, Dhaka 1205, Bangladesh</span></li>
                    <li><i class="fas fa-phone-alt"></i> <span>+880 1700-000000</span></li>
                    <li><i class="fas fa-envelope"></i> <span>support@quickmart.com</span></li>
                    <li><i class="fas fa-clock"></i> <span>Sun - Thu: 9AM - 9PM</span></li>
                </ul>
                <h6 class="footer-heading mt-3">Newsletter</h6>
                <div class="footer-newsletter">
                    <div class="input-group">
                        <input type="email" class="form-control" placeholder="Your email address">
                        <button class="btn btn-subscribe" type="button" onclick="alert('Subscribed!')">Subscribe</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Payment Methods -->
        <div class="footer-divider"></div>
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div>
                <span class="text-secondary small me-3">We Accept:</span>
                <div class="footer-payment d-inline-flex">
                    <span class="pay-icon"><i class="fas fa-money-bill-wave"></i> bKash</span>
                    <span class="pay-icon"><i class="fas fa-wallet"></i> Nagad</span>
                    <span class="pay-icon"><i class="fas fa-rocket"></i> Rocket</span>
                    <span class="pay-icon"><i class="fab fa-cc-visa"></i> Visa</span>
                    <span class="pay-icon"><i class="fab fa-cc-mastercard"></i> Mastercard</span>
                    <span class="pay-icon"><i class="fas fa-university"></i> Bank</span>
                    <span class="pay-icon"><i class="fas fa-money-bill"></i> COD</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Copyright -->
    <div class="footer-bottom mt-4">
        <div class="container d-flex flex-wrap justify-content-between align-items-center gap-2">
            <span>&copy; <?= date('Y') ?> Quick Mart. All rights reserved.</span>
            <span>Crafted with <i class="fas fa-heart text-danger"></i> for Bangladesh</span>
        </div>
    </div>
</footer>

<!-- Back to Top -->
<button class="back-to-top" id="backToTop"><i class="fas fa-arrow-up"></i></button>

<!-- Quick View Modal -->
<div class="qv-modal-backdrop" id="qvBackdrop"></div>
<div class="qv-modal" id="qvModal">
    <button class="qv-modal-close" id="qvClose"><i class="fas fa-times"></i></button>
    <div id="qvContent">
        <div class="qv-loading"><div class="spinner-border"></div><span>Loading...</span></div>
    </div>
</div>
<div class="qv-toast" id="qvToast"></div>

<!-- Slide-over Cart Panel -->
<div class="cart-panel-backdrop" id="cartBackdrop"></div>
<div class="cart-panel" id="cartPanel">
    <div class="cart-panel-header">
        <h5><i class="fas fa-shopping-bag"></i> Shopping Bag <span class="cart-count-badge" id="cartCountBadge">0</span></h5>
        <button class="cart-panel-close" id="cartPanelClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="cart-panel-items" id="cartPanelItems">
        <div class="cart-panel-empty" id="cartEmpty">
            <i class="fas fa-shopping-bag"></i>
            <p>Your bag is empty</p>
        </div>
    </div>
    <div class="cart-panel-footer" id="cartPanelFooter" style="display:none">
        <div class="cart-summary-row"><span>Subtotal</span><span id="cartSubtotal">৳0</span></div>
        <div class="cart-summary-row"><span>Shipping</span><span id="cartShipping">৳0</span></div>
        <div class="cart-summary-row total"><span>Total</span><span id="cartTotal">৳0</span></div>
        <a href="<?= SITE_URL ?>/store/checkout.php" class="btn-checkout"><i class="fas fa-lock"></i> Checkout</a>
        <a href="<?= SITE_URL ?>/store/cart.php" class="btn-view-cart">View Full Cart</a>
        <div class="cart-panel-free-ship" id="cartFreeShip"><i class="fas fa-truck"></i> Free shipping on orders over ৳2,000</div>
    </div>
</div>

<script>
// Back to Top
window.addEventListener('scroll', function() {
    var btn = document.getElementById('backToTop');
    if (btn) {
        if (window.scrollY > 300) { btn.classList.add('visible'); }
        else { btn.classList.remove('visible'); }
    }
    if (window.scrollY > 50) { document.body.classList.add('nav-scrolled'); }
    else { document.body.classList.remove('nav-scrolled'); }
});
document.getElementById('backToTop')?.addEventListener('click', function() { window.scrollTo({ top: 0, behavior: 'smooth' }); });

// Close mobile nav when clicking a link
document.querySelectorAll('#navbarNav .nav-link').forEach(function(link) {
    link.addEventListener('click', function(e) {
        if (!this.classList.contains('dropdown-toggle')) {
            var collapse = document.getElementById('navbarNav');
            if (collapse && collapse.classList.contains('show')) {
                var bsCollapse = bootstrap.Collapse.getInstance(collapse);
                if (bsCollapse) bsCollapse.hide();
            }
        }
    });
});

// Product Ad Strip — Pause on Hover
function pauseScroll(el) {
    var inner = el.querySelector('.product-ad-inner');
    if (inner) inner.style.animationPlayState = 'paused';
}
function resumeScroll(el) {
    var inner = el.querySelector('.product-ad-inner');
    if (inner) inner.style.animationPlayState = 'running';
}

// Lenis Smooth Scroll
const lenis = new Lenis({ duration: 1.2, easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)) });
function raf(time) { lenis.raf(time); requestAnimationFrame(raf); }
requestAnimationFrame(raf);

// Scroll Reveal
const revealElements = document.querySelectorAll('.reveal');
const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('revealed'); } });
}, { threshold: 0.1 });
revealElements.forEach(el => revealObserver.observe(el));

// Scroll Progress Bar
window.addEventListener('scroll', function() {
    var bar = document.querySelector('.scroll-progress');
    if (bar) { var winScroll = document.body.scrollTop || document.documentElement.scrollTop; var height = document.documentElement.scrollHeight - document.documentElement.clientHeight; bar.style.width = (winScroll / height * 100) + '%'; }
});

// Page Loading Overlay
var loadingHTML = '<div id="pageLoader" style="position:fixed;top:0;left:0;width:100%;height:100%;background:#0f0c29;z-index:99999;display:flex;align-items:center;justify-content:center;transition:opacity 0.4s;opacity:1"><div style="text-align:center"><div style="width:40px;height:40px;border:3px solid rgba(233,69,96,0.2);border-top-color:#e94560;border-radius:50%;animation:spin 0.8s linear infinite;margin:0 auto 12px"></div><p style="color:#e94560;font-size:.85rem;font-weight:600">Loading...</p></div></div><style>@keyframes spin{to{transform:rotate(360deg)}}</style>';
document.body.insertAdjacentHTML('beforeend', loadingHTML);
window.addEventListener('load', function() {
    var loader = document.getElementById('pageLoader');
    if (loader) { loader.style.opacity = '0'; setTimeout(function(){ loader.remove(); }, 400); }
});

// Form submit loading
document.querySelectorAll('form').forEach(function(form) {
    form.addEventListener('submit', function() {
        var btn = this.querySelector('button[type="submit"]');
        if (btn && !btn.classList.contains('no-loading')) {
            var orig = btn.innerHTML;
            btn.innerHTML = '<i class=\"fas fa-spinner fa-spin\"></i> Processing...';
            btn.disabled = true;
            setTimeout(function(){ btn.innerHTML = orig; btn.disabled = false; }, 5000);
        }
    });
});

// Toast notification
function showToast(msg, type) {
    type = type || 'success';
    var colors = {success:'#198754',danger:'#dc3545',warning:'#ffc107',info:'#0dcaf0'};
    var icons = {success:'check-circle',danger:'times-circle',warning:'exclamation-triangle',info:'info-circle'};
    var t = document.createElement('div');
    t.style.cssText = 'position:fixed;top:80px;right:20px;z-index:99999;padding:14px 20px;border-radius:10px;color:#fff;font-size:.9rem;font-weight:500;display:flex;align-items:center;gap:10px;box-shadow:0 8px 30px rgba(0,0,0,0.2);transform:translateX(120%);transition:transform 0.4s cubic-bezier(0.16,1,0.3,1);background:'+(colors[type]||colors.success);
    t.innerHTML = '<i class="fas fa-'+(icons[type]||icons.success)+'"></i> '+msg;
    document.body.appendChild(t);
    setTimeout(function(){ t.style.transform='translateX(0)'; },50);
    setTimeout(function(){ t.style.transform='translateX(120%)'; setTimeout(function(){ t.remove(); },400); },3000);
}

// ─── Quick View Modal ───
(function() {
    var backdrop = document.getElementById('qvBackdrop');
    var modal    = document.getElementById('qvModal');
    var content  = document.getElementById('qvContent');
    var closeBtn = document.getElementById('qvClose');
    var toast    = document.getElementById('qvToast');
    var API      = '<?= SITE_URL ?>/api/quickview.php';
    var SITE     = '<?= SITE_URL ?>';

    function openQV(id) {
        backdrop.classList.add('active');
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        content.innerHTML = '<div class="qv-loading"><div class="spinner-border"></div><span>Loading...</span></div>';
        fetch(API + '?id=' + id)
            .then(function(r){ return r.json(); })
            .then(function(d) {
                if (d.error) { content.innerHTML = '<div class="qv-loading" style="color:#dc3545"><i class="fas fa-exclamation-triangle" style="font-size:2rem"></i><span>' + d.error + '</span></div>'; return; }
                var sizeOpts = '', colorOpts = '';
                var sizes = [], colors = [];
                (d.variants || []).forEach(function(v) {
                    if (v.type === 'size' && v.value) sizes.push(v.value);
                    if (v.type === 'color' && v.value) colors.push(v.value);
                });
                if (sizes.length) {
                    sizeOpts = '<div class="qv-options"><label>Size</label><div class="qv-size-btns">';
                    sizes.forEach(function(s, i) {
                        sizeOpts += '<button class="qv-size-btn' + (i===0?' active':'') + '" data-val="' + s + '">' + s + '</button>';
                    });
                    sizeOpts += '</div></div>';
                }
                if (colors.length) {
                    colorOpts = '<div class="qv-options"><label>Color</label><div class="qv-color-btns">';
                    colors.forEach(function(c, i) {
                        colorOpts += '<button class="qv-color-btn' + (i===0?' active':'') + '" data-val="' + c + '" style="background:' + c + '" title="' + c + '"></button>';
                    });
                    colorOpts += '</div></div>';
                }
                var stockClass = d.stock > 10 ? 'in-stock' : (d.stock > 0 ? 'low-stock' : 'out-stock');
                var stockText  = d.stock > 10 ? 'In Stock' : (d.stock > 0 ? 'Only ' + d.stock + ' left' : 'Out of Stock');
                var stars = '';
                for (var i = 0; i < 5; i++) {
                    stars += '<i class="fas fa-star ' + (i < d.average_rating ? 'text-warning' : 'text-muted') + '" style="font-size:13px"></i>';
                }
                var desc = d.description ? '<div class="qv-desc">' + d.description.replace(/</g,'&lt;') + '</div>' : '';
                content.innerHTML =
                    '<div class="qv-body">' +
                        '<div class="qv-images"><img src="' + d.image + '" alt="' + d.name.replace(/"/g,'&quot;') + '"></div>' +
                        '<div class="qv-info">' +
                            (d.cat_name ? '<span class="qv-category">' + d.cat_name + '</span>' : '') +
                            '<h3>' + d.name + '</h3>' +
                            '<div class="qv-rating"><span class="stars">' + stars + '</span><small class="text-muted">(' + d.total_reviews + ' reviews)</small></div>' +
                            '<div class="qv-price">' + d.price_fmt + '</div>' +
                            '<div class="qv-stock ' + stockClass + '"><i class="fas fa-circle" style="font-size:6px"></i> ' + stockText + '</div>' +
                            desc +
                            sizeOpts + colorOpts +
                            '<div class="qv-qty-row"><label>Qty</label><div class="qv-qty-controls">' +
                                '<button type="button" class="qv-minus">−</button>' +
                                '<input type="number" value="1" min="1" max="' + d.stock + '" id="qvQty">' +
                                '<button type="button" class="qv-plus">+</button>' +
                            '</div></div>' +
                            '<div class="qv-actions">' +
                                '<button class="btn-add-cart" data-id="' + d.id + '" ' + (d.stock<=0?'disabled':'') + '><i class="fas fa-cart-plus"></i> Add to Cart</button>' +
                                '<a href="' + SITE + '/store/product.php?slug=' + d.slug + '" class="btn-view-full"><i class="fas fa-external-link-alt"></i> Full</a>' +
                            '</div>' +
                        '</div>' +
                    '</div>';
                bindQVEvents(d.id);
            })
            .catch(function() {
                content.innerHTML = '<div class="qv-loading" style="color:#dc3545"><i class="fas fa-wifi" style="font-size:2rem"></i><span>Connection error</span></div>';
            });
    }

    function closeQV() {
        backdrop.classList.remove('active');
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }

    function showQVToast(msg) {
        toast.textContent = msg;
        toast.classList.add('show');
        setTimeout(function(){ toast.classList.remove('show'); }, 2500);
    }

    function bindQVEvents(pid) {
        content.querySelectorAll('.qv-size-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                content.querySelectorAll('.qv-size-btn').forEach(function(b){ b.classList.remove('active'); });
                this.classList.add('active');
            });
        });
        content.querySelectorAll('.qv-color-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                content.querySelectorAll('.qv-color-btn').forEach(function(b){ b.classList.remove('active'); });
                this.classList.add('active');
            });
        });
        var qtyInput = document.getElementById('qvQty');
        content.querySelector('.qv-minus')?.addEventListener('click', function() {
            if (qtyInput && parseInt(qtyInput.value) > 1) qtyInput.value = parseInt(qtyInput.value) - 1;
        });
        content.querySelector('.qv-plus')?.addEventListener('click', function() {
            if (qtyInput && parseInt(qtyInput.value) < parseInt(qtyInput.max)) qtyInput.value = parseInt(qtyInput.value) + 1;
        });
        content.querySelector('.btn-add-cart')?.addEventListener('click', function() {
            var btn = this;
            var selectedSize = content.querySelector('.qv-size-btn.active')?.dataset.val || '';
            var selectedColor = content.querySelector('.qv-color-btn.active')?.dataset.val || '';
            var qty = parseInt(qtyInput?.value || 1);
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
            btn.disabled = true;
            fetch(SITE + '/api/cart.php?action=add', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
                body: 'product_id=' + pid + '&quantity=' + qty + '&size=' + encodeURIComponent(selectedSize) + '&color=' + encodeURIComponent(selectedColor)
            })
            .then(function(r){ return r.json(); })
            .then(function(d) {
                btn.innerHTML = '<i class="fas fa-check"></i> Added!';
                btn.style.background = 'linear-gradient(135deg,#28a745,#218838)';
                showQVToast('Added to cart!');
                if (d.cart_count !== undefined) {
                    var badge = document.querySelector('.nav-icons .badge');
                    if (badge) badge.textContent = d.cart_count;
                }
                if (window.reloadCartPanel) window.reloadCartPanel();
                setTimeout(function() {
                    btn.innerHTML = '<i class="fas fa-cart-plus"></i> Add to Cart';
                    btn.style.background = '';
                    btn.disabled = false;
                }, 1800);
            })
            .catch(function() {
                btn.innerHTML = '<i class="fas fa-cart-plus"></i> Add to Cart';
                btn.disabled = false;
                showToast('Failed to add', 'danger');
            });
        });
    }

    // Delegated click handlers
    document.addEventListener('click', function(e) {
        var qvBtn = e.target.closest('.overlay-btn-quickview');
        if (qvBtn) { e.preventDefault(); openQV(qvBtn.dataset.id); return; }
        if (e.target.closest('#qvBackdrop') || e.target.closest('#qvClose')) { closeQV(); }
    });
    document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closeQV(); });
})();

// ─── Slide-over Cart Panel ───
(function() {
    var backdrop  = document.getElementById('cartBackdrop');
    var panel     = document.getElementById('cartPanel');
    var itemsEl   = document.getElementById('cartPanelItems');
    var emptyEl   = document.getElementById('cartEmpty');
    var footerEl  = document.getElementById('cartPanelFooter');
    var countBadge= document.getElementById('cartCountBadge');
    var closeBtn  = document.getElementById('cartPanelClose');
    var subtotalEl= document.getElementById('cartSubtotal');
    var shippingEl= document.getElementById('cartShipping');
    var totalEl   = document.getElementById('cartTotal');
    var freeShipEl= document.getElementById('cartFreeShip');
    var SITE      = '<?= SITE_URL ?>';
    var API       = SITE + '/api/cart_panel.php';
    var CART_API  = SITE + '/api/cart.php';

    function openCart() {
        backdrop.classList.add('active');
        panel.classList.add('active');
        document.body.style.overflow = 'hidden';
        loadCart();
    }
    function closeCart() {
        backdrop.classList.remove('active');
        panel.classList.remove('active');
        document.body.style.overflow = '';
    }

    function fmt(n) { return '৳' + Number(n).toLocaleString(); }

    function loadCart() {
        fetch(API)
        .then(function(r){ return r.json(); })
        .then(function(d) {
            if (!d.success || !d.items.length) {
                itemsEl.innerHTML = '<div class="cart-panel-empty"><i class="fas fa-shopping-bag"></i><p>Your bag is empty</p></div>';
                footerEl.style.display = 'none';
                countBadge.textContent = '0';
                updateNavBadge(0);
                return;
            }
            countBadge.textContent = d.count;
            updateNavBadge(d.count);
            var html = '';
            d.items.forEach(function(item) {
                html += '<div class="cart-item" data-id="' + item.id + '">' +
                    '<div class="cart-item-img"><img src="' + item.image_url + '" alt="' + esc(item.name) + '"></div>' +
                    '<div class="cart-item-info">' +
                        '<div class="cart-item-name">' + esc(item.name) + '</div>' +
                        '<div class="cart-item-price">' + fmt(item.price) + '</div>' +
                        '<div class="cart-item-controls">' +
                            '<button class="ci-minus" data-id="' + item.id + '" data-qty="' + item.quantity + '">−</button>' +
                            '<span>' + item.quantity + '</span>' +
                            '<button class="ci-plus" data-id="' + item.id + '" data-qty="' + item.quantity + '" data-stock="' + item.stock + '">+</button>' +
                        '</div>' +
                    '</div>' +
                    '<button class="cart-item-remove" data-id="' + item.id + '"><i class="fas fa-trash-alt"></i></button>' +
                '</div>';
            });
            itemsEl.innerHTML = html;
            footerEl.style.display = 'block';
            subtotalEl.textContent = fmt(d.subtotal);
            shippingEl.textContent = d.shipping === 0 ? 'FREE' : fmt(d.shipping);
            totalEl.textContent = fmt(d.total);
            freeShipEl.innerHTML = d.shipping === 0
                ? '<i class="fas fa-check-circle"></i> You qualify for free shipping!'
                : '<i class="fas fa-truck"></i> Add ' + fmt(2000 - d.subtotal) + ' more for free shipping';
        })
        .catch(function() {
            itemsEl.innerHTML = '<div class="cart-panel-empty"><i class="fas fa-wifi"></i><p>Failed to load cart</p></div>';
        });
    }

    function updateNavBadge(count) {
        document.querySelectorAll('.nav-icons .badge').forEach(function(b) {
            if (b.closest('a[href*="cart"]')) b.textContent = count;
        });
    }

    function esc(s) {
        var d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
    }

    function apiPost(action, itemId, qty) {
        var body = 'action=' + action + '&item_id=' + itemId;
        if (qty !== undefined) body += '&quantity=' + qty;
        return fetch(CART_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
            body: body
        }).then(function(r){ return r.json(); });
    }

    // Delegated events
    itemsEl.addEventListener('click', function(e) {
        var minusBtn = e.target.closest('.ci-minus');
        var plusBtn  = e.target.closest('.ci-plus');
        var removeBtn= e.target.closest('.cart-item-remove');
        if (minusBtn) {
            var q = parseInt(minusBtn.dataset.qty);
            if (q > 1) {
                minusBtn.disabled = true;
                apiPost('update', minusBtn.dataset.id, q - 1).then(function() { loadCart(); });
            }
        } else if (plusBtn) {
            var q2 = parseInt(plusBtn.dataset.qty);
            var stock = parseInt(plusBtn.dataset.stock);
            if (q2 < stock) {
                plusBtn.disabled = true;
                apiPost('update', plusBtn.dataset.id, q2 + 1).then(function() { loadCart(); });
            }
        } else if (removeBtn) {
            var itemEl = removeBtn.closest('.cart-item');
            itemEl.style.transition = 'all 0.3s';
            itemEl.style.opacity = '0';
            itemEl.style.transform = 'translateX(50px)';
            apiPost('remove', removeBtn.dataset.id).then(function() { loadCart(); });
        }
    });

    // Open from cart icon
    document.addEventListener('click', function(e) {
        var cartLink = e.target.closest('a[href*="cart.php"]');
        if (cartLink && cartLink.closest('.nav-icons')) {
            e.preventDefault();
            openCart();
        }
    });

    closeBtn.addEventListener('click', closeCart);
    backdrop.addEventListener('click', closeCart);
    document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closeCart(); });

    // Expose for other scripts (e.g. quick view add-to-cart)
    window.reloadCartPanel = function() { loadCart(); };
    window.openCartPanel = openCart;
})();

// Image error fallback
document.querySelectorAll('img').forEach(function(img) {
    img.addEventListener('error', function() {
        this.onerror = null;
        this.src = '<?= SITE_URL ?>/assets/images/no-image.svg';
    });
});

// Hero countdown timer
(function() {
    var target = new Date();
    target.setDate(target.getDate() + 11);
    target.setHours(23, 59, 59, 0);
    function updateCD() {
        var now = new Date();
        var diff = target - now;
        if (diff <= 0) return;
        var d = Math.floor(diff / 86400000);
        var h = Math.floor((diff % 86400000) / 3600000);
        var m = Math.floor((diff % 3600000) / 60000);
        var s = Math.floor((diff % 60000) / 1000);
        var el;
        el = document.getElementById('cd-days'); if (el) el.textContent = String(d).padStart(2, '0');
        el = document.getElementById('cd-hours'); if (el) el.textContent = String(h).padStart(2, '0');
        el = document.getElementById('cd-mins'); if (el) el.textContent = String(m).padStart(2, '0');
        el = document.getElementById('cd-secs'); if (el) el.textContent = String(s).padStart(2, '0');
    }
    updateCD();
    setInterval(updateCD, 1000);
})();
</script>
<script src="<?= SITE_URL ?>/assets/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
