<?php
$pageTitle = 'Invoice - Quick Mart';
require_once __DIR__ . '/../includes/functions.php';

$orderId = (int)($_GET['id'] ?? 0);
$orderNumber = trim($_GET['order'] ?? '');

if ($orderId) {
    if (isLoggedIn() && isAdmin()) {
        $order = fetch("SELECT * FROM orders WHERE id=?", [$orderId]);
    } elseif (isLoggedIn()) {
        $order = fetch("SELECT * FROM orders WHERE id=? AND user_id=?", [$orderId, $_SESSION['user_id']]);
    } else {
        $order = fetch("SELECT * FROM orders WHERE id=?", [$orderId]);
    }
} elseif ($orderNumber) {
    $order = fetch("SELECT * FROM orders WHERE order_number=?", [$orderNumber]);
} else {
    $order = null;
}

if (!$order) { setAlert('danger', 'Order not found.'); redirect(SITE_URL . '/store/orders.php'); }

$items = fetchAll("SELECT * FROM order_items WHERE order_id=?", [$order['id']]);
$payment = fetch("SELECT * FROM payments WHERE order_id=? ORDER BY created_at DESC LIMIT 1", [$order['id']]);
$gw = null;
try { $gw = fetch("SELECT gw.name, gw.price as gw_price, ogw.message FROM order_gift_wraps ogw JOIN gift_wraps gw ON ogw.gift_wrap_id=gw.id WHERE ogw.order_id=?", [$order['id']]); } catch(Exception $e) {}
$profile = null;
try { $profile = fetch("SELECT * FROM profiles WHERE user_id=?", [$order['user_id']]); } catch(Exception $e) {}

$subtotal = array_sum(array_map(fn($i) => $i['price'] * $i['quantity'], $items));
$discount = (float)($order['discount'] ?? 0);
$shipping = (float)($order['shipping_cost'] ?? 0);
$total = (float)($order['total'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #<?= $order['order_number'] ?> - Quick Mart</title>
    <link href="<?= SITE_URL ?>/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= SITE_URL ?>/assets/css/all.min.css" rel="stylesheet">
    <style>
    @media print {
        .no-print { display: none !important; }
        body { background: #fff !important; }
        .invoice-box { box-shadow: none !important; border: none !important; max-width: 100% !important; padding: 0 !important; }
        .invoice-header { border-bottom: 3px solid #e94560 !important; }
    }
    body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
    .invoice-box { max-width: 850px; margin: 20px auto; background: #fff; border-radius: 16px; box-shadow: 0 8px 32px rgba(0,0,0,0.08); overflow: hidden; }
    .invoice-header { background: linear-gradient(135deg, #0f0c29, #302b63, #24243e); color: #fff; padding: 30px 40px; }
    .invoice-header h1 { font-size: 1.8rem; font-weight: 800; margin: 0; }
    .invoice-header .invoice-badge { background: #e94560; color: #fff; padding: 6px 16px; border-radius: 8px; font-size: .85rem; font-weight: 600; }
    .invoice-body { padding: 30px 40px; }
    .info-card { background: #f8f9fa; border-radius: 10px; padding: 16px 20px; border-left: 4px solid #e94560; }
    .info-card h6 { color: #e94560; font-weight: 700; margin-bottom: 8px; font-size: .75rem; text-transform: uppercase; letter-spacing: 1px; }
    .info-card p { margin: 2px 0; font-size: .88rem; color: #333; }
    .item-row { padding: 12px 0; border-bottom: 1px solid #eee; display: flex; align-items: center; }
    .item-row:last-child { border: none; }
    .item-num { width: 30px; height: 30px; border-radius: 50%; background: #e94560; color: #fff; display: flex; align-items: center; justify-content: center; font-size: .75rem; font-weight: 700; margin-right: 12px; flex-shrink: 0; }
    .item-name { flex: 1; font-weight: 600; font-size: .9rem; }
    .item-price { width: 90px; text-align: right; font-size: .88rem; }
    .item-qty { width: 50px; text-align: center; font-size: .88rem; color: #666; }
    .item-total { width: 100px; text-align: right; font-weight: 700; font-size: .9rem; }
    .summary-row { display: flex; justify-content: space-between; padding: 8px 0; font-size: .9rem; }
    .summary-row.total { border-top: 2px solid #e94560; padding-top: 12px; margin-top: 4px; }
    .summary-row.total .val { font-size: 1.3rem; color: #e94560; font-weight: 800; }
    .badge-method { padding: 4px 12px; border-radius: 6px; font-size: .75rem; font-weight: 600; text-transform: uppercase; color: #fff; }
    .badge-status { padding: 4px 12px; border-radius: 6px; font-size: .75rem; font-weight: 600; }
    .footer-note { background: #f8f9fa; padding: 20px 40px; text-align: center; border-top: 1px solid #eee; font-size: .8rem; color: #888; }
    .qr-placeholder { width: 80px; height: 80px; border-radius: 8px; overflow: hidden; }
    .qr-placeholder img { width: 100%; height: 100%; object-fit: contain; }
    </style>
    <script src="<?= SITE_URL ?>/assets/js/html2pdf.bundle.min.js"></script>
</head>
<body>
<div class="invoice-box">
    <div class="invoice-header">
        <div class="d-flex justify-content-between align-items-start">
            <div>
                <h1><i class="fas fa-bolt"></i> Quick Mart</h1>
                <p class="mb-0 mt-1" style="opacity:.8;font-size:.85rem">Dhaka, Bangladesh</p>
                <p class="mb-0" style="opacity:.6;font-size:.8rem">info@quickmart.com | +880 1700-000000</p>
            </div>
            <div class="text-end">
                <div class="invoice-badge mb-2">INVOICE</div>
                <h4 class="mb-1" style="font-weight:800">#<?= $order['order_number'] ?></h4>
                <p class="mb-0" style="opacity:.7;font-size:.85rem"><?= date('l, F d, Y', strtotime($order['created_at'])) ?></p>
                <p class="mb-0 mt-1"><span class="badge-status bg-<?= $order['status']=='delivered'?'success':($order['status']=='cancelled'?'danger':'warning') ?>"><?= ucfirst($order['status']) ?></span></p>
            </div>
        </div>
    </div>

    <div class="invoice-body">
        <div class="row g-3 mb-4">
            <div class="col-md-5">
                <div class="info-card h-100">
                    <h6><i class="fas fa-user"></i> Bill To</h6>
                    <p class="fw-bold mb-1"><?= htmlspecialchars($order['shipping_name'] ?? 'Customer') ?></p>
                    <p class="mb-1"><?= htmlspecialchars($order['shipping_address'] ?? '') ?></p>
                    <p class="mb-1"><?= htmlspecialchars(($order['shipping_city'] ?? '') . ' ' . ($order['shipping_area'] ?? '')) ?></p>
                    <p class="mb-0"><i class="fas fa-phone text-muted"></i> <?= htmlspecialchars($order['shipping_phone'] ?? '') ?></p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-card h-100">
                    <h6><i class="fas fa-credit-card"></i> Payment Info</h6>
                    <p class="mb-1">Method: <span class="badge-method" style="background:<?= $order['payment_method']=='bkash'?'#e91e63':($order['payment_method']=='nagad'?'#ff5722':($order['payment_method']=='cod'?'#4caf50':'#1a237e')) ?>"><?= strtoupper($order['payment_method'] ?? 'N/A') ?></span></p>
                    <p class="mb-1">Status: <span class="badge-status bg-<?= ($order['payment_status']=='paid')?'success':(($order['payment_status']=='failed')?'danger':'warning') ?>"><?= ucfirst($order['payment_status'] ?? 'pending') ?></span></p>
                    <?php if ($payment && $payment['transaction_id']): ?>
                    <p class="mb-1"><small class="text-muted">TXN:</small> <?= htmlspecialchars($payment['transaction_id']) ?></p>
                    <?php endif; ?>
                    <?php if ($payment && $payment['card_last_four']): ?>
                    <p class="mb-0"><small class="text-muted">Card:</small> ****<?= htmlspecialchars($payment['card_last_four']) ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="info-card h-100 d-flex flex-column justify-content-center align-items-center">
                    <div class="qr-placeholder">
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=<?= urlencode(SITE_URL . '/store/invoice.php?order=' . $order['order_number']) ?>&bgcolor=ffffff&color=1a1a2e" alt="QR Code">
                    </div>
                    <small class="text-muted mt-2">Scan to verify</small>
                </div>
            </div>
        </div>

        <h6 class="mb-3" style="color:#e94560;font-weight:700"><i class="fas fa-box-open"></i> Order Items</h6>
        <?php foreach ($items as $i => $item): ?>
        <div class="item-row">
            <div class="item-num"><?= $i+1 ?></div>
            <div class="item-name"><?= htmlspecialchars($item['product_name'] ?? 'Product') ?></div>
            <div class="item-price"><?= formatPrice($item['price']) ?></div>
            <div class="item-qty">x<?= $item['quantity'] ?></div>
            <div class="item-total"><?= formatPrice($item['price'] * $item['quantity']) ?></div>
        </div>
        <?php endforeach; ?>

        <div class="row mt-4">
            <div class="col-md-6">
                <?php if ($order['notes']): ?>
                <div class="p-3 rounded" style="background:#fff3cd">
                    <small class="text-muted"><i class="fas fa-sticky-note"></i> <strong>Notes:</strong> <?= htmlspecialchars($order['notes']) ?></small>
                </div>
                <?php endif; ?>
                <?php if ($gw): ?>
                <div class="p-3 rounded mt-2" style="background:#d4edda">
                    <small><i class="fas fa-gift text-success"></i> <strong>Gift Wrap:</strong> <?= htmlspecialchars($gw['name']) ?></small>
                    <?php if ($gw['message']): ?><br><small class="text-muted">"<?= htmlspecialchars($gw['message']) ?>"</small><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <div class="summary-row"><span class="text-muted">Subtotal (<?= count($items) ?> items)</span><span><?= formatPrice($subtotal) ?></span></div>
                <div class="summary-row"><span class="text-muted">Shipping</span><span><?= $shipping > 0 ? formatPrice($shipping) : '<span class="text-success">Free</span>' ?></span></div>
                <?php if ($discount > 0): ?>
                <div class="summary-row text-success"><span>Discount</span><span>-<?= formatPrice($discount) ?></span></div>
                <?php endif; ?>
                <?php if ($gw && $gw['gw_price'] > 0): ?>
                <div class="summary-row"><span class="text-muted">Gift Wrap</span><span><?= formatPrice($gw['gw_price']) ?></span></div>
                <?php endif; ?>
                <div class="summary-row total"><span class="fw-bold">Total</span><span class="val"><?= formatPrice($total) ?></span></div>
            </div>
        </div>
    </div>

    <div class="footer-note">
        <p class="mb-1"><i class="fas fa-shield-alt text-success"></i> This is a computer-generated invoice. No signature required.</p>
        <p class="mb-0">Thank you for shopping with <strong>Quick Mart</strong>! | <a href="<?= SITE_URL ?>/store/" style="color:#e94560">www.quickmart.com</a></p>
    </div>

    <div class="text-center p-4 no-print">
        <button onclick="window.print()" class="btn btn-primary me-2"><i class="fas fa-print"></i> Print Invoice</button>
        <a href="<?= SITE_URL ?>/store/orders.php" class="btn btn-outline-secondary me-2"><i class="fas fa-arrow-left"></i> My Orders</a>
        <button onclick="downloadPDF()" class="btn btn-outline-danger"><i class="fas fa-file-pdf"></i> Download PDF</button>
    </div>
</div>

<script>
function downloadPDF() {
    var element = document.querySelector('.invoice-box');
    var opt = {
        margin:       0.5,
        filename:     'Invoice_<?= $order['order_number'] ?>.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };
    var btn = event.target.closest('button');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
    btn.disabled = true;
    html2pdf().set(opt).from(element).save().then(function() {
        btn.innerHTML = '<i class="fas fa-file-pdf"></i> Download PDF';
        btn.disabled = false;
    });
}
</script>
</body></html>
