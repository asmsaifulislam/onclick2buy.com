<?php
$pageTitle = 'Sales Overview';
require_once __DIR__ . '/../includes/admin_header.php';

$period = $_GET['period'] ?? '30';
$days = (int)$period;
$startDate = date('Y-m-d', strtotime("-$days days"));
$prevStartDate = date('Y-m-d', strtotime("-{$days} days -{$days} days"));
$prevEndDate = date('Y-m-d', strtotime("-{$days} days"));

$totalRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND created_at >= ?", [$startDate]);
$prevRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND created_at >= ? AND created_at < ?", [$prevStartDate, $prevEndDate]);
$revenueChange = $prevRevenue > 0 ? round(($totalRevenue - $prevRevenue) / $prevRevenue * 100, 1) : 0;

$totalOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status != 'cancelled' AND created_at >= ?", [$startDate]);
$prevOrders = count_rows("SELECT COUNT(*) FROM orders WHERE status != 'cancelled' AND created_at >= ? AND created_at < ?", [$prevStartDate, $prevEndDate]);
$orderChange = $prevOrders > 0 ? round(($totalOrders - $prevOrders) / $prevOrders * 100, 1) : 0;

$avgOrder = $totalOrders > 0 ? $totalRevenue / $totalOrders : 0;
$pendingPayment = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE payment_status='pending' AND created_at >= ?", [$startDate]);
$totalRefunds = count_rows("SELECT COALESCE(SUM(amount),0) FROM refund_requests WHERE status='approved' AND created_at >= ?", [$startDate]);
$refundRate = $totalRevenue > 0 ? round($totalRefunds / $totalRevenue * 100, 1) : 0;
$repeatBuyers = count_rows("SELECT COUNT(DISTINCT user_id) FROM orders WHERE user_id IS NOT NULL AND status != 'cancelled' AND created_at >= ? GROUP BY user_id HAVING COUNT(*) > 1", [$startDate]);
$totalCustomers = count_rows("SELECT COUNT(DISTINCT user_id) FROM orders WHERE user_id IS NOT NULL AND status != 'cancelled' AND created_at >= ?", [$startDate]);
$repeatRate = $totalCustomers > 0 ? round($repeatBuyers / $totalCustomers * 100) : 0;

$couponRevenue = count_rows("SELECT COALESCE(SUM(o.total),0) FROM orders o WHERE o.status != 'cancelled' AND o.discount > 0 AND o.created_at >= ?", [$startDate]);
$nonCouponRevenue = $totalRevenue - $couponRevenue;

$targetAmount = count_rows("SELECT COALESCE(target_amount,0) FROM revenue_targets WHERE month=? AND year=?", [(int)date('m'), (int)date('Y')]);
$targetProgress = $targetAmount > 0 ? round($totalRevenue / $targetAmount * 100, 1) : 0;

$geoSales = fetchAll("SELECT shipping_city, COUNT(*) as orders, SUM(total) as revenue FROM orders WHERE status != 'cancelled' AND shipping_city IS NOT NULL AND shipping_city != '' AND created_at >= ? GROUP BY shipping_city ORDER BY revenue DESC LIMIT 8", [$startDate]);

$orderStatus = fetchAll("SELECT status, COUNT(*) as cnt FROM orders WHERE created_at >= ? GROUP BY status", [$startDate]);
$statusLabels = array_column($orderStatus, 'status');
$statusCounts = array_column($orderStatus, 'cnt');

$topProducts = fetchAll("SELECT p.name, SUM(oi.quantity) as units, SUM(oi.price * oi.quantity) as revenue FROM order_items oi JOIN products p ON oi.product_id=p.id JOIN orders o ON oi.order_id=o.id WHERE o.status != 'cancelled' AND o.created_at >= ? GROUP BY p.id ORDER BY revenue DESC LIMIT 10", [$startDate]);
$dailySales = fetchAll("SELECT DATE(created_at) as date, COUNT(*) as orders, SUM(total) as revenue FROM orders WHERE status != 'cancelled' AND created_at >= ? GROUP BY DATE(created_at) ORDER BY date ASC", [$startDate]);
$paymentBreakdown = fetchAll("SELECT payment_method, COUNT(*) as count, SUM(total) as total FROM orders WHERE status != 'cancelled' AND created_at >= ? GROUP BY payment_method ORDER BY total DESC", [$startDate]);
$topCategories = fetchAll("SELECT c.name, SUM(oi.price * oi.quantity) as revenue FROM order_items oi JOIN products p ON oi.product_id=p.id JOIN categories c ON p.category_id=c.id JOIN orders o ON oi.order_id=o.id WHERE o.status != 'cancelled' AND o.created_at >= ? GROUP BY c.id ORDER BY revenue DESC LIMIT 5", [$startDate]);

$hourlySales = fetchAll("SELECT " . sqlHour('created_at') . " as hour, COUNT(*) as cnt, SUM(total) as revenue FROM orders WHERE status != 'cancelled' AND created_at >= ? GROUP BY hour ORDER BY hour", [$startDate]);
$hourlyMap = array_fill(0, 24, 0);
foreach ($hourlySales as $h) $hourlyMap[(int)$h['hour']] = (int)$h['cnt'];
$maxHourly = max($hourlyMap) > 0 ? max($hourlyMap) : 1;

$dayOfWeek = fetchAll("SELECT " . sqlDayOfWeek('created_at') . " as day, COUNT(*) as cnt, SUM(total) as revenue FROM orders WHERE status != 'cancelled' AND created_at >= ? GROUP BY day ORDER BY day", [$startDate]);
$dayMap = array_fill(0, 7, 0);
$dayRevMap = array_fill(0, 7, 0);
foreach ($dayOfWeek as $d) { $dayMap[(int)$d['day']] = (int)$d['cnt']; $dayRevMap[(int)$d['day']] = (int)$d['revenue']; }
$dayNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

$revenueJson = json_encode(array_map(fn($d) => ['date' => $d['date'], 'revenue' => (int)$d['revenue']], $dailySales));
$paymentLabels = json_encode(array_map(fn($p) => strtoupper($p['payment_method'] ?? 'N/A'), $paymentBreakdown));
$paymentTotals = json_encode(array_column($paymentBreakdown, 'total'));
$catLabels = json_encode(array_column($topCategories, 'name'));
$catRevenues = json_encode(array_column($topCategories, 'revenue'));
$productNames = json_encode(array_map(fn($p) => (strlen($p['name'])>20 ? substr($p['name'],0,20).'...' : $p['name']), $topProducts));
$productRevenues = json_encode(array_column($topProducts, 'revenue'));
$statusLabelsJson = json_encode($statusLabels);
$statusCountsJson = json_encode($statusCounts);
$dayNamesJson = json_encode($dayNames);
$dayRevJson = json_encode($dayRevMap);
$hourlyJson = json_encode($hourlyMap);
$geoLabels = json_encode(array_column($geoSales, 'shipping_city'));
$geoRevenues = json_encode(array_column($geoSales, 'revenue'));
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0"><i class="fas fa-chart-line text-primary"></i> Sales Overview</h4>
    <div class="d-flex gap-2">
        <a href="?period=7" class="btn btn-sm <?= $period=='7'?'btn-primary':'btn-outline-primary' ?>">7 Days</a>
        <a href="?period=30" class="btn btn-sm <?= $period=='30'?'btn-primary':'btn-outline-primary' ?>">30 Days</a>
        <a href="?period=90" class="btn btn-sm <?= $period=='90'?'btn-primary':'btn-outline-primary' ?>">90 Days</a>
        <a href="?period=365" class="btn btn-sm <?= $period=='365'?'btn-primary':'btn-outline-primary' ?>">1 Year</a>
        <button onclick="exportCSV()" class="btn btn-sm btn-outline-success"><i class="fas fa-file-csv"></i> Export CSV</button>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-xl-2 col-md-4 col-6">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div><p>Revenue</p><h5><?= formatPrice($totalRevenue) ?></h5><small class="<?= $revenueChange>=0?'text-success':'text-danger' ?>"><i class="fas fa-arrow-<?= $revenueChange>=0?'up':'down' ?>"></i> <?= abs($revenueChange) ?>%</small></div>
                <div class="icon bg-success-light"><i class="fas fa-dollar-sign"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-md-4 col-6">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div><p>Orders</p><h5><?= $totalOrders ?></h5><small class="<?= $orderChange>=0?'text-success':'text-danger' ?>"><i class="fas fa-arrow-<?= $orderChange>=0?'up':'down' ?>"></i> <?= abs($orderChange) ?>%</small></div>
                <div class="icon bg-primary-light"><i class="fas fa-shopping-cart"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-md-4 col-6">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div><p>Avg Order</p><h5><?= formatPrice($avgOrder) ?></h5></div>
                <div class="icon bg-info-light"><i class="fas fa-receipt"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-md-4 col-6">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div><p>Pending</p><h5 class="text-warning"><?= formatPrice($pendingPayment) ?></h5></div>
                <div class="icon bg-warning-light"><i class="fas fa-clock"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-md-4 col-6">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div><p>Refunds</p><h5 class="text-danger"><?= formatPrice($totalRefunds) ?></h5><small><?= $refundRate ?>% rate</small></div>
                <div class="icon bg-danger-light"><i class="fas fa-undo"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-md-4 col-6">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div><p>Repeat Rate</p><h5 class="text-purple"><?= $repeatRate ?>%</h5><small><?= $repeatBuyers ?>/<?= $totalCustomers ?></small></div>
                <div class="icon bg-purple-light"><i class="fas fa-redo"></i></div>
            </div>
        </div>
    </div>
</div>

<?php if ($targetAmount > 0): ?>
<div class="card card-custom mb-4 p-3">
    <div class="d-flex justify-content-between align-items-center mb-2">
        <span class="fw-bold"><i class="fas fa-bullseye text-primary"></i> Sales Target: <?= formatPrice($targetAmount) ?></span>
        <span class="fw-bold <?= $targetProgress>=100?'text-success':($targetProgress>=50?'text-primary':'text-warning') ?>"><?= $targetProgress ?>%</span>
    </div>
    <div class="progress" style="height:18px;border-radius:9px;">
        <div class="progress-bar <?= $targetProgress>=100?'bg-success':($targetProgress>=50?'bg-primary':'bg-warning') ?>" style="width:<?= min($targetProgress, 100) ?>%"><?= formatPrice($totalRevenue) ?> / <?= formatPrice($targetAmount) ?></div>
    </div>
</div>
<?php endif; ?>

<div class="row g-3 mb-4">
    <div class="col-xl-8">
        <div class="card card-custom">
            <div class="card-header"><h6>Revenue Trend</h6></div>
            <div class="card-body"><canvas id="revenueChart" height="80"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Order Status</h6></div>
            <div class="card-body d-flex justify-content-center"><canvas id="statusChart" height="180"></canvas></div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Payment Methods</h6></div>
            <div class="card-body d-flex justify-content-center"><canvas id="paymentChart" height="180"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Sales by Day</h6></div>
            <div class="card-body"><canvas id="dayChart" height="160"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card card-custom">
            <div class="card-header"><h6>Coupon Impact</h6></div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <canvas id="couponChart" height="120"></canvas>
                </div>
                <div class="d-flex justify-content-between"><span>With Coupon</span><span class="fw-bold text-success"><?= formatPrice($couponRevenue) ?></span></div>
                <div class="d-flex justify-content-between"><span>Without Coupon</span><span class="fw-bold"><?= formatPrice($nonCouponRevenue) ?></span></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-xl-6">
        <div class="card card-custom">
            <div class="card-header"><h6>Hourly Sales Heatmap</h6></div>
            <div class="card-body">
                <div class="heatmap-grid" id="heatmapGrid" style="display:grid;grid-template-columns:repeat(12,1fr);gap:4px;"></div>
                <div class="d-flex justify-content-between mt-2" style="font-size:0.7rem;color:#999"><span>12AM</span><span>6AM</span><span>12PM</span><span>6PM</span><span>11PM</span></div>
            </div>
        </div>
    </div>
    <div class="col-xl-6">
        <div class="card card-custom">
            <div class="card-header"><h6>Top Products by Revenue</h6></div>
            <div class="card-body"><canvas id="productChart" height="160"></canvas></div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-xl-6">
        <div class="card card-custom">
            <div class="card-header"><h6>Geographic Sales</h6></div>
            <div class="card-body"><canvas id="geoChart" height="160"></canvas></div>
        </div>
    </div>
    <div class="col-xl-6">
        <div class="card card-custom">
            <div class="card-header"><h6>Category Performance</h6></div>
            <div class="card-body"><canvas id="catChart" height="160"></canvas></div>
        </div>
    </div>
</div>

<div class="card card-custom" id="salesTable">
    <div class="card-header"><h6>Daily Breakdown</h6></div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-custom table-sm" id="dailyTable">
                <thead><tr><th>Date</th><th>Orders</th><th>Revenue</th></tr></thead>
                <tbody>
                <?php foreach ($dailySales as $ds): ?>
                <tr><td><?= $ds['date'] ?></td><td><?= $ds['orders'] ?></td><td class="fw-bold"><?= formatPrice($ds['revenue']) ?></td></tr>
                <?php endforeach; if (empty($dailySales)): ?><tr><td colspan="3" class="text-center text-muted">No data</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="<?= SITE_URL ?>/assets/js/chart.umd.min.js"></script>
<script>
const statusColors = ['#ffc107','#0dcaf0','#0d6efd','#6f42c1','#198754','#dc3545'];
const pieColors = ['#e94560','#0d6efd','#198754','#ffc107','#6f42c1','#0dcaf0'];

const revData = <?= $revenueJson ?>;
new Chart(document.getElementById('revenueChart'), {type:'line',data:{labels:revData.map(d=>d.date),datasets:[{label:'Revenue',data:revData.map(d=>d.revenue),borderColor:'#e94560',backgroundColor:'rgba(233,69,96,0.1)',fill:true,tension:0.4}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});

new Chart(document.getElementById('statusChart'), {type:'doughnut',data:{labels:<?= $statusLabelsJson ?>,datasets:[{data:<?= $statusCountsJson ?>,backgroundColor:statusColors}]},options:{responsive:true,plugins:{legend:{position:'bottom',labels:{boxWidth:12,padding:8}}}}});

new Chart(document.getElementById('paymentChart'), {type:'pie',data:{labels:<?= $paymentLabels ?>,datasets:[{data:<?= $paymentTotals ?>,backgroundColor:pieColors}]},options:{responsive:true,plugins:{legend:{position:'bottom',labels:{boxWidth:12,padding:8}}}}});

new Chart(document.getElementById('dayChart'), {type:'bar',data:{labels:<?= $dayNamesJson ?>,datasets:[{label:'Revenue',data:<?= $dayRevJson ?>,backgroundColor:'#e94560',borderRadius:6}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});

new Chart(document.getElementById('productChart'), {type:'bar',data:{labels:<?= $productNames ?>,datasets:[{label:'Revenue',data:<?= $productRevenues ?>,backgroundColor:'#e94560',borderRadius:6}]},options:{indexAxis:'y',responsive:true,plugins:{legend:{display:false}},scales:{x:{beginAtZero:true}}}});

new Chart(document.getElementById('geoChart'), {type:'bar',data:{labels:<?= $geoLabels ?>,datasets:[{label:'Revenue',data:<?= $geoRevenues ?>,backgroundColor:pieColors,borderRadius:6}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});

new Chart(document.getElementById('catChart'), {type:'bar',data:{labels:<?= $catLabels ?>,datasets:[{label:'Revenue',data:<?= $catRevenues ?>,backgroundColor:pieColors,borderRadius:6}]},options:{indexAxis:'y',responsive:true,plugins:{legend:{display:false}},scales:{x:{beginAtZero:true}}}});

const couponTotal = <?= $totalRevenue ?>;
new Chart(document.getElementById('couponChart'), {type:'doughnut',data:{labels:['With Coupon','Without Coupon'],datasets:[{data:[<?= $couponRevenue ?>,<?= $nonCouponRevenue ?>],backgroundColor:['#198754','#e9ecef']}]},options:{responsive:true,cutout:'70%',plugins:{legend:{display:false}}}});

const hourlyData = <?= $hourlyJson ?>;
const maxH = <?= $maxHourly ?>;
const grid = document.getElementById('heatmapGrid');
hourlyData.forEach((v, i) => {
    const cell = document.createElement('div');
    const intensity = v / maxH;
    cell.style.cssText = 'border-radius:4px;padding:8px 2px;text-align:center;font-size:0.65rem;color:'+(intensity>0.5?'#fff':'#333')+';background:rgba(233,69,96,'+(0.1+intensity*0.9)+');';
    cell.innerHTML = '<div class="fw-bold">'+i+':00</div><div>'+v+'</div>';
    grid.appendChild(cell);
});

function exportCSV() {
    var rows = [['Date','Orders','Revenue']];
    document.querySelectorAll('#dailyTable tbody tr').forEach(function(tr) {
        var cells = tr.querySelectorAll('td');
        if (cells.length >= 3) rows.push([cells[0].textContent.trim(),cells[1].textContent.trim(),cells[2].textContent.trim()]);
    });
    var csv = rows.map(r => r.map(c => '"'+c.replace(/"/g,'""')+'"').join(',')).join('\n');
    var blob = new Blob([csv],{type:'text/csv'});
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'sales_export.csv'; a.click();
}
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
