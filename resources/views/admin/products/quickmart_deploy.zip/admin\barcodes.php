<?php
$pageTitle = 'Barcodes';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM barcodes WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/barcodes.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $code = $_POST['barcode'] ?? strtoupper(substr(md5(uniqid()), 0, 12));
    if ($id) { query("UPDATE barcodes SET barcode=?, product_id=? WHERE id=?", [$code, (int)$_POST['product_id'], $id]); }
    else { query("INSERT INTO barcodes (barcode, product_id) VALUES (?,?)", [$code, (int)$_POST['product_id']]); }
    setAlert('success', 'Barcode saved!'); redirect(SITE_URL . '/admin/barcodes.php');
}
$barcodes = fetchAll("SELECT b.*, p.name as product_name FROM barcodes b LEFT JOIN products p ON b.product_id=p.id ORDER BY b.id DESC");
$products = fetchAll("SELECT id, name FROM products ORDER BY name");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Barcodes (<?= count($barcodes) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_prod').value='';document.getElementById('f_code').value='';document.getElementById('modalTitle').textContent='Add Barcode';"><i class="fas fa-plus"></i> Add</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>Barcode</th><th>Product</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($barcodes as $b): ?>
<tr><td><code class="fs-6"><?= htmlspecialchars($b['barcode']) ?></code></td><td><?= htmlspecialchars($b['product_name'] ?? 'N/A') ?></td>
<td><a href="?delete=<?= $b['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Barcode</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">Product</label><select name="product_id" id="f_prod" class="form-select" required><option value="">Select</option><?php foreach ($products as $p): ?><option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></option><?php endforeach; ?></select></div>
<div class="mb-3"><label class="form-label">Barcode (leave blank to auto-generate)</label><input type="text" name="barcode" id="f_code" class="form-control"></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
