<?php
$pageTitle = 'Price Alerts - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productId = (int)($_POST['product_id'] ?? 0);
    $targetPrice = (float)($_POST['target_price'] ?? 0);
    if ($productId && $targetPrice > 0) {
        query("INSERT OR REPLACE INTO price_alerts (user_id, product_id, target_price) VALUES (?,?,?)", [$_SESSION['user_id'], $productId, $targetPrice]);
        setAlert('success', 'Price alert set!');
        redirect(SITE_URL . '/store/price_alerts.php');
    }
}
if (isset($_GET['delete'])) {
    query("DELETE FROM price_alerts WHERE id=? AND user_id=?", [(int)$_GET['delete'], $_SESSION['user_id']]);
    setAlert('success', 'Alert removed.');
    redirect(SITE_URL . '/store/price_alerts.php');
}

$alerts = fetchAll("SELECT pa.*, p.name, p.price as current_price, p.slug FROM price_alerts pa JOIN products p ON pa.product_id=p.id WHERE pa.user_id=? ORDER BY pa.created_at DESC", [$_SESSION['user_id']]);
$products = fetchAll("SELECT id, name, price FROM products WHERE is_active=1 ORDER BY name LIMIT 100");
?>
<h2 class="mb-4"><i class="fas fa-bell"></i> Price Alerts</h2>
<div class="card card-custom p-4 mb-4">
    <h5>Set New Alert</h5>
    <form method="POST" class="row g-3">
        <div class="col-md-5">
            <select name="product_id" class="form-select" required>
                <option value="">Select Product</option>
                <?php foreach ($products as $p): ?>
                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?> (<?= formatPrice($p['price']) ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-4">
            <input type="number" name="target_price" class="form-control" placeholder="Target Price (BDT)" required>
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-primary w-100"><i class="fas fa-bell"></i> Set Alert</button>
        </div>
    </form>
</div>
<div class="card card-custom p-4">
    <h5>My Alerts</h5>
    <?php if (empty($alerts)): ?>
    <p class="text-muted">No price alerts set.</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-custom">
            <thead><tr><th>Product</th><th>Current Price</th><th>Target Price</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
                <?php foreach ($alerts as $a): ?>
                <tr>
                    <td><a href="<?= SITE_URL ?>/store/product.php?slug=<?= $a['slug'] ?>"><?= htmlspecialchars($a['name']) ?></a></td>
                    <td><?= formatPrice($a['current_price']) ?></td>
                    <td class="text-primary fw-bold"><?= formatPrice($a['target_price']) ?></td>
                    <td><?php if ($a['current_price'] <= $a['target_price']): ?><span class="badge bg-success">Target Reached!</span><?php else: ?><span class="badge bg-warning">Waiting</span><?php endif; ?></td>
                    <td><a href="?delete=<?= $a['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
