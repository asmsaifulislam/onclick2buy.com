<?php
$pageTitle = 'EMI Calculator - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
$price = floatval($_GET['price'] ?? 0);
?>
<h2 class="mb-4"><i class="fas fa-calculator"></i> EMI Calculator</h2>
<div class="row">
    <div class="col-md-5">
        <div class="card card-custom p-4">
            <h5>Calculate EMI</h5>
            <div class="mb-3">
                <label class="form-label fw-bold">Product Price (BDT)</label>
                <input type="number" id="emiPrice" class="form-control" value="<?= $price ?>" placeholder="Enter price">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Down Payment (%)</label>
                <input type="number" id="emiDown" class="form-control" value="20" min="0" max="90">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Interest Rate (% per year)</label>
                <input type="number" id="emiRate" class="form-control" value="12" step="0.5">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Tenure (months)</label>
                <select id="emiTenure" class="form-select">
                    <option value="3">3 Months</option>
                    <option value="6">6 Months</option>
                    <option value="9">9 Months</option>
                    <option value="12" selected>12 Months</option>
                    <option value="18">18 Months</option>
                    <option value="24">24 Months</option>
                </select>
            </div>
            <button class="btn btn-primary w-100" onclick="calculateEMI()">Calculate</button>
        </div>
    </div>
    <div class="col-md-7">
        <div class="card card-custom p-4" id="emiResult" style="display:none">
            <h5>EMI Breakdown</h5>
            <table class="table table-custom">
                <tr><td>Product Price</td><td class="text-end fw-bold" id="rPrice">-</td></tr>
                <tr><td>Down Payment</td><td class="text-end" id="rDown">-</td></tr>
                <tr><td>Loan Amount</td><td class="text-end" id="rLoan">-</td></tr>
                <tr><td>Monthly EMI</td><td class="text-end text-primary fw-bold fs-5" id="rEMI">-</td></tr>
                <tr><td>Total Payment</td><td class="text-end" id="rTotal">-</td></tr>
                <tr><td>Total Interest</td><td class="text-end text-danger" id="rInterest">-</td></tr>
            </table>
        </div>
        <div class="card card-custom p-4 mt-3">
            <h6>Available Banks</h6>
            <div class="d-flex flex-wrap gap-2">
                <span class="badge bg-primary p-2">DBBL</span>
                <span class="badge bg-primary p-2">BRAC Bank</span>
                <span class="badge bg-primary p-2">City Bank</span>
                <span class="badge bg-primary p-2">UCB</span>
                <span class="badge bg-primary p-2">Eastern Bank</span>
                <span class="badge bg-primary p-2">Prime Bank</span>
            </div>
        </div>
    </div>
</div>
<script>
function calculateEMI() {
    var price = parseFloat(document.getElementById('emiPrice').value) || 0;
    var downPct = parseFloat(document.getElementById('emiDown').value) || 0;
    var rate = parseFloat(document.getElementById('emiRate').value) || 0;
    var tenure = parseInt(document.getElementById('emiTenure').value) || 12;
    var down = price * downPct / 100;
    var loan = price - down;
    var monthlyRate = rate / 12 / 100;
    var emi = monthlyRate > 0 ? loan * monthlyRate * Math.pow(1+monthlyRate, tenure) / (Math.pow(1+monthlyRate, tenure)-1) : loan / tenure;
    var total = emi * tenure + down;
    var interest = total - price;
    document.getElementById('rPrice').textContent = 'BDT ' + price.toLocaleString();
    document.getElementById('rDown').textContent = 'BDT ' + down.toLocaleString();
    document.getElementById('rLoan').textContent = 'BDT ' + loan.toLocaleString();
    document.getElementById('rEMI').textContent = 'BDT ' + Math.round(emi).toLocaleString() + '/mo';
    document.getElementById('rTotal').textContent = 'BDT ' + Math.round(total).toLocaleString();
    document.getElementById('rInterest').textContent = 'BDT ' + Math.round(interest).toLocaleString();
    document.getElementById('emiResult').style.display = 'block';
}
if (document.getElementById('emiPrice').value > 0) calculateEMI();
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
