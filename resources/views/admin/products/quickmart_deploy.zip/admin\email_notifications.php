<?php
$pageTitle = 'Email Notifications';
require_once __DIR__ . '/../includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fields = ['email_enabled','smtp_host','smtp_port','smtp_user','smtp_pass','email_order_confirmation','email_status_update','email_low_stock','email_promotion'];
    foreach ($fields as $f) {
        $value = $_POST[$f] ?? '';
        $existing = fetch("SELECT id FROM site_config WHERE `key`=?", [$f]);
        if ($existing) { query("UPDATE site_config SET value=? WHERE `key`=?", [$value, $f]); }
        else { query("INSERT INTO site_config (`key`, value) VALUES (?,?)", [$f, $value]); }
    }
    setAlert('success', 'Email settings saved!'); redirect(SITE_URL . '/admin/email_notifications.php');
}

if (isset($_GET['test_email'])) {
    $to = ADMIN_EMAIL;
    $subject = "Quick Mart - Test Email";
    $body = "This is a test email from Quick Mart.\n\nIf you received this, email notifications are working!\n\nQuick Mart Team";
    $sent = @mail($to, $subject, $body);
    if ($sent) setAlert('success', "Test email sent to $to");
    else setAlert('danger', 'Failed to send email. Check SMTP settings.');
    redirect(SITE_URL . '/admin/email_notifications.php');
}

$config = [];
$rows = fetchAll("SELECT `key`, value FROM site_config WHERE `key` LIKE 'email%' OR `key` LIKE 'smtp%'");
foreach ($rows as $r) $config[$r['key']] = $r['value'];

$lowStockProducts = fetchAll("SELECT name, stock FROM products WHERE stock <= 10 AND is_active=1 ORDER BY stock ASC LIMIT 10");
$recentOrders = fetchAll("SELECT o.order_number, o.shipping_name, u.email as shipping_email, o.status, o.created_at FROM orders o LEFT JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC LIMIT 10");

$templates = [
    'order_confirmation' => [
        'name' => 'Order Confirmation',
        'subject' => 'Order #{order_number} Confirmed - Quick Mart',
        'body' => "Hi {name},\n\nYour order #{order_number} has been confirmed!\n\nOrder Details:\n{items}\n\nTotal: BDT {total}\nPayment: {payment_method}\n\nTrack your order: {tracking_url}\n\nThank you for shopping with Quick Mart!",
        'enabled' => $config['email_order_confirmation'] ?? '1'
    ],
    'status_update' => [
        'name' => 'Order Status Update',
        'subject' => 'Order #{order_number} - Status Updated',
        'body' => "Hi {name},\n\nYour order #{order_number} status has been updated to: {status}\n\n{note}\n\nTrack your order: {tracking_url}\n\nQuick Mart Team",
        'enabled' => $config['email_status_update'] ?? '1'
    ],
    'low_stock' => [
        'name' => 'Low Stock Alert (Admin)',
        'subject' => 'Low Stock Alert - Quick Mart',
        'body' => "Low Stock Alert!\n\nThe following products are running low:\n{products}\n\nPlease restock soon.\n\nQuick Mart Admin",
        'enabled' => $config['email_low_stock'] ?? '1'
    ],
    'promotion' => [
        'name' => 'Promotional Email',
        'subject' => 'Special Offer from Quick Mart!',
        'body' => "Hi {name},\n\nWe have a special offer for you!\n\n{promotion_details}\n\nUse code {coupon_code} for {discount}% off!\n\nShop now: {shop_url}\n\nQuick Mart Team",
        'enabled' => $config['email_promotion'] ?? '0'
    ]
];
?>
<h4 class="mb-4"><i class="fas fa-envelope"></i> Email Notifications</h4>

<div class="row g-4">
    <div class="col-md-8">
        <div class="card card-custom p-4 mb-4">
            <h6>Email / SMTP Configuration</h6>
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Enable Email</label>
                        <select name="email_enabled" class="form-select"><option value="1" <?= ($config['email_enabled'] ?? '1')=='1'?'selected':'' ?>>Yes</option><option value="0" <?= ($config['email_enabled'] ?? '1')=='0'?'selected':'' ?>>No</option></select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">SMTP Host</label>
                        <input type="text" name="smtp_host" class="form-control" value="<?= htmlspecialchars($config['smtp_host'] ?? 'smtp.gmail.com') ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">SMTP Port</label>
                        <input type="number" name="smtp_port" class="form-control" value="<?= htmlspecialchars($config['smtp_port'] ?? '587') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">SMTP Username</label>
                        <input type="text" name="smtp_user" class="form-control" value="<?= htmlspecialchars($config['smtp_user'] ?? '') ?>" placeholder="your@email.com">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">SMTP Password</label>
                        <input type="password" name="smtp_pass" class="form-control" value="<?= htmlspecialchars($config['smtp_pass'] ?? '') ?>">
                    </div>
                </div>
                <div class="row g-3 mt-2">
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Order Confirmation</label>
                        <select name="email_order_confirmation" class="form-select"><option value="1" <?= ($config['email_order_confirmation'] ?? '1')=='1'?'selected':'' ?>>On</option><option value="0" <?= ($config['email_order_confirmation'] ?? '1')=='0'?'selected':'' ?>>Off</option></select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Status Updates</label>
                        <select name="email_status_update" class="form-select"><option value="1" <?= ($config['email_status_update'] ?? '1')=='1'?'selected':'' ?>>On</option><option value="0" <?= ($config['email_status_update'] ?? '1')=='0'?'selected':'' ?>>Off</option></select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Low Stock Alert</label>
                        <select name="email_low_stock" class="form-select"><option value="1" <?= ($config['email_low_stock'] ?? '1')=='1'?'selected':'' ?>>On</option><option value="0" <?= ($config['email_low_stock'] ?? '1')=='0'?'selected':'' ?>>Off</option></select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Promotions</label>
                        <select name="email_promotion" class="form-select"><option value="1" <?= ($config['email_promotion'] ?? '0')=='1'?'selected':'' ?>>On</option><option value="0" <?= ($config['email_promotion'] ?? '0')=='0'?'selected':'' ?>>Off</option></select>
                    </div>
                </div>
                <div class="mt-3">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
                    <a href="?test_email=1" class="btn btn-outline-info ms-2"><i class="fas fa-paper-plane"></i> Send Test Email</a>
                </div>
            </form>
        </div>

        <div class="card card-custom p-4">
            <h6>Email Templates</h6>
            <?php foreach ($templates as $key => $t): ?>
            <div class="border rounded p-3 mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <strong><?= $t['name'] ?></strong>
                    <span class="badge bg-<?= $t['enabled']=='1'?'success':'secondary' ?>"><?= $t['enabled']=='1'?'Enabled':'Disabled' ?></span>
                </div>
                <pre class="bg-dark p-2 rounded small mb-0" style="white-space:pre-wrap"><?= htmlspecialchars($t['body']) ?></pre>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-custom p-4 mb-4">
            <h6>Email Stats</h6>
            <div class="d-flex justify-content-between mb-2"><span>Configured</span><span class="badge bg-<?= ($config['email_enabled'] ?? '1')=='1'?'success':'danger' ?>"><?= ($config['email_enabled'] ?? '1')=='1'?'Yes':'No' ?></span></div>
            <div class="d-flex justify-content-between mb-2"><span>SMTP Host</span><small><?= htmlspecialchars($config['smtp_host'] ?? 'Not set') ?></small></div>
        </div>
        <div class="card card-custom p-4 mb-4">
            <h6>Low Stock Alert (≤10)</h6>
            <?php if (empty($lowStockProducts)): ?><p class="text-muted small">All products well stocked.</p><?php endif; ?>
            <?php foreach ($lowStockProducts as $ls): ?>
            <div class="d-flex justify-content-between small mb-1"><span><?= htmlspecialchars($ls['name']) ?></span><span class="badge bg-<?= $ls['stock']==0?'danger':'warning' ?>"><?= $ls['stock'] ?></span></div>
            <?php endforeach; ?>
        </div>
        <div class="card card-custom p-4">
            <h6>Recent Orders (for email)</h6>
            <?php foreach ($recentOrders as $ro): ?>
            <div class="small border-bottom py-1">
                <strong>#<?= $ro['order_number'] ?></strong> — <?= htmlspecialchars($ro['shipping_name']) ?><br>
                <span class="text-muted"><?= $ro['shipping_email'] ?? 'No email' ?> | <?= date('M d', strtotime($ro['created_at'])) ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
