<?php
$pageTitle = 'Subscriptions';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['cancel'])) { query("UPDATE subscriptions SET status='cancelled' WHERE id=?", [(int)$_GET['cancel']]); setAlert('success', 'Subscription cancelled.'); redirect(SITE_URL . '/admin/subscriptions.php'); }
$subscriptions = fetchAll("SELECT s.*, u.username, p.name as product_name FROM subscriptions s LEFT JOIN users u ON s.user_id=u.id LEFT JOIN products p ON s.product_id=p.id ORDER BY s.created_at DESC");
?>
<h4 class="mb-4">Subscriptions (<?= count($subscriptions) ?>)</h4>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>User</th><th>Product</th><th>Plan</th><th>Frequency</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($subscriptions as $s): ?>
<tr><td><?= htmlspecialchars($s['username'] ?? 'N/A') ?></td><td><?= htmlspecialchars($s['product_name'] ?? 'Deleted') ?></td><td><?= htmlspecialchars($s['plan_name']) ?></td>
<td><span class="badge bg-info"><?= ucfirst($s['frequency']) ?></span></td><td><?= formatPrice($s['price']) ?></td>
<td><span class="badge bg-<?= $s['status']=='active'?'success':($s['status']=='cancelled'?'danger':'warning') ?>"><?= ucfirst($s['status']) ?></span></td>
<td><?php if ($s['status']=='active'): ?><a href="?cancel=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Cancel subscription?')"><i class="fas fa-times"></i> Cancel</a><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
