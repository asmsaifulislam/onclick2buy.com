<?php
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

if (!isLoggedIn() || !isAdmin()) {
    echo json_encode([]);
    exit;
}

$q = trim($_GET['q'] ?? '');
if (strlen($q) < 2) {
    echo json_encode([]);
    exit;
}

$term = "%{$q}%";
$results = [];

$products = fetchAll("SELECT id, name, price, stock FROM products WHERE name LIKE ? OR description LIKE ? LIMIT 5", [$term, $term]);
foreach ($products as $p) {
    $results[] = [
        'type' => 'product',
        'icon' => 'fas fa-box',
        'color' => '#e94560',
        'title' => $p['name'],
        'subtitle' => formatPrice($p['price']) . ' | Stock: ' . $p['stock'],
        'url' => SITE_URL . '/admin/products.php',
    ];
}

$orders = fetchAll("SELECT o.id, o.order_number, o.total, o.status, o.payment_status, u.username FROM orders o LEFT JOIN users u ON o.user_id=u.id WHERE o.order_number LIKE ? OR o.shipping_name LIKE ? OR o.shipping_phone LIKE ? LIMIT 5", [$term, $term, $term]);
foreach ($orders as $o) {
    $results[] = [
        'type' => 'order',
        'icon' => 'fas fa-shopping-cart',
        'color' => '#0d6efd',
        'title' => '#' . $o['order_number'] . ' — ' . ($o['username'] ?? $o['shipping_name'] ?? 'Guest'),
        'subtitle' => formatPrice($o['total']) . ' | ' . ucfirst($o['status']),
        'url' => SITE_URL . '/admin/orders.php',
    ];
}

$customers = fetchAll("SELECT u.id, u.username, u.email, u.is_staff FROM users u WHERE u.is_staff=0 AND (u.username LIKE ? OR u.email LIKE ?) LIMIT 5", [$term, $term]);
foreach ($customers as $c) {
    $results[] = [
        'type' => 'customer',
        'icon' => 'fas fa-user',
        'color' => '#198754',
        'title' => $c['username'],
        'subtitle' => $c['email'],
        'url' => SITE_URL . '/admin/customers.php',
    ];
}

$coupons = fetchAll("SELECT id, code, discount_percent, discount_amount, used_count FROM coupons WHERE code LIKE ? LIMIT 3", [$term]);
foreach ($coupons as $c) {
    $disc = $c['discount_percent'] > 0 ? $c['discount_percent'] . '% off' : formatPrice($c['discount_amount']) . ' off';
    $results[] = [
        'type' => 'coupon',
        'icon' => 'fas fa-ticket-alt',
        'color' => '#ffc107',
        'title' => $c['code'],
        'subtitle' => $disc . ' | Used: ' . $c['used_count'],
        'url' => SITE_URL . '/admin/coupons.php',
    ];
}

$blog = fetchAll("SELECT id, title FROM blog_posts WHERE title LIKE ? OR content LIKE ? LIMIT 3", [$term, $term]);
foreach ($blog as $b) {
    $results[] = [
        'type' => 'blog',
        'icon' => 'fas fa-blog',
        'color' => '#6f42c1',
        'title' => $b['title'],
        'subtitle' => 'Blog Post',
        'url' => SITE_URL . '/admin/blog.php',
    ];
}

$categories = fetchAll("SELECT id, name FROM categories WHERE name LIKE ? LIMIT 3", [$term]);
foreach ($categories as $c) {
    $results[] = [
        'type' => 'category',
        'icon' => 'fas fa-tags',
        'color' => '#0dcaf0',
        'title' => $c['name'],
        'subtitle' => 'Category',
        'url' => SITE_URL . '/admin/categories.php',
    ];
}

$users = fetchAll("SELECT id, username, email, role FROM users WHERE username LIKE ? OR email LIKE ? LIMIT 3", [$term, $term]);
foreach ($users as $u) {
    $results[] = [
        'type' => 'user',
        'icon' => 'fas fa-user-cog',
        'color' => '#dc3545',
        'title' => $u['username'],
        'subtitle' => ucfirst($u['role'] ?? 'user') . ' | ' . $u['email'],
        'url' => SITE_URL . '/admin/users.php',
    ];
}

$pages = [
    ['name' => 'Dashboard', 'url' => '/admin/', 'icon' => 'fas fa-tachometer-alt'],
    ['name' => 'BI 360 Analytics', 'url' => '/admin/bi360.php', 'icon' => 'fas fa-chart-pie'],
    ['name' => 'All Orders', 'url' => '/admin/orders.php', 'icon' => 'fas fa-shopping-cart'],
    ['name' => 'Products', 'url' => '/admin/products.php', 'icon' => 'fas fa-box'],
    ['name' => 'Categories', 'url' => '/admin/categories.php', 'icon' => 'fas fa-tags'],
    ['name' => 'Coupons', 'url' => '/admin/coupons.php', 'icon' => 'fas fa-ticket-alt'],
    ['name' => 'Blog Posts', 'url' => '/admin/blog.php', 'icon' => 'fas fa-blog'],
    ['name' => 'Inventory', 'url' => '/admin/inventory.php', 'icon' => 'fas fa-warehouse'],
    ['name' => 'Sales Overview', 'url' => '/admin/sales.php', 'icon' => 'fas fa-chart-line'],
    ['name' => 'Reports', 'url' => '/admin/reports.php', 'icon' => 'fas fa-chart-bar'],
    ['name' => 'Flash Sales', 'url' => '/admin/flash_sales.php', 'icon' => 'fas fa-bolt'],
    ['name' => 'Promotions', 'url' => '/admin/promotions.php', 'icon' => 'fas fa-percent'],
    ['name' => 'Gift Wraps', 'url' => '/admin/gift_wraps.php', 'icon' => 'fas fa-gift'],
    ['name' => 'Customers', 'url' => '/admin/customers.php', 'icon' => 'fas fa-users'],
    ['name' => 'Users Control', 'url' => '/admin/users.php', 'icon' => 'fas fa-user-cog'],
    ['name' => 'Staff Roles', 'url' => '/admin/staff.php', 'icon' => 'fas fa-user-shield'],
    ['name' => 'Wallets', 'url' => '/admin/wallets.php', 'icon' => 'fas fa-wallet'],
    ['name' => 'Bundles', 'url' => '/admin/bundles.php', 'icon' => 'fas fa-boxes'],
    ['name' => 'Affiliates', 'url' => '/admin/affiliates.php', 'icon' => 'fas fa-link'],
    ['name' => 'Loyalty Points', 'url' => '/admin/loyalty.php', 'icon' => 'fas fa-star'],
    ['name' => 'Revenue Target', 'url' => '/admin/revenue_target.php', 'icon' => 'fas fa-bullseye'],
    ['name' => 'Size Guides', 'url' => '/admin/size_guides.php', 'icon' => 'fas fa-ruler'],
    ['name' => 'Push Notifications', 'url' => '/admin/push_notifications.php', 'icon' => 'fas fa-bell'],
    ['name' => 'Barcodes', 'url' => '/admin/barcodes.php', 'icon' => 'fas fa-barcode'],
    ['name' => 'Store Locations', 'url' => '/admin/store_locations.php', 'icon' => 'fas fa-map-marker-alt'],
    ['name' => 'Subscriptions', 'url' => '/admin/subscriptions.php', 'icon' => 'fas fa-sync-alt'],
    ['name' => 'Price Alerts', 'url' => '/admin/price_alerts.php', 'icon' => 'fas fa-bell'],
    ['name' => 'Activity Log', 'url' => '/admin/activity_log.php', 'icon' => 'fas fa-history'],
    ['name' => 'SMS Settings', 'url' => '/admin/sms_settings.php', 'icon' => 'fas fa-sms'],
    ['name' => 'Email Settings', 'url' => '/admin/email_notifications.php', 'icon' => 'fas fa-envelope'],
    ['name' => 'Site Config', 'url' => '/admin/site_config.php', 'icon' => 'fas fa-cog'],
    ['name' => 'Cart Recovery', 'url' => '/admin/cart_recovery.php', 'icon' => 'fas fa-redo'],
    ['name' => 'Import/Export', 'url' => '/admin/import_export.php', 'icon' => 'fas fa-file-import'],
    ['name' => 'Backup', 'url' => '/admin/auto_backup.php', 'icon' => 'fas fa-database'],
    ['name' => 'Vendors', 'url' => '/admin/vendors.php', 'icon' => 'fas fa-store-alt'],
    ['name' => 'Variants', 'url' => '/admin/variants.php', 'icon' => 'fas fa-layer-group'],
];

$lq = strtolower($q);
$matchedPages = array_filter($pages, function($p) use ($lq) {
    return stripos($p['name'], $lq) !== false;
});
foreach (array_slice($matchedPages, 0, 3) as $mp) {
    $results[] = [
        'type' => 'page',
        'icon' => $mp['icon'],
        'color' => '#6c757d',
        'title' => $mp['name'],
        'subtitle' => 'Page',
        'url' => SITE_URL . $mp['url'],
    ];
}

echo json_encode(array_slice($results, 0, 15));


