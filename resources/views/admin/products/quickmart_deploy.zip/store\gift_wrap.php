<?php
$pageTitle = 'Gift Wrapping - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
$wraps = fetchAll("SELECT * FROM gift_wraps WHERE is_active=1 ORDER BY price");
?>
<h2 class="mb-4"><i class="fas fa-gift"></i> Gift Wrapping Options</h2>
<p class="text-muted mb-4">Add beautiful gift wrapping to your orders!</p>
<div class="row g-4">
    <?php foreach ($wraps as $w): ?>
    <div class="col-md-3">
        <div class="card card-custom p-4 text-center h-100">
            <i class="fas fa-gift fa-3x text-primary mb-3"></i>
            <h5><?= htmlspecialchars($w['name']) ?></h5>
            <p class="text-muted small"><?= htmlspecialchars($w['description']) ?></p>
            <h4 class="text-primary"><?= formatPrice($w['price']) ?></h4>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<div class="card card-custom p-4 mt-4">
    <h5>How it works</h5>
    <ol class="text-muted">
        <li>Add products to your cart</li>
        <li>Proceed to checkout</li>
        <li>Select your gift wrapping option</li>
        <li>Add a personal message (optional)</li>
    </ol>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
