<?php
$pageTitle = 'Flash Sales - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
$now = date('Y-m-d H:i:s');
$sales = fetchAll("SELECT fs.*, GROUP_CONCAT(p.name) as product_names FROM flash_sales fs LEFT JOIN flash_sale_products fsp ON fs.id=fsp.flash_sale_id LEFT JOIN products p ON fsp.product_id=p.id WHERE fs.is_active=1 AND fs.start_date<=? AND fs.end_date>=? GROUP BY fs.id ORDER BY fs.end_date ASC", [$now, $now]);
$allSales = fetchAll("SELECT * FROM flash_sales WHERE is_active=1 ORDER BY start_date DESC");
?>
<h2 class="mb-4"><i class="fas fa-bolt text-warning"></i> Flash Sales</h2>
<?php if (empty($allSales)): ?>
<div class="text-center py-5"><i class="fas fa-bolt fa-4x text-muted mb-3" style="opacity:0.3"></i><h5>No flash sales right now</h5></div>
<?php else: ?>
<?php foreach ($allSales as $sale):
    $products = fetchAll("SELECT fsp.*, p.name, p.price as original_price FROM flash_sale_products fsp JOIN products p ON fsp.product_id=p.id WHERE fsp.flash_sale_id=?", [$sale['id']]);
    $isActive = ($now >= $sale['start_date'] && $now <= $sale['end_date']);
?>
<div class="card card-custom p-4 mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4><?= htmlspecialchars($sale['name']) ?> <span class="badge bg-danger"><?= $sale['discount_percent'] ?>% OFF</span></h4>
            <p class="text-muted mb-0"><?= date('M d, Y', strtotime($sale['start_date'])) ?> - <?= date('M d, Y', strtotime($sale['end_date'])) ?></p>
        </div>
        <?php if ($isActive): ?>
        <span class="badge bg-success p-2"><i class="fas fa-circle fa-blink"></i> LIVE NOW</span>
        <?php else: ?>
        <span class="badge bg-secondary p-2">Ended</span>
        <?php endif; ?>
    </div>
    <div class="row g-3">
        <?php foreach ($products as $fp): ?>
        <div class="col-md-3">
            <div class="card card-custom p-3 text-center">
                <h6><?= htmlspecialchars($fp['name']) ?></h6>
                <p><del class="text-muted"><?= formatPrice($fp['original_price']) ?></del></p>
                <h5 class="text-danger"><?= formatPrice($fp['sale_price']) ?></h5>
                <button class="btn btn-sm btn-primary add-to-cart-btn" data-id="<?= $fp['product_id'] ?>"><i class="fas fa-cart-plus"></i> Add</button>
                <button class="buy-now-btn buy-now-btn-sm mt-2 w-100" data-id="<?= $fp['product_id'] ?>"><i class="fas fa-bolt"></i> Buy Now</button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>
<style>.fa-blink{animation:blink 1s infinite} @keyframes blink{0%,100%{opacity:1}50%{opacity:0.3}}</style>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
