<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';
$q = trim($_GET['q'] ?? '');
header('Content-Type: application/json');
if (strlen($q) < 2) { echo json_encode([]); exit; }
$products = fetchAll("SELECT name, slug, price, image FROM products WHERE is_active=1 AND name LIKE ? ORDER BY name LIMIT 10", ["%$q%"]);
$results = array_map(fn($p) => ['name' => $p['name'], 'url' => SITE_URL . '/store/product.php?slug=' . $p['slug'], 'price' => formatPrice($p['price']), 'image' => $p['image']], $products);
echo json_encode($results);
