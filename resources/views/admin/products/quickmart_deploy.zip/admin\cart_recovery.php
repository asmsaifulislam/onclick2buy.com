<?php
$pageTitle = 'Cart Abandonment';
require_once __DIR__ . '/../includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['save_settings'])) {
        $fields = ['cart_recovery_enabled', 'cart_recovery_hours', 'cart_recovery_email_template'];
        foreach ($fields as $f) {
            $value = $_POST[$f] ?? '';
            $existing = fetch("SELECT id FROM site_config WHERE `key`=?", [$f]);
            if ($existing) { query("UPDATE site_config SET value=? WHERE `key`=?", [$value, $f]); }
            else { query("INSERT INTO site_config (`key`, value) VALUES (?,?)", [$f, $value]); }
        }
        setAlert('success', 'Cart recovery settings saved!'); redirect(SITE_URL . '/admin/cart_recovery.php');
    }
    if (isset($_POST['send_recovery'])) {
        $abandoned = fetchAll("SELECT ca.*, u.email, u.username FROM cart_abandonment ca LEFT JOIN users u ON ca.user_id=u.id WHERE ca.recovery_sent=0 AND ca.cart_total > 0 ORDER BY ca.created_at DESC");
        $sent = 0;
        foreach ($abandoned as $cart) {
            if ($cart['email']) {
                $to = $cart['email'];
                $subject = "You left items in your cart! Complete your order now";
                $body = "Hi " . htmlspecialchars($cart['username'] ?? 'there') . ",\n\n";
                $body .= "You left " . htmlspecialchars($cart['items_summary']) . " in your cart (Total: BDT " . number_format($cart['cart_total']) . ").\n\n";
                $body .= "Complete your order now: " . SITE_URL . "/store/cart.php\n\n";
                $body .= "Use code WELCOME10 for 10% off!\n\n";
                $body .= "Quick Mart Team";
                mail($to, $subject, $body);
                query("UPDATE cart_abandonment SET recovery_sent=1 WHERE id=?", [$cart['id']]);
                $sent++;
            }
        }
        setAlert('success', "Recovery emails sent to $sent customers!");
        redirect(SITE_URL . '/admin/cart_recovery.php');
    }
}

$config = [];
$rows = fetchAll("SELECT `key`, value FROM site_config WHERE `key` LIKE 'cart_recovery%'");
foreach ($rows as $r) $config[$r['key']] = $r['value'];

$abandonedCarts = fetchAll("SELECT ca.*, u.username, u.email FROM cart_abandonment ca LEFT JOIN users u ON ca.user_id=u.id ORDER BY ca.created_at DESC LIMIT 50");
$totalAbandoned = count_rows("SELECT COUNT(*) FROM cart_abandonment");
$recoverySent = count_rows("SELECT COUNT(*) FROM cart_abandonment WHERE recovery_sent=1");
$recoveredOrders = count_rows("SELECT COUNT(*) FROM cart_abandonment WHERE recovery_sent=1 AND email_sent=1");
$abandonedRevenue = count_rows("SELECT COALESCE(SUM(cart_total),0) FROM cart_abandonment WHERE recovery_sent=0");
?>
<h4 class="mb-4"><i class="fas fa-shopping-cart"></i> Cart Abandonment Recovery</h4>

<div class="row g-4 mb-4">
    <div class="col-md-3"><div class="card card-custom p-3 text-center"><h3 class="text-warning"><?= $totalAbandoned ?></h3><p class="text-muted mb-0">Abandoned Carts</p></div></div>
    <div class="col-md-3"><div class="card card-custom p-3 text-center"><h3 class="text-info"><?= $recoverySent ?></h3><p class="text-muted mb-0">Recovery Sent</p></div></div>
    <div class="col-md-3"><div class="card card-custom p-3 text-center"><h3 class="text-success"><?= $recoveredOrders ?></h3><p class="text-muted mb-0">Recovered</p></div></div>
    <div class="col-md-3"><div class="card card-custom p-3 text-center"><h3 class="text-danger"><?= formatPrice($abandonedRevenue) ?></h3><p class="text-muted mb-0">Lost Revenue</p></div></div>
</div>

<div class="row g-4">
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h6>Recovery Settings</h6>
            <form method="POST">
                <input type="hidden" name="save_settings" value="1">
                <div class="mb-3"><label class="form-label fw-bold">Enable Cart Recovery</label>
                    <select name="cart_recovery_enabled" class="form-select"><option value="1" <?= ($config['cart_recovery_enabled'] ?? '1')=='1'?'selected':'' ?>>Yes</option><option value="0" <?= ($config['cart_recovery_enabled'] ?? '1')=='0'?'selected':'' ?>>No</option></select></div>
                <div class="mb-3"><label class="form-label fw-bold">Hours Before Recovery Email</label>
                    <input type="number" name="cart_recovery_hours" class="form-control" value="<?= htmlspecialchars($config['cart_recovery_hours'] ?? '24') ?>"></div>
                <div class="mb-3"><label class="form-label fw-bold">Recovery Email Template</label>
                    <textarea name="cart_recovery_email_template" class="form-control" rows="4"><?= htmlspecialchars($config['cart_recovery_email_template'] ?? "Hi {name},\n\nYou left items in your cart!\nTotal: BDT {total}\n\nComplete your order: {cart_url}\n\nUse code WELCOME10 for 10% off!") ?></textarea></div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
            </form>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6>Abandoned Carts</h6>
                <form method="POST" class="d-inline"><input type="hidden" name="send_recovery" value="1"><button type="submit" class="btn btn-sm btn-warning"><i class="fas fa-envelope"></i> Send Recovery Emails</button></form>
            </div>
            <div style="max-height:400px;overflow-y:auto">
            <?php if (empty($abandonedCarts)): ?><p class="text-muted">No abandoned carts.</p><?php endif; ?>
            <?php foreach ($abandonedCarts as $c): ?>
            <div class="d-flex justify-content-between align-items-center p-2 border-bottom small">
                <div>
                    <strong><?= htmlspecialchars($c['username'] ?? 'Guest') ?></strong><br>
                    <span class="text-muted"><?= htmlspecialchars($c['items_summary'] ?? '') ?></span><br>
                    <span class="text-warning fw-bold"><?= formatPrice($c['cart_total']) ?></span>
                </div>
                <div class="text-end">
                    <span class="badge bg-<?= $c['recovery_sent']?'success':'secondary' ?>"><?= $c['recovery_sent']?'Sent':'Pending' ?></span><br>
                    <small class="text-muted"><?= date('M d H:i', strtotime($c['created_at'])) ?></small>
                </div>
            </div>
            <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
