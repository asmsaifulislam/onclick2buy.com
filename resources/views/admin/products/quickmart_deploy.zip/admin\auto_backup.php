<?php
$pageTitle = 'Auto Backup';
require_once __DIR__ . '/../includes/admin_header.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['backup_now'])) {
    $dbPath = __DIR__ . '/../quickmart.db';
    $backupDir = __DIR__ . '/../backups';
    if (!is_dir($backupDir)) mkdir($backupDir, 0755, true);
    $backupFile = $backupDir . '/backup_' . date('Y-m-d_H-i-s') . '.db';
    if (copy($dbPath, $backupFile)) {
        $size = filesize($backupFile);
        query("INSERT INTO site_config (`key`, value) VALUES ('last_backup_size', ?)", [$size . ' bytes']);
        setAlert('success', 'Backup created: ' . basename($backupFile) . ' (' . round($size/1024, 1) . ' KB)');
    } else {
        setAlert('danger', 'Backup failed!');
    }
    redirect(SITE_URL . '/admin/auto_backup.php');
}
$backupDir = __DIR__ . '/../backups';
$backups = [];
if (is_dir($backupDir)) {
    foreach (glob($backupDir . '/backup_*.db') as $file) {
        $backups[] = ['name' => basename($file), 'size' => filesize($file), 'date' => filemtime($file)];
    }
    usort($backups, function($a,$b) { return $b['date'] - $a['date']; });
}
if (isset($_GET['delete_backup'])) {
    $target = $backupDir . '/' . basename($_GET['delete_backup']);
    if (file_exists($target)) { unlink($target); setAlert('success', 'Backup deleted.'); redirect(SITE_URL . '/admin/auto_backup.php'); }
}
$lastBackup = fetch("SELECT value FROM site_config WHERE `key`='last_backup'");
$lastSize = fetch("SELECT value FROM site_config WHERE `key`='last_backup_size'");
?>
<h4 class="mb-4">Database Backup</h4>
<div class="card card-custom mb-4"><div class="card-body">
<div class="d-flex justify-content-between align-items-center mb-3">
<div>
    <h5>SQLite Database Backup</h5>
    <p class="text-muted mb-0">Database: <code>quickmart.db</code> <?php if ($lastBackup): ?> | Last backup: <?= $lastBackup['value'] ?><?php endif; ?> <?php if ($lastSize): ?> (<?= $lastSize['value'] ?>)<?php endif; ?></p>
</div>
<form method="POST"><input type="hidden" name="backup_now" value="1">
<button type="submit" class="btn btn-primary"><i class="fas fa-download"></i> Backup Now</button></form>
</div>
<p class="small text-muted mb-0"><i class="fas fa-info-circle"></i> For production: download backups regularly and store offsite. Configure cron via cPanel for automatic backups.</p>
</div></div>
<?php if (!empty($backups)): ?>
<div class="card card-custom"><div class="card-body">
<h5>Existing Backups (<?= count($backups) ?>)</h5>
<div class="table-responsive">
<table class="table table-custom"><thead><tr><th>File</th><th>Size</th><th>Date</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($backups as $b): ?>
<tr>
<td><i class="fas fa-database text-success"></i> <?= $b['name'] ?></td>
<td><?= round($b['size']/1024, 1) ?> KB</td>
<td><?= date('M d, Y H:i', $b['date']) ?></td>
<td><a href="<?= SITE_URL ?>/backups/<?= $b['name'] ?>" class="btn btn-sm btn-success" download><i class="fas fa-download"></i> Download</a> <a href="?delete_backup=<?= $b['name'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this backup?')"><i class="fas fa-trash"></i></a></td>
</tr><?php endforeach; ?></tbody></table></div>
</div></div>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
