<?php
$pageTitle = 'Promotions';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM promotions WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/promotions.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [$_POST['name'], $_POST['promotion_type'], (float)$_POST['discount_percent'], (float)$_POST['discount_amount'], (float)$_POST['min_purchase'], $_POST['start_date'], $_POST['end_date'], $_POST['status']];
    if ($id) { query("UPDATE promotions SET name=?, promotion_type=?, discount_percent=?, discount_amount=?, min_purchase=?, start_date=?, end_date=?, status=? WHERE id=?", array_merge($data, [$id])); }
    else { query("INSERT INTO promotions (name, promotion_type, discount_percent, discount_amount, min_purchase, start_date, end_date, status) VALUES (?,?,?,?,?,?,?,?)", $data); }
    setAlert('success', 'Promotion saved!'); redirect(SITE_URL . '/admin/promotions.php');
}
$promos = fetchAll("SELECT * FROM promotions ORDER BY created_at DESC");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Promotions (<?= count($promos) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_name').value='';document.getElementById('f_type').value='discount';document.getElementById('f_pct').value='';document.getElementById('f_amt').value='';document.getElementById('f_min').value='0';document.getElementById('f_start').value='';document.getElementById('f_end').value='';document.getElementById('f_status').value='active';document.getElementById('modalTitle').textContent='Add Promotion';"><i class="fas fa-plus"></i> Add Promotion</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>Name</th><th>Type</th><th>Discount</th><th>Min</th><th>Period</th><th>Status</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($promos as $p): ?>
<tr><td><strong><?= htmlspecialchars($p['name']) ?></strong></td><td><span class="badge bg-info"><?= ucfirst($p['promotion_type']) ?></span></td>
<td><?= $p['discount_percent']>0?$p['discount_percent'].'%':''.formatPrice($p['discount_amount']) ?></td>
<td><?= formatPrice($p['min_purchase']) ?></td>
<td class="small"><?= $p['start_date'] ?> to <?= $p['end_date'] ?></td>
<td><span class="badge bg-<?= $p['status']=='active'?'success':'secondary' ?>"><?= ucfirst($p['status']) ?></span></td>
<td><button class="btn btn-sm btn-warning" onclick="document.getElementById('f_id').value='<?= $p['id'] ?>';document.getElementById('f_name').value='<?= htmlspecialchars($p['name']) ?>';document.getElementById('f_type').value='<?= $p['promotion_type'] ?>';document.getElementById('f_pct').value='<?= $p['discount_percent'] ?>';document.getElementById('f_amt').value='<?= $p['discount_amount'] ?>';document.getElementById('f_min').value='<?= $p['min_purchase'] ?>';document.getElementById('f_start').value='<?= $p['start_date'] ?>';document.getElementById('f_end').value='<?= $p['end_date'] ?>';document.getElementById('f_status').value='<?= $p['status'] ?>';document.getElementById('modalTitle').textContent='Edit Promotion';new bootstrap.Modal(document.getElementById('modal')).show();"><i class="fas fa-edit"></i></button> <a href="?delete=<?= $p['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Promotion</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" id="f_name" class="form-control" required></div>
<div class="row g-3 mb-3"><div class="col-6"><label class="form-label">Type</label><select name="promotion_type" id="f_type" class="form-select"><option value="discount">Percentage Discount</option><option value="flat">Flat Discount</option><option value="flash">Flash Sale</option><option value="clearance">Clearance</option><option value="bundle">Bundle</option></select></div>
<div class="col-6"><label class="form-label">Status</label><select name="status" id="f_status" class="form-select"><option value="active">Active</option><option value="inactive">Inactive</option><option value="expired">Expired</option></select></div></div>
<div class="row g-3 mb-3"><div class="col-6"><label class="form-label">Discount %</label><input type="number" step="0.1" name="discount_percent" id="f_pct" class="form-control"></div>
<div class="col-6"><label class="form-label">Discount Amount</label><input type="number" step="0.01" name="discount_amount" id="f_amt" class="form-control"></div></div>
<div class="mb-3"><label class="form-label">Min Purchase</label><input type="number" step="0.01" name="min_purchase" id="f_min" class="form-control"></div>
<div class="row g-3"><div class="col-6"><label class="form-label">Start Date</label><input type="datetime-local" name="start_date" id="f_start" class="form-control" required></div>
<div class="col-6"><label class="form-label">End Date</label><input type="datetime-local" name="end_date" id="f_end" class="form-control" required></div></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
