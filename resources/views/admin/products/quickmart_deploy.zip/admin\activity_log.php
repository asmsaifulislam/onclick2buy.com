<?php
$pageTitle = 'Activity Log';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['clear'])) { query("DELETE FROM activity_log"); setAlert('success', 'Log cleared.'); redirect(SITE_URL . '/admin/activity_log.php'); }
$page = max(1, (int)($_GET['p'] ?? 1));
$perPage = 50;
$offset = ($page - 1) * $perPage;
$total = count_rows("SELECT COUNT(*) FROM activity_log");
$logs = fetchAll("SELECT al.*, u.username FROM activity_log al LEFT JOIN users u ON al.user_id=u.id ORDER BY al.created_at DESC LIMIT ? OFFSET ?", [$perPage, $offset]);
$totalPages = ceil($total / $perPage);
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Activity Log (<?= $total ?> entries)</h4>
    <a href="?clear=1" class="btn btn-danger" onclick="return confirm('Clear all logs?')"><i class="fas fa-trash"></i> Clear Log</a>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>Date</th><th>User</th><th>Action</th><th>Details</th><th>IP</th></tr></thead>
<tbody><?php foreach ($logs as $l): ?>
<tr><td class="small"><?= $l['created_at'] ?></td><td><?= htmlspecialchars($l['username'] ?? 'System') ?></td>
<td><span class="badge bg-secondary"><?= htmlspecialchars($l['action']) ?></span></td>
<td class="small"><?= htmlspecialchars($l['details']) ?></td><td class="small"><?= $l['ip_address'] ?></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<?php if ($totalPages > 1): ?>
<nav><ul class="pagination justify-content-center">
<?php for ($i = max(1,$page-3); $i <= min($totalPages,$page+3); $i++): ?>
<li class="page-item <?= $i==$page?'active':'' ?>"><a class="page-link" href="?p=<?= $i ?>"><?= $i ?></a></li>
<?php endfor; ?></ul></nav>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
