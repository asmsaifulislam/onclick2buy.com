<?php
$pageTitle = 'Manage Blog';
require_once __DIR__ . '/../includes/admin_header.php';

if (isset($_GET['delete'])) {
    query("DELETE FROM blog_posts WHERE id=?", [(int)$_GET['delete']]);
    setAlert('success', 'Post deleted.');
    redirect(SITE_URL . '/admin/blog.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $title = $_POST['title'];
    $slug = slugify($title);
    $content = $_POST['content'];
    if ($id) {
        query("UPDATE blog_posts SET title=?, slug=?, content=? WHERE id=?", [$title, $slug, $content, $id]);
        setAlert('success', 'Post updated!');
    } else {
        query("INSERT INTO blog_posts (title, slug, content) VALUES (?,?,?)", [$title, $slug, $content]);
        setAlert('success', 'Post added!');
    }
    redirect(SITE_URL . '/admin/blog.php');
}

$posts = fetchAll("SELECT * FROM blog_posts ORDER BY created_at DESC");
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Blog Posts (<?= count($posts) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#blogModal" onclick="document.getElementById('bp_id').value='';document.getElementById('bp_title').value='';document.getElementById('bp_content').value='';document.getElementById('blogModalTitle').textContent='Add Post';">
        <i class="fas fa-plus"></i> Add Post
    </button>
</div>

<div class="card card-custom">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-custom">
                <thead><tr><th>ID</th><th>Title</th><th>Published</th><th>Date</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($posts as $p): ?>
                    <tr>
                        <td><?= $p['id'] ?></td>
                        <td><strong><?= htmlspecialchars($p['title']) ?></strong></td>
                        <td><span class="badge bg-<?= $p['is_published'] ? 'success' : 'secondary' ?>"><?= $p['is_published'] ? 'Yes' : 'No' ?></span></td>
                        <td><?= date('M d, Y', strtotime($p['created_at'])) ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning" onclick="document.getElementById('bp_id').value='<?= $p['id'] ?>';document.getElementById('bp_title').value='<?= htmlspecialchars($p['title']) ?>';document.getElementById('bp_content').value=<?= json_encode($p['content']) ?>;document.getElementById('blogModalTitle').textContent='Edit Post';new bootstrap.Modal(document.getElementById('blogModal')).show();"><i class="fas fa-edit"></i></button>
                            <a href="?delete=<?= $p['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="blogModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-dark">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="blogModalTitle">Add Post</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="bp_id">
                    <div class="mb-3"><label class="form-label">Title</label><input type="text" name="title" id="bp_title" class="form-control" required></div>
                    <div class="mb-3"><label class="form-label">Content</label><textarea name="content" id="bp_content" class="form-control" rows="8" required></textarea></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
