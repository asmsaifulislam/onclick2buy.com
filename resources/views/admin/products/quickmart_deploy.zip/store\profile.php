<?php
$pageTitle = 'My Profile - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');

$user = fetch("SELECT * FROM users WHERE id=?", [$_SESSION['user_id']]);
$profile = fetch("SELECT * FROM profiles WHERE user_id=?", [$_SESSION['user_id']]);
$orders = count_rows("SELECT COUNT(*) FROM orders WHERE user_id=?", [$_SESSION['user_id']]);
$totalSpent = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE user_id=? AND payment_status='completed'", [$_SESSION['user_id']]);
$wishlistCount = count_rows("SELECT COUNT(*) FROM wishlist WHERE user_id=?", [$_SESSION['user_id']]);
$lp = fetch("SELECT points FROM loyalty_points WHERE user_id=?", [$_SESSION['user_id']]);
$wallet = fetch("SELECT balance FROM wallets WHERE user_id=?", [$_SESSION['user_id']]);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $city = trim($_POST['city'] ?? '');

    if ($name && $email) {
        query("UPDATE users SET username=? WHERE id=?", [$name, $_SESSION['user_id']]);
        if ($profile) {
            query("UPDATE profiles SET phone=?, address=?, city=? WHERE user_id=?", [$phone, $address, $city, $_SESSION['user_id']]);
        } else {
            query("INSERT INTO profiles (user_id, phone, address, city) VALUES (?,?,?,?)", [$_SESSION['user_id'], $phone, $address, $city]);
        }
        $_SESSION['username'] = $name;
        setAlert('success', 'Profile updated successfully!');
        redirect(SITE_URL . '/store/profile.php');
    }
}
?>

<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card card-custom p-4 text-center">
            <div class="rounded-circle bg-primary d-inline-flex align-items-center justify-content-center mb-3" style="width:80px;height:80px;">
                <i class="fas fa-user fa-2x text-white"></i>
            </div>
            <h5><?= htmlspecialchars($_SESSION['username']) ?></h5>
            <p class="text-muted small"><?= htmlspecialchars($user['email']) ?></p>
            <p class="text-muted small">Member since <?= date('M Y', strtotime($user['created_at'])) ?></p>
        </div>
        <div class="row g-2 mt-3">
            <div class="col-6">
                <div class="card card-custom p-3 text-center">
                    <h4 class="text-primary mb-0"><?= $orders ?></h4>
                    <small class="text-muted">Orders</small>
                </div>
            </div>
            <div class="col-6">
                <div class="card card-custom p-3 text-center">
                    <h4 class="text-success mb-0"><?= formatPrice($totalSpent) ?></h4>
                    <small class="text-muted">Spent</small>
                </div>
            </div>
            <div class="col-6">
                <div class="card card-custom p-3 text-center">
                    <h4 class="text-danger mb-0"><?= $wishlistCount ?></h4>
                    <small class="text-muted">Wishlist</small>
                </div>
            </div>
            <div class="col-6">
                <div class="card card-custom p-3 text-center">
                    <h4 class="text-warning mb-0"><?= number_format($lp['points'] ?? 0) ?></h4>
                    <small class="text-muted">Points</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card card-custom p-4">
            <h5 class="mb-3"><i class="fas fa-edit"></i> Edit Profile</h5>
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Full Name</label>
                        <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($_SESSION['username']) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Email</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Phone</label>
                        <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($profile['phone'] ?? '') ?>" placeholder="01XXXXXXXXX">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">City</label>
                        <select name="city" class="form-select">
                            <option value="">Select City</option>
                            <?php foreach (['Dhaka','Chittagong','Sylhet','Rajshahi','Khulna','Barisal','Rangpur','Mymensingh'] as $c): ?>
                            <option value="<?= $c ?>" <?= ($profile['city'] ?? '') == $c ? 'selected' : '' ?>><?= $c ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-bold">Address</label>
                        <textarea name="address" class="form-control" rows="2" placeholder="House #, Road #, Area"><?= htmlspecialchars($profile['address'] ?? '') ?></textarea>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
