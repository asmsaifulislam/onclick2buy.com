    </div>
</div>

<script>
// Sidebar Toggle
document.getElementById('toggle-sidebar')?.addEventListener('click', function() {
    document.getElementById('sidebar').classList.toggle('show');
    document.getElementById('sidebar-overlay').classList.toggle('active');
});
document.getElementById('sidebar-overlay')?.addEventListener('click', function() {
    document.getElementById('sidebar').classList.remove('show');
    this.classList.remove('active');
});

// Page Loading Overlay
var ld = '<div id="pageLoader" style="position:fixed;top:0;left:0;width:100%;height:100%;background:#0f0c29;z-index:99999;display:flex;align-items:center;justify-content:center;transition:opacity .4s;opacity:1"><div style="text-align:center"><div style="width:40px;height:40px;border:3px solid rgba(233,69,96,0.2);border-top-color:#e94560;border-radius:50%;animation:aspin .8s linear infinite;margin:0 auto 12px"></div><p style="color:#e94560;font-size:.85rem;font-weight:600">Loading...</p></div></div><style>@keyframes aspin{to{transform:rotate(360deg)}}</style>';
document.body.insertAdjacentHTML('beforeend', ld);
window.addEventListener('load', function() {
    var l = document.getElementById('pageLoader');
    if (l) { l.style.opacity = '0'; setTimeout(function(){ l.remove(); }, 400); }
});

// Form submit loading
document.querySelectorAll('form').forEach(function(f) {
    f.addEventListener('submit', function() {
        var b = this.querySelector('button[type="submit"]');
        if (b && !b.classList.contains('no-loading')) {
            var o = b.innerHTML;
            b.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            b.disabled = true;
            setTimeout(function(){ b.innerHTML = o; b.disabled = false; }, 5000);
        }
    });
});

// Image error fallback
document.querySelectorAll('img').forEach(function(img) {
    img.addEventListener('error', function() {
        this.onerror = null;
        this.src = '<?= SITE_URL ?>/assets/images/no-image.svg';
    });
});
</script>
<script src="<?= SITE_URL ?>/assets/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
