<?php
$pageTitle = 'Wishlist - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
if (!isLoggedIn()) redirect(SITE_URL . '/store/login.php');

$wishlist = fetchAll("SELECT w.*, p.name, p.price, p.slug, p.stock FROM wishlist w JOIN products p ON w.product_id=p.id WHERE w.user_id=? ORDER BY w.created_at DESC", [$_SESSION['user_id']]);
?>

<h2 class="mb-4"><i class="fas fa-heart"></i> My Wishlist</h2>

<?php if (empty($wishlist)): ?>
<div class="text-center py-5">
    <i class="fas fa-heart-broken fa-4x text-muted mb-3"></i>
    <h5>Your wishlist is empty</h5>
    <a href="<?= SITE_URL ?>/store/products.php" class="btn btn-primary mt-3">Browse Products</a>
</div>
<?php else: ?>
<div class="row g-4">
    <?php foreach ($wishlist as $item): ?>
    <div class="col-6 col-md-4 col-lg-3">
        <div class="card h-100 card-custom">
            <div class="card-body">
                <h6><?= htmlspecialchars($item['name']) ?></h6>
                <h5 class="text-primary"><?= formatPrice($item['price']) ?></h5>
                <div class="d-flex gap-1 mt-2 flex-wrap">
                    <a href="<?= SITE_URL ?>/store/product.php?slug=<?= $item['slug'] ?>" class="btn btn-sm btn-outline-primary flex-grow-1">View</a>
                    <button class="btn btn-sm btn-primary add-to-cart-btn" data-id="<?= $item['product_id'] ?>">
                        <i class="fas fa-cart-plus"></i>
                    </button>
                    <button class="buy-now-btn buy-now-btn-sm" data-id="<?= $item['product_id'] ?>" title="Buy Now">
                        <i class="fas fa-bolt"></i>
                    </button>
                    <form method="POST" action="<?= SITE_URL ?>/api/wishlist.php" style="display:inline">
                        <input type="hidden" name="action" value="remove">
                        <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                        <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
