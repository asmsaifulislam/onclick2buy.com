<?php
$pageTitle = 'Reports';
require_once __DIR__ . '/../includes/admin_header.php';

$report = $_GET['report'] ?? 'overview';

// Overview Stats
$totalRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled'");
$totalOrders = count_rows("SELECT COUNT(*) FROM orders");
$avgOrder = $totalOrders > 0 ? $totalRevenue / $totalOrders : 0;
$topProducts = fetchAll("SELECT p.name, p.price, p.total_reviews, p.average_rating FROM products p ORDER BY p.total_reviews DESC LIMIT 5");
$catSales = fetchAll("SELECT c.name, COUNT(o.id) as order_count, COALESCE(SUM(o.total),0) as revenue FROM categories c LEFT JOIN products p ON c.id=p.category_id LEFT JOIN order_items oi ON p.id=oi.product_id LEFT JOIN orders o ON oi.order_id=o.id AND o.status != 'cancelled' GROUP BY c.id ORDER BY revenue DESC");
$statusCounts = fetchAll("SELECT status, COUNT(*) as cnt FROM orders GROUP BY status");
$paymentCounts = fetchAll("SELECT payment_method, COUNT(*) as cnt FROM orders GROUP BY payment_method");
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Reports</h4>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card card-custom p-3 text-center">
            <h3 class="text-success"><?= formatPrice($totalRevenue) ?></h3>
            <p class="text-muted mb-0">Total Revenue</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card card-custom p-3 text-center">
            <h3 class="text-primary"><?= $totalOrders ?></h3>
            <p class="text-muted mb-0">Total Orders</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card card-custom p-3 text-center">
            <h3 class="text-info"><?= formatPrice($avgOrder) ?></h3>
            <p class="text-muted mb-0">Avg Order Value</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card card-custom p-3 text-center">
            <h3 class="text-warning"><?= count_rows("SELECT COUNT(*) FROM products WHERE stock < 10") ?></h3>
            <p class="text-muted mb-0">Low Stock Products</p>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h5>Top Products (by reviews)</h5>
            <table class="table table-sm">
                <thead><tr><th>Product</th><th>Price</th><th>Rating</th><th>Reviews</th></tr></thead>
                <tbody>
                    <?php foreach ($topProducts as $p): ?>
                    <tr><td><?= htmlspecialchars($p['name']) ?></td><td><?= formatPrice($p['price']) ?></td><td><?= $p['average_rating'] ?></td><td><?= $p['total_reviews'] ?></td></tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h5>Category Sales</h5>
            <table class="table table-sm">
                <thead><tr><th>Category</th><th>Orders</th><th>Revenue</th></tr></thead>
                <tbody>
                    <?php foreach ($catSales as $c): ?>
                    <tr><td><?= htmlspecialchars($c['name']) ?></td><td><?= $c['order_count'] ?></td><td><?= formatPrice($c['revenue']) ?></td></tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h5>Order Status Breakdown</h5>
            <?php foreach ($statusCounts as $s): ?>
            <div class="d-flex justify-content-between mb-2">
                <span class="badge bg-<?= $s['status']=='pending'?'warning':($s['status']=='delivered'?'success':($s['status']=='cancelled'?'danger':'info')) ?>"><?= ucfirst($s['status']) ?></span>
                <span><strong><?= $s['cnt'] ?></strong> orders</span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card card-custom p-4">
            <h5>Payment Methods</h5>
            <?php foreach ($paymentCounts as $p): ?>
            <div class="d-flex justify-content-between mb-2">
                <span class="badge bg-info"><?= strtoupper($p['payment_method']) ?></span>
                <span><strong><?= $p['cnt'] ?></strong> orders</span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
