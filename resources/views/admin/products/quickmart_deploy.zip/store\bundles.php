<?php
$pageTitle = 'Bundles - Quick Mart';
require_once __DIR__ . '/../includes/header.php';
$bundles = fetchAll("SELECT b.*, GROUP_CONCAT(p.name, ', ') as product_names, COUNT(bp.id) as product_count FROM bundles b LEFT JOIN bundle_products bp ON b.id=bp.bundle_id LEFT JOIN products p ON bp.product_id=p.id WHERE b.is_active=1 GROUP BY b.id ORDER BY b.created_at DESC");
?>
<h2 class="mb-4"><i class="fas fa-layer-group"></i> Product Bundles</h2>
<p class="text-muted mb-4">Save more when you buy in bundles!</p>
<?php if (empty($bundles)): ?>
<div class="text-center py-5"><i class="fas fa-layer-group fa-4x text-muted mb-3" style="opacity:0.3"></i><h5>No bundles available yet</h5></div>
<?php else: ?>
<div class="row g-4">
    <?php foreach ($bundles as $b): ?>
    <div class="col-md-4">
        <div class="card card-custom p-4 h-100">
            <span class="badge bg-success mb-2"><?= $b['product_count'] ?> Products</span>
            <h5><?= htmlspecialchars($b['name']) ?></h5>
            <p class="text-muted small"><?= htmlspecialchars($b['description'] ?? '') ?></p>
            <p class="text-muted small"><i class="fas fa-box"></i> <?= htmlspecialchars($b['product_names'] ?? '') ?></p>
            <h4 class="text-primary mt-auto"><?= formatPrice($b['bundle_price']) ?></h4>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
