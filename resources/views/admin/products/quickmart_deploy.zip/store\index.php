<?php
$pageTitle = 'Quick Mart - Your Premium Online Store';
require_once __DIR__ . '/../includes/header.php';
$categories = getCategories();
$featured = fetchAll("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.is_active=1 ORDER BY p.total_reviews DESC LIMIT 8");
$newArrivals = fetchAll("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.is_active=1 ORDER BY p.created_at DESC LIMIT 8");
$bestSellers = fetchAll("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.is_active=1 ORDER BY p.average_rating DESC LIMIT 8");
$adProducts = fetchAll("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.is_active=1 ORDER BY p.average_rating DESC, p.total_reviews DESC LIMIT 20");
$adProducts2 = fetchAll("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.is_active=1 ORDER BY p.created_at DESC, p.total_reviews DESC LIMIT 20");
$now = date('Y-m-d H:i:s');
$flashProducts = fetchAll("SELECT p.*, c.name as cat_name, fs.discount_percent FROM flash_sales fs JOIN flash_sale_products fsp ON fs.id=fsp.flash_sale_id JOIN products p ON fsp.product_id=p.id LEFT JOIN categories c ON p.category_id=c.id WHERE fs.is_active=1 AND fs.start_date<=? AND fs.end_date>=? LIMIT 10", [$now, $now]);
?>

<!-- ═══════ HERO SLIDER ═══════ -->
<section class="hero-slider mb-5">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="2"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="3"></button>
        </div>
        <div class="carousel-inner">

            <!-- Slide 1: Summer Collection -->
            <div class="carousel-item active">
                <div class="hero-slide" style="background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);">
                    <div class="hero-shapes">
                        <div class="hero-shape shape-circle" style="width:300px;height:300px;top:-80px;right:10%;background:radial-gradient(circle,rgba(233,69,96,0.3),transparent 70%);"></div>
                        <div class="hero-shape shape-circle" style="width:200px;height:200px;bottom:-40px;left:5%;background:radial-gradient(circle,rgba(102,126,234,0.25),transparent 70%);"></div>
                        <div class="hero-shape shape-ring" style="width:160px;height:160px;top:20%;right:25%;border:2px solid rgba(255,255,255,0.08);"></div>
                        <div class="hero-shape shape-dot" style="width:8px;height:8px;top:30%;left:15%;background:rgba(233,69,96,0.6);"></div>
                        <div class="hero-shape shape-dot" style="width:6px;height:6px;bottom:35%;right:30%;background:rgba(102,126,234,0.5);"></div>
                    </div>
                    <div class="container position-relative" style="z-index:2;">
                        <div class="row align-items-center">
                            <div class="col-lg-7">
                                <div class="hero-anim">
                                    <span class="hero-badge badge-animated"><i class="fas fa-fire"></i> Summer '26</span>
                                    <h1 class="hero-title">Shop the<br><span class="text-gradient">Trend</span></h1>
                                    <p class="hero-subtitle">Discover our curated Summer Collection — fresh styles, hot deals, delivered free across Bangladesh.</p>
                                    <div class="hero-cta-row">
                                        <a href="<?= SITE_URL ?>/store/products.php" class="hero-btn hero-btn-glow"><i class="fas fa-shopping-bag"></i> Shop Collection</a>
                                        <a href="<?= SITE_URL ?>/store/flash_sale.php" class="hero-btn hero-btn-ghost"><i class="fas fa-bolt"></i> Flash Sales</a>
                                    </div>
                                    <div class="hero-stats">
                                        <div class="hero-stat"><span class="hero-stat-num">96+</span><span class="hero-stat-label">Products</span></div>
                                        <div class="hero-stat-divider"></div>
                                        <div class="hero-stat"><span class="hero-stat-num">40%</span><span class="hero-stat-label">Off Today</span></div>
                                        <div class="hero-stat-divider"></div>
                                        <div class="hero-stat"><span class="hero-stat-num">Free</span><span class="hero-stat-label">Delivery</span></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 text-center d-none d-lg-block">
                                <div class="hero-visual hero-visual-float">
                                    <div class="hero-visual-card">
                                        <div class="hero-visual-icon"><i class="fas fa-tshirt"></i></div>
                                        <div class="hero-visual-label">Fashion</div>
                                    </div>
                                    <div class="hero-visual-card hero-visual-card-sm" style="top:10%;right:-10px;">
                                        <div class="hero-visual-icon"><i class="fas fa-star"></i></div>
                                    </div>
                                    <div class="hero-visual-card hero-visual-card-sm" style="bottom:15%;left:-15px;">
                                        <div class="hero-visual-icon"><i class="fas fa-truck"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 2: Flash Sale -->
            <div class="carousel-item">
                <div class="hero-slide" style="background: linear-gradient(135deg, #e94560 0%, #ff6b81 50%, #ff8a5c 100%);">
                    <div class="hero-shapes">
                        <div class="hero-shape shape-circle" style="width:350px;height:350px;top:-100px;left:5%;background:radial-gradient(circle,rgba(255,255,255,0.15),transparent 70%);"></div>
                        <div class="hero-shape shape-circle" style="width:200px;height:200px;bottom:-60px;right:10%;background:radial-gradient(circle,rgba(0,0,0,0.1),transparent 70%);"></div>
                        <div class="hero-shape shape-ring" style="width:120px;height:120px;top:15%;right:20%;border:2px solid rgba(255,255,255,0.15);"></div>
                        <div class="hero-shape shape-dot" style="width:10px;height:10px;top:25%;right:35%;background:rgba(255,255,255,0.4);"></div>
                        <div class="hero-shape shape-dot" style="width:6px;height:6px;bottom:40%;left:20%;background:rgba(255,255,255,0.3);"></div>
                    </div>
                    <div class="container position-relative" style="z-index:2;">
                        <div class="row align-items-center">
                            <div class="col-lg-7">
                                <div class="hero-anim">
                                    <span class="hero-badge hero-badge-white badge-animated"><i class="fas fa-bolt"></i> FLASH SALE</span>
                                    <h1 class="hero-title" style="color:#fff;">Up to <span class="text-gradient-white">50% Off</span></h1>
                                    <p class="hero-subtitle" style="color:rgba(255,255,255,0.85);">Thousands of products at unbeatable prices. Hurry — ends soon!</p>
                                    <div class="hero-countdown" id="heroCountdown">
                                        <div class="countdown-item"><span class="countdown-num" id="cd-days">11</span><span class="countdown-label">Days</span></div>
                                        <div class="countdown-item"><span class="countdown-num" id="cd-hours">05</span><span class="countdown-label">Hrs</span></div>
                                        <div class="countdown-item"><span class="countdown-num" id="cd-mins">21</span><span class="countdown-label">Min</span></div>
                                        <div class="countdown-item"><span class="countdown-num" id="cd-secs">19</span><span class="countdown-label">Sec</span></div>
                                    </div>
                                    <div class="hero-cta-row mt-3">
                                        <a href="<?= SITE_URL ?>/store/flash_sale.php" class="hero-btn hero-btn-white"><i class="fas fa-tags"></i> Grab Deals Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 text-center d-none d-lg-block">
                                <div class="hero-visual hero-visual-float">
                                    <div class="hero-visual-card hero-visual-card-white">
                                        <div class="hero-visual-icon"><i class="fas fa-percentage"></i></div>
                                        <div class="hero-visual-label">50% OFF</div>
                                    </div>
                                    <div class="hero-visual-card hero-visual-card-sm hero-visual-card-white" style="top:5%;right:-10px;">
                                        <div class="hero-visual-icon"><i class="fas fa-clock"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 3: Accessories -->
            <div class="carousel-item">
                <div class="hero-slide" style="background: linear-gradient(135deg, #0d7377 0%, #14b8a6 50%, #5eead4 100%);">
                    <div class="hero-shapes">
                        <div class="hero-shape shape-circle" style="width:280px;height:280px;top:-60px;right:15%;background:radial-gradient(circle,rgba(255,255,255,0.15),transparent 70%);"></div>
                        <div class="hero-shape shape-ring" style="width:180px;height:180px;bottom:10%;left:10%;border:2px solid rgba(255,255,255,0.1);"></div>
                        <div class="hero-shape shape-dot" style="width:8px;height:8px;top:35%;left:12%;background:rgba(255,255,255,0.5);"></div>
                        <div class="hero-shape shape-dot" style="width:6px;height:6px;bottom:25%;right:25%;background:rgba(255,255,255,0.4);"></div>
                    </div>
                    <div class="container position-relative" style="z-index:2;">
                        <div class="row align-items-center">
                            <div class="col-lg-7">
                                <div class="hero-anim">
                                    <span class="hero-badge hero-badge-white badge-animated"><i class="fas fa-gem"></i> Complete Your Look</span>
                                    <h1 class="hero-title" style="color:#fff;">Accessories<br><span class="text-gradient-teal">That Shine</span></h1>
                                    <p class="hero-subtitle" style="color:rgba(255,255,255,0.85);">Watches, bags, jewelry & more — elevate every outfit with the perfect accessory.</p>
                                    <div class="hero-cta-row">
                                        <a href="<?= SITE_URL ?>/store/products.php" class="hero-btn hero-btn-white"><i class="fas fa-shopping-bag"></i> Explore Accessories</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 text-center d-none d-lg-block">
                                <div class="hero-visual hero-visual-float">
                                    <div class="hero-visual-card hero-visual-card-white">
                                        <div class="hero-visual-icon"><i class="fas fa-clock"></i></div>
                                        <div class="hero-visual-label">Watches</div>
                                    </div>
                                    <div class="hero-visual-card hero-visual-card-white" style="top:10%;right:-15px;">
                                        <div class="hero-visual-icon"><i class="fas fa-gem"></i></div>
                                    </div>
                                    <div class="hero-visual-card hero-visual-card-sm hero-visual-card-white" style="bottom:20%;left:-10px;">
                                        <div class="hero-visual-icon"><i class="fas fa-shopping-bag"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 4: Free Delivery -->
            <div class="carousel-item">
                <div class="hero-slide" style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);">
                    <div class="hero-shapes">
                        <div class="hero-shape shape-circle" style="width:320px;height:320px;top:-80px;left:10%;background:radial-gradient(circle,rgba(233,69,96,0.2),transparent 70%);"></div>
                        <div class="hero-shape shape-circle" style="width:200px;height:200px;bottom:-50px;right:15%;background:radial-gradient(circle,rgba(94,234,212,0.15),transparent 70%);"></div>
                        <div class="hero-shape shape-ring" style="width:140px;height:140px;top:25%;right:18%;border:2px solid rgba(233,69,96,0.15);"></div>
                        <div class="hero-shape shape-dot" style="width:8px;height:8px;top:20%;left:25%;background:rgba(233,69,96,0.5);"></div>
                        <div class="hero-shape shape-dot" style="width:6px;height:6px;bottom:30%;right:35%;background:rgba(94,234,212,0.4);"></div>
                    </div>
                    <div class="container position-relative" style="z-index:2;">
                        <div class="row align-items-center">
                            <div class="col-lg-7">
                                <div class="hero-anim">
                                    <span class="hero-badge badge-animated" style="background:rgba(94,234,212,0.2);color:#5eead4;border:1px solid rgba(94,234,212,0.3);"><i class="fas fa-truck"></i> FREE DELIVERY</span>
                                    <h1 class="hero-title" style="color:#fff;">Shop Anywhere<br><span class="text-gradient-accent">Across Bangladesh</span></h1>
                                    <p class="hero-subtitle" style="color:rgba(255,255,255,0.7);">Free shipping on all orders over ৳2,000. Fast, reliable delivery to your doorstep.</p>
                                    <div class="hero-cta-row">
                                        <a href="<?= SITE_URL ?>/store/products.php" class="hero-btn hero-btn-glow"><i class="fas fa-rocket"></i> Start Shopping</a>
                                        <a href="<?= SITE_URL ?>/store/order_tracking.php" class="hero-btn hero-btn-ghost"><i class="fas fa-truck"></i> Track Order</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 text-center d-none d-lg-block">
                                <div class="hero-visual hero-visual-float">
                                    <div class="hero-visual-card" style="background:linear-gradient(135deg,rgba(233,69,96,0.2),rgba(233,69,96,0.05));border:1px solid rgba(233,69,96,0.2);">
                                        <div class="hero-visual-icon" style="color:#e94560;"><i class="fas fa-truck-fast"></i></div>
                                        <div class="hero-visual-label" style="color:#e94560;">Free Ship</div>
                                    </div>
                                    <div class="hero-visual-card hero-visual-card-sm" style="background:rgba(94,234,212,0.1);border:1px solid rgba(94,234,212,0.2);top:10%;right:-10px;">
                                        <div class="hero-visual-icon" style="color:#5eead4;"><i class="fas fa-shield-halved"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span></button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next"><span class="carousel-control-next-icon"></span></button>
    </div>
</section>

<!-- ═══════ PRODUCT AD STRIP — Auto-Scroll ═══════ -->
<?php if (!empty($adProducts)): ?>
<section class="product-ad-strip-section mb-5">
    <div class="container-fluid px-0">
        <div class="d-flex justify-content-between align-items-center px-4 mb-3">
            <h4 class="mb-0 fw-bold"><i class="fas fa-fire text-danger"></i> Recommended for You</h4>
            <a href="<?= SITE_URL ?>/store/products.php" class="btn btn-outline-primary btn-sm">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="product-ad-track" id="adTrack1" onmouseenter="pauseScroll(this)" onmouseleave="resumeScroll(this)">
            <div class="product-ad-inner">
                <?php foreach (array_merge($adProducts, $adProducts) as $p): ?>
                <div class="product-ad-card">
                    <a href="<?= SITE_URL ?>/store/product.php?slug=<?= $p['slug'] ?>">
                        <div class="product-ad-img">
                            <?php if (!empty($p['image'])): ?>
                            <img src="<?= SITE_URL ?>/<?= $p['image'] ?>" alt="<?= htmlspecialchars($p['name']) ?>" loading="lazy">
                            <?php else: ?>
                            <div class="product-ad-placeholder"><i class="fas fa-image fa-2x text-muted"></i></div>
                            <?php endif; ?>
                        </div>
                        <div class="product-ad-info">
                            <h6><?= htmlspecialchars(substr($p['name'], 0, 40)) ?><?= strlen($p['name']) > 40 ? '...' : '' ?></h6>
                            <div class="product-ad-price">
                                <span class="price-now"><?= formatPrice($p['price']) ?></span>
                            </div>
                            <div class="product-ad-rating">
                                <?php for ($i = 0; $i < 5; $i++): ?>
                                <i class="fas fa-star <?= $i < round($p['average_rating']) ? 'text-warning' : 'text-muted' ?>"></i>
                                <?php endfor; ?>
                                <small>(<?= $p['total_reviews'] ?>)</small>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if (!empty($flashProducts)): ?>
<!-- ═══════ FLASH SALE BANNER ═══════ -->
<section class="flash-sale-banner mb-5 reveal">
    <div class="container">
        <div class="flash-banner-inner">
            <div class="flash-banner-content">
                <h3><i class="fas fa-bolt"></i> Flash Sale is LIVE! <i class="fas fa-bolt"></i></h3>
                <p>Hurry up! Deals end soon.</p>
            </div>
            <div class="flash-timer" id="flashTimer">
                <div class="timer-box"><span id="cd-days">00</span><small>Days</small></div>
                <div class="timer-box"><span id="cd-hours">00</span><small>Hrs</small></div>
                <div class="timer-box"><span id="cd-mins">00</span><small>Min</small></div>
                <div class="timer-box"><span id="cd-secs">00</span><small>Sec</small></div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if (!empty($adProducts2)): ?>
<!-- ═══════ PRODUCT AD STRIP 2 — Best Deals ═══════ -->
<section class="product-ad-strip-section mb-5">
    <div class="container-fluid px-0">
        <div class="d-flex justify-content-between align-items-center px-4 mb-3">
            <h4 class="mb-0 fw-bold"><i class="fas fa-tags text-primary"></i> Best Deals</h4>
            <a href="<?= SITE_URL ?>/store/products.php" class="btn btn-outline-primary btn-sm">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="product-ad-track reverse" id="adTrack2" onmouseenter="pauseScroll(this)" onmouseleave="resumeScroll(this)">
            <div class="product-ad-inner reverse">
                <?php foreach (array_merge($adProducts2, $adProducts2) as $p): ?>
                <div class="product-ad-card">
                    <a href="<?= SITE_URL ?>/store/product.php?slug=<?= $p['slug'] ?>">
                        <div class="product-ad-img">
                            <?php if (!empty($p['image'])): ?>
                            <img src="<?= SITE_URL ?>/<?= $p['image'] ?>" alt="<?= htmlspecialchars($p['name']) ?>" loading="lazy">
                            <?php else: ?>
                            <div class="product-ad-placeholder"><i class="fas fa-image fa-2x text-muted"></i></div>
                            <?php endif; ?>
                        </div>
                        <div class="product-ad-info">
                            <h6><?= htmlspecialchars(substr($p['name'], 0, 40)) ?><?= strlen($p['name']) > 40 ? '...' : '' ?></h6>
                            <div class="product-ad-price">
                                <span class="price-now"><?= formatPrice($p['price']) ?></span>
                            </div>
                            <div class="product-ad-rating">
                                <?php for ($i = 0; $i < 5; $i++): ?>
                                <i class="fas fa-star <?= $i < round($p['average_rating']) ? 'text-warning' : 'text-muted' ?>"></i>
                                <?php endfor; ?>
                                <small>(<?= $p['total_reviews'] ?>)</small>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="mb-5">
    <div class="container">
        <h3 class="mb-4">Shop by Category</h3>
        <div class="row g-3">
            <?php foreach ($categories as $cat): ?>
            <div class="col-6 col-md-4 col-lg-2">
                <a href="<?= SITE_URL ?>/store/products.php?category=<?= $cat['slug'] ?>" class="text-decoration-none">
                    <div class="card text-center p-3 h-100 card-custom">
                        <i class="fas fa-folder fa-2x text-primary mb-2"></i>
                        <h6 class="mb-0"><?= htmlspecialchars($cat['name']) ?></h6>
                        <small class="text-muted"><?= $cat['product_count'] ?> products</small>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="mb-5">
    <div class="container">
        <h3 class="mb-4">Featured Products</h3>
        <div class="row g-4">
            <?php foreach ($featured as $p): ?>
            <div class="col-6 col-md-4 col-lg-3">
                <div class="card h-100 card-custom product-card" data-pid="<?= $p['id'] ?>">
                    <div class="card-body">
                        <div class="card-overlay">
                            <button class="overlay-btn overlay-btn-quickview" data-id="<?= $p['id'] ?>" title="Quick View"><i class="fas fa-eye"></i></button>
                            <button class="overlay-btn overlay-btn-wishlist add-to-wishlist-btn" data-id="<?= $p['id'] ?>" title="Add to Wishlist"><i class="far fa-heart"></i></button>
                        </div>
                        <span class="badge bg-primary mb-2"><?= htmlspecialchars($p['cat_name'] ?? '') ?></span>
                        <h6 class="card-title"><?= htmlspecialchars($p['name']) ?></h6>
                        <div class="mb-2">
                            <?php for ($i = 0; $i < 5; $i++): ?>
                            <i class="fas fa-star <?= $i < $p['average_rating'] ? 'text-warning' : 'text-muted' ?>" style="font-size:12px"></i>
                            <?php endfor; ?>
                            <small class="text-muted">(<?= $p['total_reviews'] ?>)</small>
                        </div>
                        <h5 class="text-primary mb-2"><?= formatPrice($p['price']) ?></h5>
                        <div class="d-flex gap-1 flex-wrap">
                            <a href="<?= SITE_URL ?>/store/product.php?slug=<?= $p['slug'] ?>" class="btn btn-sm btn-outline-primary flex-grow-1">View</a>
                            <button class="btn btn-sm btn-primary add-to-cart-btn" data-id="<?= $p['id'] ?>">
                                <i class="fas fa-cart-plus"></i>
                            </button>
                            <button class="buy-now-btn buy-now-btn-sm" data-id="<?= $p['id'] ?>" title="Buy Now">
                                <i class="fas fa-bolt"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="mb-5">
    <div class="container">
        <h3 class="mb-4">Best Sellers</h3>
        <div class="row g-4">
            <?php foreach ($bestSellers as $p): ?>
            <div class="col-6 col-md-4 col-lg-3">
                <div class="card h-100 card-custom product-card" data-pid="<?= $p['id'] ?>">
                    <div class="card-body">
                        <div class="card-overlay">
                            <button class="overlay-btn overlay-btn-quickview" data-id="<?= $p['id'] ?>" title="Quick View"><i class="fas fa-eye"></i></button>
                            <button class="overlay-btn overlay-btn-wishlist add-to-wishlist-btn" data-id="<?= $p['id'] ?>" title="Add to Wishlist"><i class="far fa-heart"></i></button>
                        </div>
                        <span class="badge bg-success mb-2"><?= htmlspecialchars($p['cat_name'] ?? '') ?></span>
                        <h6 class="card-title"><?= htmlspecialchars($p['name']) ?></h6>
                        <h5 class="text-primary mb-2"><?= formatPrice($p['price']) ?></h5>
                        <a href="<?= SITE_URL ?>/store/product.php?slug=<?= $p['slug'] ?>" class="btn btn-sm btn-outline-primary">View Details</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
(function() {
    var API = '<?= SITE_URL ?>/api/flash_countdown.php';
    var targetTime = 0;
    var timer = null;
    var banner = document.getElementById('flashTimer');
    var bannerSection = banner ? banner.closest('section') : null;

    var dEl = document.getElementById('cd-days');
    var hEl = document.getElementById('cd-hours');
    var mEl = document.getElementById('cd-mins');
    var sEl = document.getElementById('cd-secs');
    if (!banner) return;

    function pad(n) { return n < 10 ? '0' + n : n; }

    function flip(el, val) {
        if (!el) return;
        var text = pad(val);
        if (el.textContent !== text) {
            el.style.transform = 'rotateX(90deg)';
            setTimeout(function() {
                el.textContent = text;
                el.style.transform = 'rotateX(0deg)';
            }, 150);
        }
    }

    function tick() {
        var now = Date.now();
        var diff = targetTime - now;
        if (diff <= 0) {
            flip(dEl, 0); flip(hEl, 0); flip(mEl, 0); flip(sEl, 0);
            var p = bannerSection ? bannerSection.querySelector('.flash-banner-content p') : null;
            if (p) p.textContent = 'Sale has ended!';
            if (timer) clearInterval(timer);
            fetchFlash();
            return;
        }
        var d = Math.floor(diff / 86400000);
        var h = Math.floor((diff % 86400000) / 3600000);
        var m = Math.floor((diff % 3600000) / 60000);
        var s = Math.floor((diff % 60000) / 1000);
        flip(dEl, d);
        flip(hEl, h);
        flip(mEl, m);
        flip(sEl, s);
    }

    function fetchFlash() {
        fetch(API)
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (d.active && d.end_date) {
                    targetTime = new Date(d.end_date).getTime();
                    if (bannerSection) {
                        bannerSection.style.display = '';
                        var h3 = bannerSection.querySelector('h3');
                        var p = bannerSection.querySelector('.flash-banner-content p');
                        if (h3) h3.innerHTML = '<i class="fas fa-bolt"></i> ' + d.title + ' is LIVE! <i class="fas fa-bolt"></i>';
                        if (p) p.textContent = d.discount > 0 ? 'Up to ' + d.discount + '% off — Hurry up!' : 'Hurry up! Deals end soon.';
                    }
                    if (timer) clearInterval(timer);
                    tick();
                    timer = setInterval(tick, 1000);
                } else {
                    if (bannerSection) bannerSection.style.display = 'none';
                }
            })
            .catch(function() {});
    }

    fetchFlash();
    setInterval(fetchFlash, 60000);
})();
</script>
