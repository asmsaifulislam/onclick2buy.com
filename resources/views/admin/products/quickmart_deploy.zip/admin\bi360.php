<?php
$pageTitle = 'BI 360 Analytics';
require_once __DIR__ . '/../includes/admin_header.php';

$today = date('Y-m-d');
$monthStart = date('Y-m-01');
$lastMonthStart = date('Y-m-01', strtotime('-1 month'));
$lastMonthEnd = date('Y-m-t', strtotime('-1 month'));
$yearStart = date('Y-01-01');

$thisMonthRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND created_at >= ?", [$monthStart]);
$lastMonthRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND created_at >= ? AND created_at <= ?", [$lastMonthStart, $lastMonthEnd]);
$revenueChangePct = $lastMonthRevenue > 0 ? (($thisMonthRevenue - $lastMonthRevenue) / $lastMonthRevenue * 100) : 0;

$thisMonthOrders = count_rows("SELECT COUNT(*) FROM orders WHERE created_at >= ?", [$monthStart]);
$lastMonthOrders = count_rows("SELECT COUNT(*) FROM orders WHERE created_at >= ? AND created_at <= ?", [$lastMonthStart, $lastMonthEnd]);
$orderChangePct = $lastMonthOrders > 0 ? (($thisMonthOrders - $lastMonthOrders) / $lastMonthOrders * 100) : 0;

$avgOrderThisMonth = $thisMonthOrders > 0 ? $thisMonthRevenue / $thisMonthOrders : 0;
$avgOrderLastMonth = $lastMonthOrders > 0 ? $lastMonthRevenue / $lastMonthOrders : 0;
$avgChangePct = $avgOrderLastMonth > 0 ? (($avgOrderThisMonth - $avgOrderLastMonth) / $avgOrderLastMonth * 100) : 0;

$totalCustomers = count_rows("SELECT COUNT(*) FROM users WHERE is_staff=0");
$newCustomersMonth = count_rows("SELECT COUNT(*) FROM users WHERE is_staff=0 AND created_at >= ?", [$monthStart]);
$repeatCustomers = count_rows("SELECT COUNT(DISTINCT user_id) FROM orders WHERE user_id IS NOT NULL GROUP BY user_id HAVING COUNT(*) > 1");

$totalProducts = count_rows("SELECT COUNT(*) FROM products WHERE is_active=1");
$lowStock = count_rows("SELECT COUNT(*) FROM products WHERE is_active=1 AND stock <= 10");
$outOfStock = count_rows("SELECT COUNT(*) FROM products WHERE is_active=1 AND stock = 0");
$inventoryHealth = $totalProducts > 0 ? round(($totalProducts - $lowStock) / $totalProducts * 100) : 100;

$totalRevenue = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled'");
$totalCost = $totalRevenue * 0.6;
$profitMargin = $totalRevenue > 0 ? round(($totalRevenue - $totalCost) / $totalRevenue * 100) : 0;

$pendingRefunds = count_rows("SELECT COUNT(*) FROM refund_requests WHERE status='pending'");
$totalCoupons = count_rows("SELECT COUNT(*) FROM coupons");
$usedCoupons = count_rows("SELECT COUNT(*) FROM coupons WHERE used_count > 0");

$revenueByDay = [];
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} days"));
    $rev = count_rows("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled' AND DATE(created_at)=?", [$date]);
    $cost = $rev * 0.6;
    $revenueByDay[] = ['date' => date('M d', strtotime($date)), 'revenue' => (int)$rev, 'profit' => (int)($rev - $cost)];
}

$orderStatusDist = fetchAll("SELECT status, COUNT(*) as cnt FROM orders GROUP BY status ORDER BY cnt DESC");
$statusLabels = array_column($orderStatusDist, 'status');
$statusCounts = array_column($orderStatusDist, 'cnt');
$statusColors = ['#ffc107','#0dcaf0','#0d6efd','#6f42c1','#198754','#dc3545'];
$statusColorsUsed = array_slice($statusColors, 0, count($statusLabels));

$paymentMethods = fetchAll("SELECT payment_method, COUNT(*) as cnt, SUM(total) as total FROM orders WHERE payment_method IS NOT NULL GROUP BY payment_method ORDER BY cnt DESC");
$paymentLabels = array_column($paymentMethods, 'payment_method');
$paymentCounts = array_column($paymentMethods, 'cnt');
$paymentColors = ['#e94560','#0d6efd','#198754','#ffc107','#6f42c1','#0dcaf0'];

$topProducts = fetchAll("SELECT p.name, SUM(oi.quantity) as sold, SUM(oi.quantity * oi.price) as revenue FROM order_items oi JOIN products p ON oi.product_id=p.id JOIN orders o ON oi.order_id=o.id WHERE o.status != 'cancelled' GROUP BY p.id ORDER BY revenue DESC LIMIT 10");
$productNames = array_column($topProducts, 'name');
$productRevenues = array_column($topProducts, 'revenue');

$categoryPerf = fetchAll("SELECT c.name, COUNT(oi.id) as items_sold, SUM(oi.quantity * oi.price) as revenue FROM order_items oi JOIN products p ON oi.product_id=p.id JOIN categories c ON p.category_id=c.id JOIN orders o ON oi.order_id=o.id WHERE o.status != 'cancelled' GROUP BY c.id ORDER BY revenue DESC LIMIT 8");
$catLabels = array_column($categoryPerf, 'name');
$catRevenues = array_column($categoryPerf, 'revenue');

$hourlyOrders = fetchAll("SELECT " . sqlHour('created_at') . " as hour, COUNT(*) as cnt FROM orders GROUP BY hour ORDER BY hour");
$hourlyMap = array_fill(0, 24, 0);
foreach ($hourlyOrders as $h) { $hourlyMap[(int)$h['hour']] = (int)$h['cnt']; }
$maxHourly = max($hourlyMap) > 0 ? max($hourlyMap) : 1;

$customerSeg = fetchAll("SELECT CASE WHEN order_count=1 THEN 'One-time' WHEN order_count BETWEEN 2 AND 5 THEN 'Regular' WHEN order_count BETWEEN 6 AND 15 THEN 'Loyal' ELSE 'Champion' END as segment, COUNT(*) as cnt FROM (SELECT user_id, COUNT(*) as order_count FROM orders WHERE user_id IS NOT NULL GROUP BY user_id) GROUP BY segment");
$segLabels = array_column($customerSeg, 'segment');
$segCounts = array_column($customerSeg, 'cnt');

$dayOfWeek = fetchAll("SELECT " . sqlDayOfWeek('created_at') . " as day, COUNT(*) as cnt FROM orders GROUP BY day ORDER BY day");
$dayMap = array_fill(0, 7, 0);
foreach ($dayOfWeek as $d) { $dayMap[(int)$d['day']] = (int)$d['cnt']; }
$dayNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

$topCustomers = fetchAll("SELECT u.username, COUNT(o.id) as orders, SUM(o.total) as spent FROM orders o JOIN users u ON o.user_id=u.id WHERE o.status != 'cancelled' AND o.user_id IS NOT NULL GROUP BY o.user_id ORDER BY spent DESC LIMIT 10");

$couponStats = fetchAll("SELECT code, used_count, discount_percent, discount_amount FROM coupons ORDER BY used_count DESC LIMIT 10");

$revenueJson = json_encode($revenueByDay);
$statusLabelsJson = json_encode($statusLabels);
$statusCountsJson = json_encode($statusCounts);
$statusColorsJson = json_encode($statusColorsUsed);
$paymentLabelsJson = json_encode($paymentLabels);
$paymentCountsJson = json_encode($paymentCounts);
$paymentColorsJson = json_encode(array_slice($paymentColors, 0, count($paymentLabels)));
$productNamesJson = json_encode($productNames);
$productRevenuesJson = json_encode($productRevenues);
$catLabelsJson = json_encode($catLabels);
$catRevenuesJson = json_encode($catRevenues);
$hourlyMapJson = json_encode($hourlyMap);
$segLabelsJson = json_encode($segLabels);
$segCountsJson = json_encode($segCounts);
$dayNamesJson = json_encode($dayNames);
$dayMapJson = json_encode($dayMap);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0"><i class="fas fa-chart-pie text-primary"></i> BI 360 Analytics</h4>
    <div>
        <button onclick="window.print()" class="btn btn-sm btn-outline-secondary"><i class="fas fa-print"></i> Print Report</button>
    </div>
</div>

<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3 reveal stagger-1">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <p>Monthly Revenue</p>
                    <h3><?= formatPrice($thisMonthRevenue) ?></h3>
                    <small class="<?= $revenueChangePct >= 0 ? 'text-success' : 'text-danger' ?>">
                        <i class="fas fa-arrow-<?= $revenueChangePct >= 0 ? 'up' : 'down' ?>"></i> <?= number_format(abs($revenueChangePct), 1) ?>% vs last month
                    </small>
                </div>
                <div class="icon bg-success-light"><i class="fas fa-dollar-sign"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-3 reveal stagger-2">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <p>Monthly Orders</p>
                    <h3><?= $thisMonthOrders ?></h3>
                    <small class="<?= $orderChangePct >= 0 ? 'text-success' : 'text-danger' ?>">
                        <i class="fas fa-arrow-<?= $orderChangePct >= 0 ? 'up' : 'down' ?>"></i> <?= number_format(abs($orderChangePct), 1) ?>% vs last month
                    </small>
                </div>
                <div class="icon bg-primary-light"><i class="fas fa-shopping-cart"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-3 reveal stagger-3">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <p>Avg Order Value</p>
                    <h3><?= formatPrice($avgOrderThisMonth) ?></h3>
                    <small class="<?= $avgChangePct >= 0 ? 'text-success' : 'text-danger' ?>">
                        <i class="fas fa-arrow-<?= $avgChangePct >= 0 ? 'up' : 'down' ?>"></i> <?= number_format(abs($avgChangePct), 1) ?>% vs last month
                    </small>
                </div>
                <div class="icon bg-info-light"><i class="fas fa-receipt"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-3 reveal stagger-4">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <p>Profit Margin</p>
                    <h3 class="text-success"><?= $profitMargin ?>%</h3>
                    <small class="text-muted"><?= formatPrice($totalRevenue - $totalCost) ?> profit</small>
                </div>
                <div class="icon bg-warning-light"><i class="fas fa-chart-line"></i></div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3 reveal stagger-1">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <p>New Customers</p>
                    <h3><?= $newCustomersMonth ?></h3>
                    <small class="text-muted">this month</small>
                </div>
                <div class="icon bg-success-light"><i class="fas fa-user-plus"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-3 reveal stagger-2">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <p>Repeat Buyers</p>
                    <h3><?= $repeatCustomers ?></h3>
                    <small class="text-muted">2+ orders</small>
                </div>
                <div class="icon bg-purple-light"><i class="fas fa-redo"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-3 reveal stagger-3">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <p>Inventory Health</p>
                    <h3 class="<?= $inventoryHealth >= 90 ? 'text-success' : 'text-warning' ?>"><?= $inventoryHealth ?>%</h3>
                    <small class="text-muted"><?= $lowStock ?> low, <?= $outOfStock ?> out</small>
                </div>
                <div class="icon bg-info-light"><i class="fas fa-warehouse"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-3 reveal stagger-4">
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <p>Coupon Usage</p>
                    <h3><?= $usedCoupons ?>/<?= $totalCoupons ?></h3>
                    <small class="text-muted"><?= $pendingRefunds ?> pending refunds</small>
                </div>
                <div class="icon bg-danger-light"><i class="fas fa-ticket-alt"></i></div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-xl-8 mb-3">
        <div class="card card-custom">
            <div class="card-header"><h6>Revenue & Profit Trend (Last 30 Days)</h6></div>
            <div class="card-body"><canvas id="revenueProfitChart" height="90"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4 mb-3">
        <div class="card card-custom">
            <div class="card-header"><h6>Order Status Distribution</h6></div>
            <div class="card-body d-flex align-items-center justify-content-center"><canvas id="orderStatusChart" height="200"></canvas></div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-xl-4 mb-3">
        <div class="card card-custom">
            <div class="card-header"><h6>Payment Methods</h6></div>
            <div class="card-body d-flex align-items-center justify-content-center"><canvas id="paymentChart" height="200"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4 mb-3">
        <div class="card card-custom">
            <div class="card-header"><h6>Customer Segmentation</h6></div>
            <div class="card-body d-flex align-items-center justify-content-center"><canvas id="customerSegChart" height="200"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4 mb-3">
        <div class="card card-custom">
            <div class="card-header"><h6>Sales by Day of Week</h6></div>
            <div class="card-body"><canvas id="dayOfWeekChart" height="160"></canvas></div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-xl-6 mb-3">
        <div class="card card-custom">
            <div class="card-header"><h6>Top Products by Revenue</h6></div>
            <div class="card-body"><canvas id="topProductsChart" height="180"></canvas></div>
        </div>
    </div>
    <div class="col-xl-6 mb-3">
        <div class="card card-custom">
            <div class="card-header"><h6>Category Performance</h6></div>
            <div class="card-body"><canvas id="categoryChart" height="180"></canvas></div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-xl-8 mb-3">
        <div class="card card-custom">
            <div class="card-header"><h6>Hourly Order Heatmap</h6></div>
            <div class="card-body">
                <div class="heatmap-grid" id="heatmapGrid"></div>
                <div class="d-flex justify-content-between mt-2" style="font-size:0.75rem;color:#999;">
                    <span>12 AM</span><span>6 AM</span><span>12 PM</span><span>6 PM</span><span>11 PM</span>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4 mb-3">
        <div class="card card-custom">
            <div class="card-header"><h6>Top 10 Customers</h6></div>
            <div class="card-body" style="max-height:320px;overflow-y:auto;">
                <?php if (!empty($topCustomers)): ?>
                <?php foreach ($topCustomers as $i => $c): ?>
                <div class="d-flex justify-content-between align-items-center mb-2 p-2 rounded <?= $i < 3 ? 'bg-warning bg-opacity-10' : '' ?>">
                    <div>
                        <strong>#<?= $i+1 ?> <?= htmlspecialchars($c['username']) ?></strong><br>
                        <small class="text-muted"><?= $c['orders'] ?> orders</small>
                    </div>
                    <span class="fw-bold text-primary"><?= formatPrice($c['spent']) ?></span>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <p class="text-muted text-center">No data</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-xl-6 mb-3">
        <div class="card card-custom">
            <div class="card-header"><h6>Coupon Performance</h6></div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-custom">
                        <thead><tr><th>Code</th><th>Discount</th><th>Times Used</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php foreach ($couponStats as $cp): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($cp['code']) ?></strong></td>
                                <td><?= $cp['discount_percent'] ? $cp['discount_percent'].'%' : formatPrice($cp['discount_amount']) ?></td>
                                <td><?= $cp['used_count'] ?></td>
                                <td><span class="badge bg-<?= $cp['used_count'] > 0 ? 'success' : 'secondary' ?>"><?= $cp['used_count'] > 0 ? 'Active' : 'Unused' ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-6 mb-3">
        <div class="card card-custom">
            <div class="card-header"><h6>Business Health Score</h6></div>
            <div class="card-body">
                <div class="row g-3">
                    <?php
                    $scores = [
                        ['label' => 'Revenue Growth', 'score' => max(0, min(100, 50 + $revenueChangePct)), 'color' => '#198754'],
                        ['label' => 'Order Volume', 'score' => max(0, min(100, 50 + $orderChangePct)), 'color' => '#0d6efd'],
                        ['label' => 'Customer Retention', 'score' => $totalCustomers > 0 ? round($repeatCustomers / $totalCustomers * 100) : 0, 'color' => '#6f42c1'],
                        ['label' => 'Inventory Health', 'score' => $inventoryHealth, 'color' => '#0dcaf0'],
                        ['label' => 'Profit Margin', 'score' => $profitMargin, 'color' => '#e94560'],
                        ['label' => 'Coupon Adoption', 'score' => $totalCoupons > 0 ? round($usedCoupons / $totalCoupons * 100) : 0, 'color' => '#ffc107'],
                    ];
                    $overallScore = round(array_sum(array_column($scores, 'score')) / count($scores));
                    ?>
                    <div class="col-12 text-center mb-3">
                        <div style="width:120px;height:120px;border-radius:50%;border:8px solid <?= $overallScore >= 70 ? '#198754' : ($overallScore >= 40 ? '#ffc107' : '#dc3545') ?>;margin:0 auto;display:flex;align-items:center;justify-content:center;flex-direction:column;">
                            <h2 class="mb-0 fw-bold"><?= $overallScore ?></h2>
                            <small>/ 100</small>
                        </div>
                        <p class="mt-2 fw-bold text-<?= $overallScore >= 70 ? 'success' : ($overallScore >= 40 ? 'warning' : 'danger') ?>"><?= $overallScore >= 70 ? 'Healthy' : ($overallScore >= 40 ? 'Needs Attention' : 'Critical') ?></p>
                    </div>
                    <?php foreach ($scores as $s): ?>
                    <div class="col-md-6">
                        <div class="d-flex justify-content-between mb-1">
                            <small><?= $s['label'] ?></small>
                            <small class="fw-bold"><?= $s['score'] ?>%</small>
                        </div>
                        <div class="progress" style="height:8px;border-radius:4px;">
                            <div class="progress-bar" style="width:<?= $s['score'] ?>%;background:<?= $s['color'] ?>;"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?= SITE_URL ?>/assets/js/chart.umd.min.js"></script>
<script>
const revData = <?= $revenueJson ?>;
new Chart(document.getElementById('revenueProfitChart'), {
    type: 'line',
    data: {
        labels: revData.map(d => d.date),
        datasets: [
            { label: 'Revenue', data: revData.map(d => d.revenue), borderColor: '#e94560', backgroundColor: 'rgba(233,69,96,0.1)', fill: true, tension: 0.4 },
            { label: 'Profit', data: revData.map(d => d.profit), borderColor: '#198754', backgroundColor: 'rgba(25,135,84,0.1)', fill: true, tension: 0.4 }
        ]
    },
    options: { responsive: true, plugins: { legend: { position: 'top' } }, scales: { y: { beginAtZero: true } } }
});

new Chart(document.getElementById('orderStatusChart'), {
    type: 'doughnut',
    data: {
        labels: <?= $statusLabelsJson ?>,
        datasets: [{ data: <?= $statusCountsJson ?>, backgroundColor: <?= $statusColorsJson ?> }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
});

new Chart(document.getElementById('paymentChart'), {
    type: 'pie',
    data: {
        labels: <?= $paymentLabelsJson ?>,
        datasets: [{ data: <?= $paymentCountsJson ?>, backgroundColor: <?= $paymentColorsJson ?> }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
});

new Chart(document.getElementById('customerSegChart'), {
    type: 'doughnut',
    data: {
        labels: <?= $segLabelsJson ?>,
        datasets: [{ data: <?= $segCountsJson ?>, backgroundColor: ['#e94560','#0d6efd','#198754','#ffc107'] }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
});

new Chart(document.getElementById('dayOfWeekChart'), {
    type: 'bar',
    data: {
        labels: <?= $dayNamesJson ?>,
        datasets: [{ label: 'Orders', data: <?= $dayMapJson ?>, backgroundColor: '#e94560', borderRadius: 6 }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
});

new Chart(document.getElementById('topProductsChart'), {
    type: 'bar',
    data: {
        labels: <?= $productNamesJson ?>,
        datasets: [{ label: 'Revenue', data: <?= $productRevenuesJson ?>, backgroundColor: '#e94560', borderRadius: 6 }]
    },
    options: { indexAxis: 'y', responsive: true, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true } } }
});

new Chart(document.getElementById('categoryChart'), {
    type: 'bar',
    data: {
        labels: <?= $catLabelsJson ?>,
        datasets: [{ label: 'Revenue', data: <?= $catRevenuesJson ?>, backgroundColor: ['#e94560','#0d6efd','#198754','#ffc107','#6f42c1','#0dcaf0','#dc3545','#fd7e14'], borderRadius: 6 }]
    },
    options: { indexAxis: 'y', responsive: true, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true } } }
});

const hourlyData = <?= $hourlyMapJson ?>;
const maxH = <?= $maxHourly ?>;
const grid = document.getElementById('heatmapGrid');
grid.style.display = 'grid';
grid.style.gridTemplateColumns = 'repeat(12, 1fr)';
grid.style.gap = '4px';
hourlyData.forEach((v, i) => {
    const cell = document.createElement('div');
    const intensity = v / maxH;
    cell.style.cssText = 'border-radius:4px;padding:8px 4px;text-align:center;font-size:0.7rem;color:' + (intensity > 0.5 ? '#fff' : '#333') + ';background:rgba(233,69,96,' + (0.1 + intensity * 0.9) + ');';
    cell.innerHTML = '<div class="fw-bold">' + i + ':00</div><div>' + v + '</div>';
    grid.appendChild(cell);
});
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
