<?php
$pageTitle = 'Product Variants';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM product_variants WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Variant deleted.'); redirect(SITE_URL . '/admin/variants.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [(int)$_POST['product_id'], $_POST['name'], (float)$_POST['price_adjust'], (int)$_POST['stock']];
    if ($id) { query("UPDATE product_variants SET product_id=?, name=?, price_adjust=?, stock=? WHERE id=?", array_merge($data, [$id])); }
    else { query("INSERT INTO product_variants (product_id, name, price_adjust, stock) VALUES (?,?,?,?)", $data); }
    setAlert('success', 'Variant saved!'); redirect(SITE_URL . '/admin/variants.php');
}
$variants = fetchAll("SELECT pv.*, p.name as product_name FROM product_variants pv LEFT JOIN products p ON pv.product_id=p.id ORDER BY p.name, pv.name");
$products = fetchAll("SELECT id, name FROM products ORDER BY name");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Product Variants (<?= count($variants) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_prod').value='';document.getElementById('f_name').value='';document.getElementById('f_adj').value='0';document.getElementById('f_stock').value='0';document.getElementById('modalTitle').textContent='Add Variant';"><i class="fas fa-plus"></i> Add</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>Product</th><th>Variant Name</th><th>Price Adjust</th><th>Stock</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($variants as $v): ?>
<tr><td><?= htmlspecialchars($v['product_name'] ?? 'Deleted') ?></td><td><strong><?= htmlspecialchars($v['name']) ?></strong></td>
<td><?= $v['price_adjust']>=0?'+':'' ?><?= formatPrice($v['price_adjust']) ?></td><td><?= $v['stock'] ?></td>
<td><button class="btn btn-sm btn-warning" onclick="document.getElementById('f_id').value='<?= $v['id'] ?>';document.getElementById('f_prod').value='<?= $v['product_id'] ?>';document.getElementById('f_name').value='<?= htmlspecialchars($v['name']) ?>';document.getElementById('f_adj').value='<?= $v['price_adjust'] ?>';document.getElementById('f_stock').value='<?= $v['stock'] ?>';document.getElementById('modalTitle').textContent='Edit Variant';new bootstrap.Modal(document.getElementById('modal')).show();"><i class="fas fa-edit"></i></button> <a href="?delete=<?= $v['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Variant</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">Product</label><select name="product_id" id="f_prod" class="form-select" required><option value="">Select</option><?php foreach ($products as $p): ?><option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></option><?php endforeach; ?></select></div>
<div class="mb-3"><label class="form-label">Variant Name (e.g., Size L, Color Red)</label><input type="text" name="name" id="f_name" class="form-control" required></div>
<div class="row g-3"><div class="col-6"><label class="form-label">Price Adjustment</label><input type="number" step="0.01" name="price_adjust" id="f_adj" class="form-control"></div>
<div class="col-6"><label class="form-label">Stock</label><input type="number" name="stock" id="f_stock" class="form-control"></div></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
