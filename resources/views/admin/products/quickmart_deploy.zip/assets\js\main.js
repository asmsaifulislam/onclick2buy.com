document.addEventListener('DOMContentLoaded', function() {
    var SITE = (document.querySelector('meta[name="site-url"]') || {}).content || '';
    // ─── Glassmorphism Navbar Scroll ───
    var navbar = document.querySelector('.navbar-glass');
    var topBar = document.querySelector('.navbar-top-bar');
    if (navbar) {
        var scrollThreshold = 50;
        var ticking = false;
        function onScroll() {
            if (!ticking) {
                window.requestAnimationFrame(function() {
                    if (window.scrollY > scrollThreshold) {
                        navbar.classList.add('scrolled');
                        document.body.classList.add('nav-scrolled');
                        if (topBar) topBar.classList.add('hidden-bar');
                    } else {
                        navbar.classList.remove('scrolled');
                        document.body.classList.remove('nav-scrolled');
                        if (topBar) topBar.classList.remove('hidden-bar');
                    }
                    ticking = false;
                });
                ticking = true;
            }
        }
        window.addEventListener('scroll', onScroll, { passive: true });
        onScroll();
    }

    // Add to cart buttons
    document.querySelectorAll('.add-to-cart-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var productId = this.getAttribute('data-id');
            var qtyInput = document.getElementById('qty');
            var qty = qtyInput ? qtyInput.value : 1;

            fetch(SITE + '/api/cart.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'},
                body: 'action=add&product_id=' + productId + '&quantity=' + qty
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    // Update cart badge
                    var badges = document.querySelectorAll('.badge.bg-danger');
                    badges.forEach(b => {
                        if (b.closest('a[href*="cart"]')) b.textContent = data.cart_count;
                    });
                    // Reload slide-over cart panel
                    if (window.reloadCartPanel) window.reloadCartPanel();
                    // Show feedback
                    var originalText = btn.innerHTML;
                    btn.innerHTML = '<i class="fas fa-check"></i> Added!';
                    btn.classList.add('btn-success');
                    setTimeout(function() {
                        btn.innerHTML = originalText;
                        btn.classList.remove('btn-success');
                    }, 1500);
                }
            });
        });
    });

    // Add to wishlist buttons
    document.querySelectorAll('.add-to-wishlist-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var productId = this.getAttribute('data-id');
            fetch(SITE + '/api/wishlist.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'},
                body: 'action=add&product_id=' + productId
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    btn.innerHTML = '<i class="fas fa-heart" style="color:red"></i>';
                }
            });
        });
    });

    // ─── Buy Now Button ───
    document.querySelectorAll('.buy-now-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var productId = this.getAttribute('data-id');
            var qtyInput = document.getElementById('qty');
            var qty = qtyInput ? qtyInput.value : 1;
            var originalHTML = btn.innerHTML;

            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
            btn.disabled = true;

            fetch(SITE + '/api/cart.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'},
                body: 'action=add&product_id=' + productId + '&quantity=' + qty
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    btn.innerHTML = '<i class="fas fa-check"></i> Added!';
                    btn.classList.add('btn-success');
                    if (window.reloadCartPanel) window.reloadCartPanel();
                    setTimeout(function() {
                        window.location.href = SITE + '/store/checkout.php';
                    }, 600);
                } else {
                    btn.innerHTML = '<i class="fas fa-times"></i> Failed';
                    setTimeout(function() {
                        btn.innerHTML = originalHTML;
                        btn.disabled = false;
                    }, 1500);
                }
            })
            .catch(function() {
                btn.innerHTML = originalHTML;
                btn.disabled = false;
                showToast('Error adding to cart', 'danger');
            });
        });
    });
});
