<?php
$pageTitle = 'Gift Wraps';
require_once __DIR__ . '/../includes/admin_header.php';
if (isset($_GET['delete'])) { query("DELETE FROM gift_wraps WHERE id=?", [(int)$_GET['delete']]); setAlert('success', 'Deleted.'); redirect(SITE_URL . '/admin/gift_wraps.php'); }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [$_POST['name'], $_POST['description'], (float)$_POST['price']];
    if ($id) { query("UPDATE gift_wraps SET name=?, description=?, price=? WHERE id=?", array_merge($data, [$id])); }
    else { query("INSERT INTO gift_wraps (name, description, price) VALUES (?,?,?)", $data); }
    setAlert('success', 'Gift wrap saved!'); redirect(SITE_URL . '/admin/gift_wraps.php');
}
$wraps = fetchAll("SELECT * FROM gift_wraps ORDER BY name");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Gift Wrapping Options (<?= count($wraps) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal" onclick="document.getElementById('f_id').value='';document.getElementById('f_name').value='';document.getElementById('f_desc').value='';document.getElementById('f_price').value='';document.getElementById('modalTitle').textContent='Add Gift Wrap';"><i class="fas fa-plus"></i> Add</button>
</div>
<div class="card card-custom"><div class="card-body"><div class="table-responsive">
<table class="table table-custom"><thead><tr><th>Name</th><th>Description</th><th>Price</th><th>Actions</th></tr></thead>
<tbody><?php foreach ($wraps as $w): ?>
<tr><td><strong><?= htmlspecialchars($w['name']) ?></strong></td><td><?= htmlspecialchars($w['description']) ?></td><td><?= formatPrice($w['price']) ?></td>
<td><button class="btn btn-sm btn-warning" onclick="document.getElementById('f_id').value='<?= $w['id'] ?>';document.getElementById('f_name').value='<?= htmlspecialchars($w['name']) ?>';document.getElementById('f_desc').value='<?= htmlspecialchars($w['description']) ?>';document.getElementById('f_price').value='<?= $w['price'] ?>';document.getElementById('modalTitle').textContent='Edit Gift Wrap';new bootstrap.Modal(document.getElementById('modal')).show();"><i class="fas fa-edit"></i></button> <a href="?delete=<?= $w['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody></table></div></div></div>
<div class="modal fade" id="modal" tabindex="-1"><div class="modal-dialog"><div class="modal-content bg-dark">
<form method="POST"><div class="modal-header"><h5 class="modal-title" id="modalTitle">Add Gift Wrap</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><input type="hidden" name="id" id="f_id">
<div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" id="f_name" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Description</label><input type="text" name="description" id="f_desc" class="form-control"></div>
<div class="mb-3"><label class="form-label">Price</label><input type="number" step="0.01" name="price" id="f_price" class="form-control" required></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div></form>
</div></div></div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
