<?php
$pageTitle = 'Products - Quick Mart';
require_once __DIR__ . '/../includes/header.php';

$category = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? 'newest';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 12;

$where = "WHERE p.is_active=1";
$params = [];

if ($category) {
    $where .= " AND c.slug=?";
    $params[] = $category;
}
if ($search) {
    $where .= " AND (p.name LIKE ? OR p.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$orderBy = match($sort) {
    'price_low' => 'p.price ASC',
    'price_high' => 'p.price DESC',
    'rating' => 'p.average_rating DESC',
    'popular' => 'p.total_reviews DESC',
    default => 'p.created_at DESC'
};

$total = count_rows("SELECT COUNT(*) FROM products p LEFT JOIN categories c ON p.category_id=c.id $where", $params);
$totalPages = ceil($total / $perPage);
$offset = ($page - 1) * $perPage;
$params[] = $perPage;
$params[] = $offset;

$products = fetchAll("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id $where ORDER BY $orderBy LIMIT ? OFFSET ?", $params);
$categories = getCategories();
$catName = $category ? $categories[array_search($category, array_column($categories, 'slug'))]['name'] ?? '' : '';
?>

<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card card-custom p-3">
            <h5 class="mb-3">Filters</h5>
            <form method="GET">
                <div class="mb-3">
                    <label class="form-label fw-bold">Search</label>
                    <input type="text" name="search" class="form-control" placeholder="Search products..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Category</label>
                    <select name="category" class="form-select">
                        <option value="">All Categories</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['slug'] ?>" <?= $category == $cat['slug'] ? 'selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Sort By</label>
                    <select name="sort" class="form-select">
                        <option value="newest" <?= $sort == 'newest' ? 'selected' : '' ?>>Newest</option>
                        <option value="price_low" <?= $sort == 'price_low' ? 'selected' : '' ?>>Price: Low to High</option>
                        <option value="price_high" <?= $sort == 'price_high' ? 'selected' : '' ?>>Price: High to Low</option>
                        <option value="rating" <?= $sort == 'rating' ? 'selected' : '' ?>>Top Rated</option>
                        <option value="popular" <?= $sort == 'popular' ? 'selected' : '' ?>>Most Popular</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100">Apply</button>
            </form>
        </div>
    </div>
    <div class="col-md-9">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4><?= $catName ? $catName : ($search ? "Search: $search" : 'All Products') ?></h4>
            <span class="text-muted"><?= $total ?> products found</span>
        </div>
        <div class="row g-4">
            <?php if (empty($products)): ?>
            <div class="col-12 text-center py-5">
                <i class="fas fa-search fa-3x text-muted mb-3"></i>
                <h5>No products found</h5>
                <a href="<?= SITE_URL ?>/store/products.php" class="btn btn-primary">View All Products</a>
            </div>
            <?php else: ?>
            <?php foreach ($products as $p): ?>
            <div class="col-6 col-lg-4">
                <div class="card h-100 card-custom product-card" data-pid="<?= $p['id'] ?>">
                    <div class="card-body">
                        <div class="card-overlay">
                            <button class="overlay-btn overlay-btn-quickview" data-id="<?= $p['id'] ?>" title="Quick View"><i class="fas fa-eye"></i></button>
                            <button class="overlay-btn overlay-btn-wishlist add-to-wishlist-btn" data-id="<?= $p['id'] ?>" title="Add to Wishlist"><i class="far fa-heart"></i></button>
                        </div>
                        <span class="badge bg-secondary mb-2"><?= htmlspecialchars($p['cat_name'] ?? '') ?></span>
                        <h6 class="card-title"><?= htmlspecialchars($p['name']) ?></h6>
                        <div class="mb-2">
                            <?php for ($i = 0; $i < 5; $i++): ?>
                            <i class="fas fa-star <?= $i < $p['average_rating'] ? 'text-warning' : 'text-muted' ?>" style="font-size:12px"></i>
                            <?php endfor; ?>
                            <small class="text-muted">(<?= $p['total_reviews'] ?>)</small>
                        </div>
                        <h5 class="text-primary"><?= formatPrice($p['price']) ?></h5>
                        <p class="text-muted small mb-2">Stock: <?= $p['stock'] ?></p>
                        <div class="d-flex gap-1 flex-wrap">
                            <a href="<?= SITE_URL ?>/store/product.php?slug=<?= $p['slug'] ?>" class="btn btn-sm btn-outline-primary flex-grow-1">View</a>
                            <button class="btn btn-sm btn-primary add-to-cart-btn" data-id="<?= $p['id'] ?>">
                                <i class="fas fa-cart-plus"></i>
                            </button>
                            <button class="buy-now-btn buy-now-btn-sm" data-id="<?= $p['id'] ?>" title="Buy Now">
                                <i class="fas fa-bolt"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?php if ($totalPages > 1): ?>
        <nav class="mt-4">
            <ul class="pagination justify-content-center">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                    <a class="page-link" href="?page=<?= $i ?>&category=<?= $category ?>&search=<?= $search ?>&sort=<?= $sort ?>"><?= $i ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
