<?php
require_once __DIR__ . '/db.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    if (!isLoggedIn()) return false;
    $u = fetch("SELECT is_staff FROM users WHERE id=?", [$_SESSION['user_id']]);
    return $u && $u['is_staff'];
}

function loginUser($username, $password) {
    $user = fetch("SELECT * FROM users WHERE username=?", [$username]);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['is_staff'] = $user['is_staff'];
        return true;
    }
    return false;
}

function registerUser($username, $email, $password) {
    $exists = count_rows("SELECT COUNT(*) FROM users WHERE username=? OR email=?", [$username, $email]);
    if ($exists) return false;
    $hash = password_hash($password, PASSWORD_DEFAULT);
    insertId("INSERT INTO users (username, email, password, is_staff, created_at) VALUES (?,?,?,?,?)", [$username, $email, $hash, 0, date('Y-m-d H:i:s')]);
    return true;
}

function logoutUser() {
    session_destroy();
    header("Location: " . SITE_URL . "/store/login.php");
    exit;
}

function getCartSession() {
    if (!isset($_SESSION['cart_session'])) {
        $_SESSION['cart_session'] = session_id();
    }
    return $_SESSION['cart_session'];
}

function getCartCount() {
    $sid = getCartSession();
    if (isLoggedIn()) {
        return count_rows("SELECT COALESCE(SUM(quantity),0) FROM cart_items WHERE user_id=?", [$_SESSION['user_id']]);
    }
    return count_rows("SELECT COALESCE(SUM(quantity),0) FROM cart_items WHERE session_id=?", [$sid]);
}

function getCartTotal() {
    $sid = getCartSession();
    if (isLoggedIn()) {
        $r = fetch("SELECT COALESCE(SUM(p.price * c.quantity),0) as total FROM cart_items c JOIN products p ON c.product_id=p.id WHERE c.user_id=?", [$_SESSION['user_id']]);
    } else {
        $r = fetch("SELECT COALESCE(SUM(p.price * c.quantity),0) as total FROM cart_items c JOIN products p ON c.product_id=p.id WHERE c.session_id=?", [$sid]);
    }
    return $r['total'] ?? 0;
}

function getWishlistCount() {
    if (!isLoggedIn()) return 0;
    return count_rows("SELECT COUNT(*) FROM wishlist WHERE user_id=?", [$_SESSION['user_id']]);
}

function dbDriver() {
    return db()->getAttribute(PDO::ATTR_DRIVER_NAME);
}

function sqlHour($col) {
    return dbDriver() === 'mysql' ? "DATE_FORMAT($col, '%H')" : "strftime('%H', $col)";
}

function sqlDayOfWeek($col) {
    return dbDriver() === 'mysql' ? "DAYOFWEEK($col) - 1" : "strftime('%w', $col)";
}

function sqlCastAsText($expr) {
    return dbDriver() === 'mysql' ? "CAST($expr AS CHAR)" : "CAST($expr AS TEXT)";
}

function sqlMonth($col) {
    return dbDriver() === 'mysql' ? "MONTH($col)" : "CAST(strftime('%m', $col) AS INTEGER)";
}

function sqlYear($col) {
    return dbDriver() === 'mysql' ? "YEAR($col)" : "CAST(strftime('%Y', $col) AS INTEGER)";
}

function formatPrice($price) {
    return 'BDT ' . number_format($price);
}

function slugify($text) {
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9-]/', '-', $text);
    $text = preg_replace('/-+/', '-', $text);
    return trim($text, '-');
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function setAlert($type, $msg) {
    $_SESSION['alert'] = ['type' => $type, 'msg' => $msg];
}

function getAlert() {
    if (isset($_SESSION['alert'])) {
        $a = $_SESSION['alert'];
        unset($_SESSION['alert']);
        return '<div class="alert alert-' . $a['type'] . ' alert-dismissible fade show">' . htmlspecialchars($a['msg']) . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    }
    return '';
}

function timeAgo($datetime) {
    $now = new DateTime();
    $past = new DateTime($datetime);
    $diff = $now->diff($past);
    if ($diff->y > 0) return $diff->y . ' year(s) ago';
    if ($diff->m > 0) return $diff->m . ' month(s) ago';
    if ($diff->d > 0) return $diff->d . ' day(s) ago';
    if ($diff->h > 0) return $diff->h . ' hour(s) ago';
    if ($diff->i > 0) return $diff->i . ' minute(s) ago';
    return 'Just now';
}

function generateOrderNumber() {
    return 'QM' . date('Ymd') . strtoupper(substr(uniqid(), -6));
}

function getProductImage($product) {
    if (!empty($product['image']) && file_exists(__DIR__ . '/../assets/images/' . $product['image'])) return SITE_URL . '/assets/images/' . $product['image'];
    return SITE_URL . '/assets/images/no-image.svg';
}

function getSiteConfig($key = null, $default = '') {
    static $configs = null;
    if ($configs === null) {
        $configs = [];
        $rows = fetchAll("SELECT `key`, value FROM site_config");
        foreach ($rows as $r) $configs[$r['key']] = $r['value'];
    }
    if ($key === null) return $configs;
    return $configs[$key] ?? $default;
}

function getCategories() {
    return fetchAll("SELECT c.*, (SELECT COUNT(*) FROM products WHERE category_id=c.id AND is_active=1) as product_count FROM categories c WHERE c.is_active=1 ORDER BY c.name");
}

function getUserRole() {
    if (!isLoggedIn()) return '';
    if (isAdmin() && ($_SESSION['user_id'] ?? 0) == 1) return 'super_admin';
    $role = fetch("SELECT role FROM staff_roles WHERE user_id=?", [$_SESSION['user_id']]);
    return $role ? $role['role'] : (isAdmin() ? 'staff' : 'customer');
}

function hasPermission($permission) {
    if (!isLoggedIn()) return false;
    if (($_SESSION['user_id'] ?? 0) == 1) return true;
    $perm = fetch("SELECT $permission FROM staff_roles WHERE user_id=?", [$_SESSION['user_id']]);
    return $perm && $perm[$permission];
}

function requirePermission($permission) {
    if (!hasPermission($permission)) {
        setAlert('danger', 'You do not have permission to access this page.');
        redirect(SITE_URL . '/admin/');
    }
}

function isUserBanned($userId) {
    $user = fetch("SELECT is_active FROM users WHERE id=?", [$userId]);
    return $user && $user['is_active'] == 0;
}
