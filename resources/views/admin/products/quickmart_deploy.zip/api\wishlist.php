<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn()) { setAlert('danger', 'Please login first.'); redirect(SITE_URL . '/store/login.php'); }

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$productId = (int)($_POST['product_id'] ?? $_GET['product_id'] ?? 0);
$userId = $_SESSION['user_id'];

switch ($action) {
    case 'add':
        if ($productId) {
            $exists = count_rows("SELECT COUNT(*) FROM wishlist WHERE user_id=? AND product_id=?", [$userId, $productId]);
            if (!$exists) {
                query("INSERT INTO wishlist (user_id, product_id) VALUES (?,?)", [$userId, $productId]);
                setAlert('success', 'Added to wishlist!');
            } else {
                setAlert('info', 'Already in your wishlist.');
            }
        }
        break;
    case 'remove':
        if ($productId) {
            query("DELETE FROM wishlist WHERE user_id=? AND product_id=?", [$userId, $productId]);
            setAlert('success', 'Removed from wishlist.');
        }
        break;
}

$referer = $_SERVER['HTTP_REFERER'] ?? SITE_URL . '/store/wishlist.php';
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'wishlist_count' => getWishlistCount()]);
    exit;
}
redirect($referer);
