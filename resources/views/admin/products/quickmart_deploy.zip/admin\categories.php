<?php
$pageTitle = 'Manage Categories';
require_once __DIR__ . '/../includes/admin_header.php';

if (isset($_GET['delete'])) {
    query("DELETE FROM categories WHERE id=?", [(int)$_GET['delete']]);
    setAlert('success', 'Category deleted.');
    redirect(SITE_URL . '/admin/categories.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $name = $_POST['name'];
    $slug = slugify($name);
    $desc = $_POST['description'] ?? '';
    if ($id) {
        query("UPDATE categories SET name=?, slug=?, description=? WHERE id=?", [$name, $slug, $desc, $id]);
        setAlert('success', 'Category updated!');
    } else {
        query("INSERT INTO categories (name, slug, description) VALUES (?,?,?)", [$name, $slug, $desc]);
        setAlert('success', 'Category added!');
    }
    redirect(SITE_URL . '/admin/categories.php');
}

$categories = fetchAll("SELECT c.*, (SELECT COUNT(*) FROM products WHERE category_id=c.id) as product_count FROM categories c ORDER BY c.name");
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Categories (<?= count($categories) ?>)</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#catModal" onclick="document.getElementById('c_id').value='';document.getElementById('c_name').value='';document.getElementById('c_desc').value='';document.getElementById('catModalTitle').textContent='Add Category';">
        <i class="fas fa-plus"></i> Add Category
    </button>
</div>

<div class="card card-custom">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-custom">
                <thead><tr><th>ID</th><th>Name</th><th>Slug</th><th>Products</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($categories as $c): ?>
                    <tr>
                        <td><?= $c['id'] ?></td>
                        <td><strong><?= htmlspecialchars($c['name']) ?></strong></td>
                        <td><?= $c['slug'] ?></td>
                        <td><span class="badge bg-primary"><?= $c['product_count'] ?></span></td>
                        <td>
                            <button class="btn btn-sm btn-warning" onclick="document.getElementById('c_id').value='<?= $c['id'] ?>';document.getElementById('c_name').value='<?= htmlspecialchars($c['name']) ?>';document.getElementById('c_desc').value='<?= htmlspecialchars($c['description']) ?>';document.getElementById('catModalTitle').textContent='Edit Category';new bootstrap.Modal(document.getElementById('catModal')).show();"><i class="fas fa-edit"></i></button>
                            <a href="?delete=<?= $c['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="catModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="catModalTitle">Add Category</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="c_id">
                    <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" id="c_name" class="form-control" required></div>
                    <div class="mb-3"><label class="form-label">Description</label><textarea name="description" id="c_desc" class="form-control" rows="3"></textarea></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
