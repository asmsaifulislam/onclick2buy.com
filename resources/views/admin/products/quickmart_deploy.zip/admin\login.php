<?php
require_once __DIR__ . '/../includes/functions.php';
if (isLoggedIn() && isAdmin()) redirect(SITE_URL . '/admin/');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (loginUser($_POST['username'], $_POST['password'])) {
        if (isAdmin()) {
            redirect(SITE_URL . '/admin/');
        } else {
            logoutUser();
            setAlert('danger', 'Access denied. Admin only.');
            header("Location: login.php");
            exit;
        }
    } else {
        setAlert('danger', 'Invalid credentials.');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Quick Mart</title>
    <link href="<?= SITE_URL ?>/assets/css/bootstrap.min.css" rel="stylesheet">
    <style>body{background:#0a0a1a;min-height:100vh;display:flex;align-items:center;justify-content:center;}</style>
</head>
<body>
<div class="card bg-dark border-secondary p-4" style="width:400px">
    <h3 class="text-center mb-4 text-white">Admin Login</h3>
    <?= getAlert() ?>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label text-white">Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label text-white">Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
    <p class="text-muted small text-center mt-3">Demo: admin / admin123</p>
</div>
</body>
</html>
